#include "parcelmanagementwidget.h"
#include "ui_parcelmanagementwidget.h"
#include <QDesktopWidget>
#include <QDebug>
#include <QDate>
#include <QMessageBox>
#include "mydb.h"
#include <iostream>
ParcelManagementWidget::ParcelManagementWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ParcelManagementWidget)
{
    ui->setupUi(this);
    initData();
    initUi();//初始化界面参数
    initConnect();//初始化信号和槽连接
}

ParcelManagementWidget::~ParcelManagementWidget()
{
    delete ui;
}
void ParcelManagementWidget::initUi()
{
    // 固定窗口的大小
    this->setFixedSize(this->width(), this->height());
    this->setWindowTitle("包裹管理");
    //设置弹出窗口的位置（在屏幕中央）
    QDesktopWidget *deskdop=QApplication::desktop();
    this->move((deskdop->width()-this->width())/2,      (deskdop->height()-this->height())/2);

    QString  itemText;
    itemText = "";
    ui->comboBox_parcelState->insertItem(0,itemText);
    itemText = "未装车";
    ui->comboBox_parcelState->insertItem(1,itemText);
    itemText = "已装车";
    ui->comboBox_parcelState->insertItem(2,itemText);
    itemText = "已出发";
    ui->comboBox_parcelState->insertItem(3,itemText);
    itemText = "滞留";
    ui->comboBox_parcelState->insertItem(4,itemText);
    itemText = "拒收";
    ui->comboBox_parcelState->insertItem(5,itemText);
    itemText = "本人签收";
    ui->comboBox_parcelState->insertItem(6,itemText);
    itemText = "他人签收";
    ui->comboBox_parcelState->insertItem(7,itemText);
    itemText = "人工配送";
    ui->comboBox_parcelState->insertItem(8,itemText);



    itemText = "";
    ui->comboBox_parcelSchedule->insertItem(0,itemText);
    itemText = "1";
    ui->comboBox_parcelSchedule->insertItem(1,itemText);
    itemText = "2";
    ui->comboBox_parcelSchedule->insertItem(2,itemText);
    itemText = "3";
    ui->comboBox_parcelSchedule->insertItem(3,itemText);
    itemText = "4";
    ui->comboBox_parcelSchedule->insertItem(3,itemText);

    //table Widget
    ui->tableWidget->setColumnCount(6);
    ui->tableWidget->setRowCount(0);
    ui->tableWidget->setHorizontalHeaderLabels(QStringList() <<"运单号"<< "订单号" <<"包裹状态"<< "收货人"  <<"送货时间"<<"送货班次");

    ui->tableWidget->setColumnWidth(0, 150);
    ui->tableWidget->setColumnWidth(1, 150);
    ui->tableWidget->setColumnWidth(2, 100);
    ui->tableWidget->setColumnWidth(3, 100);
    ui->tableWidget->setColumnWidth(4, 240);
    ui->tableWidget->setColumnWidth(5, 100);

    ui->LineEdit_startTime->setEnabled(false);
    ui->LineEdit_endTime->setEnabled(false);
    QString button_style="QPushButton{  border-radius: 0px;  border: 0px}";
    ui->pushButton_startTime->setStyleSheet(button_style);
    ui->pushButton_startTime->setFocusPolicy(Qt::NoFocus);

    ui->pushButton_endTime->setStyleSheet(button_style);
    ui->pushButton_endTime->setFocusPolicy(Qt::NoFocus);
    QIcon ico(":/images/calendar.png");
    ui->pushButton_startTime->setIcon(ico);
    ui->pushButton_startTime->setIconSize(QSize(25,25));

    ui->pushButton_endTime->setIcon(ico);
    ui->pushButton_endTime->setIconSize(QSize(25,25));

    ui->calendarWidget_start->setFirstDayOfWeek(Qt::Monday);
    ui->calendarWidget_start->setHorizontalHeaderFormat(QCalendarWidget::ShortDayNames);
    ui->calendarWidget_start->setVerticalHeaderFormat(QCalendarWidget::NoVerticalHeader);
    ui->calendarWidget_start->setGridVisible(true);
    ui->calendarWidget_start->setSelectionMode(QCalendarWidget::SingleSelection);

    ui->calendarWidget_end->setFirstDayOfWeek(Qt::Monday);
    ui->calendarWidget_end->setHorizontalHeaderFormat(QCalendarWidget::ShortDayNames);
    ui->calendarWidget_end->setVerticalHeaderFormat(QCalendarWidget::NoVerticalHeader);
    ui->calendarWidget_end->setGridVisible(true);
    ui->calendarWidget_end->setSelectionMode(QCalendarWidget::SingleSelection);

    ui->calendarWidget_start->hide();
    ui->calendarWidget_end->hide();
}
void ParcelManagementWidget::initConnect()
{
    connect(ui->tableWidget, SIGNAL(cellClicked(int,int)), this, SLOT(clickCell(int, int)));
    connect(ui->calendarWidget_start, SIGNAL(clicked(QDate)), this, SLOT(slot_calendarStartTimeClicked(QDate)));
    connect(ui->calendarWidget_end, SIGNAL(clicked(QDate)), this, SLOT(slot_calendarEndTimeClicked(QDate)));
}
void ParcelManagementWidget::on_pushButton_startTime_clicked()
{
    ui->calendarWidget_start->show();
    QDate cdate=QDate::currentDate();
    ui->calendarWidget_start->setSelectedDate(cdate);
}
void ParcelManagementWidget::on_pushButton_endTime_clicked()
{
    ui->calendarWidget_end->show();
    QDate cdate=QDate::currentDate();
    ui->calendarWidget_end->setSelectedDate(cdate);
}
void ParcelManagementWidget::slot_calendarStartTimeClicked(QDate date)
{
    sleep(400);
    QString dtstr=date.toString("yyyy-MM-dd");
    ui->LineEdit_startTime->setText(dtstr);
    ui->calendarWidget_start->hide();
}
void ParcelManagementWidget::slot_calendarEndTimeClicked(QDate date)
{
    sleep(400);
    QString dtstr=date.toString("yyyy-MM-dd");
    ui->LineEdit_endTime->setText(dtstr);
    ui->calendarWidget_end->hide();
}
void ParcelManagementWidget::initData()
{
    parcelID.clear();
    bookID.clear();
    name.clear();
    phone.clear();
    parcelState.clear();
    deliverySchedule.clear();
    startTime.clear();
    endTime.clear();
}
void ParcelManagementWidget::resetDisplayData()
{
    ui->LineEdit_bookID->clear();
    ui->LineEdit_name->clear();
    ui->LineEdit_parcelID->clear();
    ui->LineEdit_phone->clear();
    ui->LineEdit_startTime->clear();
    ui->LineEdit_endTime->clear();

    ui->comboBox_parcelState->setCurrentIndex(0);
    ui->comboBox_parcelSchedule->setCurrentIndex(0);

    ui->tableWidget->clear();
    ui->tableWidget->setColumnCount(6);
    ui->tableWidget->setRowCount(0);
    ui->tableWidget->setHorizontalHeaderLabels(QStringList() <<"运单号"<< "订单号" <<"包裹状态"<< "收货人"  <<"送货时间"<<"送货班次");
}
void ParcelManagementWidget::clickCell(int row, int col)
{
    if(col==0)
    {
        QString parcelID;
        parcelID=ui->tableWidget->item(row,0)->text();
        qDebug()<<parcelID;

        parcelInfoWidget.getParcelID(parcelID);
        if(parcelInfoWidget.queryParcelnfo() == true)
        {
           parcelInfoWidget.show();
        }
    }
}
void ParcelManagementWidget::on_pushButton_query_reset_clicked()
{
    ui->comboBox_parcelSchedule->setCurrentIndex(0);
    ui->comboBox_parcelState->setCurrentIndex(0);

    ui->LineEdit_bookID->clear();
    ui->LineEdit_name->clear();
    ui->LineEdit_parcelID->clear();
    ui->LineEdit_phone->clear();
    ui->LineEdit_startTime->clear();
    ui->LineEdit_endTime->clear();

    ui->tableWidget->clear();
    ui->tableWidget->setColumnCount(6);
    ui->tableWidget->setRowCount(0);
    ui->tableWidget->setHorizontalHeaderLabels(QStringList() <<"运单号"<< "订单号" <<"包裹状态"<< "收货人"  <<"送货时间"<<"送货班次");
}
QString ParcelManagementWidget::parcelStatusMap(QString parcelStatusTmp)
{
    QString parcelState;
    if(parcelStatusTmp == "")
        parcelState = "";
    if(parcelStatusTmp == "未装车")
        parcelState = "000";
    if(parcelStatusTmp == "已装车")
        parcelState = "100";
    if(parcelStatusTmp == "已出发")
        parcelState = "200";
    if(parcelStatusTmp == "滞留")
        parcelState = "500";
    if(parcelStatusTmp == "拒收")
        parcelState = "400";
    if(parcelStatusTmp == "本人签收")
        parcelState = "301";
    if(parcelStatusTmp == "他人签收")
        parcelState = "302";
    if(parcelStatusTmp == "人工配送")
        parcelState = "600";
    return parcelState;
}
QString ParcelManagementWidget::parcelStatusMap_inv(QString parcelStatusTmp)
{
    QString parcelState;
    if(parcelStatusTmp == "000")
        parcelState = "未装车";
    if(parcelStatusTmp == "100")
        parcelState = "已装车";
    if(parcelStatusTmp == "200")
        parcelState = "已出发";
    if(parcelStatusTmp == "500")
        parcelState = "滞留";
    if(parcelStatusTmp == "400")
        parcelState = "拒收";
    if(parcelStatusTmp == "301")
        parcelState = "本人签收";
    if(parcelStatusTmp == "302")
        parcelState = "他人签收";
    if(parcelStatusTmp == "600")
        parcelState = "人工配送";
    return parcelState;
}
void ParcelManagementWidget::on_pushButton_query_clicked()
{
    //get QUERY condition from UI
    parcelID = ui->LineEdit_parcelID->text();
    bookID = ui->LineEdit_bookID->text();
    name = ui->LineEdit_name->text();
    phone = ui->LineEdit_phone->text();
    parcelState = parcelStatusMap(ui->comboBox_parcelState->currentText());
    startTime = ui->LineEdit_startTime->text();
    endTime = ui->LineEdit_endTime->text();
    deliverySchedule = ui->comboBox_parcelSchedule->currentText();

    //check if legal
    //if( checkParcelID()&& checkBookID() && checkPhoneNum() && !checkIsEmpty())
    if( !checkIsEmpty())
    {
        //query from DB
        int db_State = getAllParclesInfoFromDB();
        if(db_State == 1)
            updateTableWidget();
        else if(db_State == -1)
            QMessageBox::information(NULL, "提示", "数据库中没有此包裹,\n请核对相关信息后查询 !\n");
        else
            return;
    }
    else
    {
        if(!checkParcelID())
            QMessageBox::information(NULL, "提示", "请输入正确的运单号 !\n");
        else if(!checkBookID())
            QMessageBox::information(NULL, "提示", "请输入正确的订单号 !\n");
        else if(!checkPhoneNum())
            QMessageBox::information(NULL, "提示", "请输入正确的手机号 !\n");
        else
            QMessageBox::information(NULL, "提示", "输入信息为空 !\n");
    }

}
bool ParcelManagementWidget::checkParcelID()
{
    qDebug()<<parcelID;
    if(parcelID.length() == 0)
        return true;
    else
    {
        if(parcelID.length()!= 10)
            return false;
        else
        {
            for(int i=0; i<parcelID.length(); i++)
            {
                if(parcelID[i]>='0' && parcelID[i]<='9');
                else
                    return false;
            }
        }
        return true;
    }
}
bool ParcelManagementWidget::checkBookID()
{
    if(bookID.length() == 0)
        return true;
    else
    {
        if(bookID.length()!= 14)
            return false;
        else
        {
            for(int i=0; i<bookID.length(); i++)
            {
                if(bookID[i]>='0' && bookID[i]<='9');
                else
                    return false;
            }
        }
        return true;
    }
}
bool ParcelManagementWidget::checkPhoneNum()
{
    if(phone.length() == 0)
        return true;
    else
    {
        if(phone.length()!= 11)
            return false;
        else
        {
            for(int i=0; i<phone.length(); i++)
            {
                if(phone[i]>='0' && phone[i]<='9');
                else
                    return false;
            }
        }
        return true;
    }
}
bool ParcelManagementWidget::checkIsEmpty()
{
    if(parcelID.length() == 0 && bookID.length() ==0 && name.length() == 0 && phone.length()==0 && parcelState.length() == 0 &&
            startTime.length() == 0 && endTime.length() ==0 && deliverySchedule.length() ==0)
        return true;
    else
        return false;

}
bool ParcelManagementWidget::checkQueryReslut(vector<vector<string> > & result)
{
    int sum = 0;
    for(int i=0; i<result.size();i++)
        sum += result[i].size();
    int averageSize = sum/result.size();
    for(int j=0; j<result.size();j++)
    {
        if(result[j].size() != averageSize)
        {
            qDebug()<<"check query result is false";
            return false;
        }
    }
    return true;
    qDebug()<<"check query result is ture";
}
int ParcelManagementWidget::getAllParclesInfoFromDB()
{
    MyDB mydb;
    if( !mydb.initDB("localhost","root","vip","db_vip"))
    {
        QMessageBox::information(NULL, "提示", "数据库连接失败 !\n");
        return 2;
    }
    else
    {
        //query table of transport_sn
        string query = "select transport_sn,vp_order_sn,status,receiver_name,time,time_slot_id from db_vip.transport_sns where ";
        string condition = getQueryCondtion();
        std::cout<<condition<<endl;
        query += condition;
        qDebug()<<QString::fromStdString(query);
        vector<vector<string> > result_transport_sn;
        if( !mydb.exeSQL(query, result_transport_sn ))
        {
            QMessageBox::information(NULL, "提示", "查询数据失败 !\n");
            return 2;
        }
        else
        {
            parcelIDClusters.clear();
            bookIDClusters.clear();
            parcelStateClusters.clear();
            nameClusters.clear();
            deliveryScheduleClusters.clear();
            deliveryTimeClusters.clear();

            parcelNum = result_transport_sn[0].size();
            // check if each column size is same
            qDebug()<<"query data";
            qDebug()<<result_transport_sn[4].size();
            qDebug()<<result_transport_sn[5].size();
            if(checkQueryReslut(result_transport_sn))
            {
                qDebug()<<"have checked";
                for(int i=0;i<result_transport_sn[0].size(); i++)
                {
                    parcelIDClusters.push_back(QString::fromStdString(result_transport_sn[0][i]));
                    bookIDClusters.push_back(QString::fromStdString(result_transport_sn[1][i]));
                    parcelStateClusters.push_back(QString::fromStdString(result_transport_sn[2][i]));
                    nameClusters.push_back(QString::fromStdString(result_transport_sn[3][i]));
                    deliveryTimeClusters.push_back(QString::fromStdString(result_transport_sn[4][i]));
                    deliveryScheduleClusters.push_back(QString::fromStdString(result_transport_sn[5][i]));
                }
            }
            else
            {
                QMessageBox::information(NULL, "提示", "查询部分数据失败 !\n");
                return 2;
            }
        }
    }

    if(parcelIDClusters.size() == 0)
        return -1;
    else
        return 1;

}
string ParcelManagementWidget::getQueryCondtion()
{
    QString temp;
    if(parcelID.size() != 0)
    {
        if(temp.size() != 0)
            temp += " and ";
        temp += " transport_sn=";
        temp += "\'";
        temp += parcelID;
        temp += "\'";
        parcelID.clear();
    }
    if(bookID.size() != 0)
    {
        if(temp.size() != 0)
            temp += " and ";
        temp += " vp_order_sn=";
        temp += "\'";
        temp += bookID;
        temp += "\'";
        bookID.clear();
    }
    if(parcelState.size() != 0)
    {
        if(temp.size() != 0)
            temp += " and ";
        temp += " status=";
        temp += "\'";
        temp += parcelState;
        temp += "\'";
        parcelState.clear();
    }
    if(name.size() != 0)
    {
        if(temp.size() != 0)
            temp += " and ";
        temp += " receiver_name=";
        temp += "\'";
        temp += name;
        temp += "\'";
        name.clear();
    }
    if(phone.size() != 0)
    {
        if(temp.size() != 0)
            temp += " and ";
        temp += " receiver_mobile=";
        temp += "\'";
        temp += phone;
        temp += "\'";
        phone.clear();
    }
    if(deliverySchedule.size() != 0)
    {
        if(temp.size() != 0)
            temp += " and ";
        temp += " time_slot_id=";
        temp += "\'";
        temp += deliverySchedule;
        temp += "\'";
        deliverySchedule.clear();
    }

    if(startTime.size() != 0)
    {
        if(temp.size() != 0)
            temp += " and ";
        temp += " time>";
        temp += "\'";
        temp += startTime;
        temp += "\'";
        startTime.clear();
    }
    if(endTime.size() != 0)
    {
        if(temp.size() != 0)
            temp += " and ";
        temp += " time<";
        temp += "\'";
        temp += endTime;
        temp += "\ ";
        temp += "24:60:60";
        temp += "\'";
        endTime.clear();
    }

    return temp.toStdString();
}
void ParcelManagementWidget::updateTableWidget()
{
    ui->tableWidget->clear();
    ui->tableWidget->setColumnCount(6);
    ui->tableWidget->setRowCount(parcelNum);
    ui->tableWidget->setHorizontalHeaderLabels(QStringList() <<"运单号"<< "订单号" <<"包裹状态"<< "收货人" <<"送货时间"<<"送货班次");

    for(int i=0;i<parcelNum;i++)
    {
        QTableWidgetItem *item = new QTableWidgetItem();
        ui->tableWidget->setItem(i, 0, item);
        //item->setBackground(QBrush(QColor(230,130,100)));
        item->setBackground(QBrush(QColor(0, 160, 230)));
        item->setFlags(item->flags() & (~Qt::ItemIsEditable));
        ui->tableWidget->item(i,0)->setText(parcelIDClusters[i]);

        QTableWidgetItem *item1 = new QTableWidgetItem();
        ui->tableWidget->setItem(i, 1, item1);
        item1->setFlags(item1->flags() & (~Qt::ItemIsEditable));
        ui->tableWidget->item(i,1)->setText(bookIDClusters[i]);

        QTableWidgetItem *item2 = new QTableWidgetItem();
        ui->tableWidget->setItem(i, 2, item2);
        item2->setFlags(item2->flags() & (~Qt::ItemIsEditable));
        ui->tableWidget->item(i,2)->setText(parcelStatusMap_inv(parcelStateClusters[i]));

        QTableWidgetItem *item3 = new QTableWidgetItem();
        ui->tableWidget->setItem(i, 3, item3);
        item3->setFlags(item3->flags() & (~Qt::ItemIsEditable));
        ui->tableWidget->item(i,3)->setText(nameClusters[i]);

        QTableWidgetItem *item5 = new QTableWidgetItem();
        ui->tableWidget->setItem(i, 4, item5);
        item5->setFlags(item5->flags() & (~Qt::ItemIsEditable));
        ui->tableWidget->item(i,4)->setText(deliveryTimeClusters[i]);

        QTableWidgetItem *item6 = new QTableWidgetItem();
        ui->tableWidget->setItem(i, 5, item6);
        item6->setFlags(item6->flags() & (~Qt::ItemIsEditable));
        ui->tableWidget->item(i,5)->setText(deliveryScheduleClusters[i]);
    }

}
