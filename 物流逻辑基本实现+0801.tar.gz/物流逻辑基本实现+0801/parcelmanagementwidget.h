#ifndef PARCELMANAGEMENTWIDGET_H
#define PARCELMANAGEMENTWIDGET_H

#include <QWidget>
#include <QDate>
#include <QTime>
#include <QCoreApplication>
#include "parcelinfowidget.h"
#include "detentionreasonwidget.h"
#include "calendarwidget.h"
#include <vector>
#include<string>
namespace Ui {
class ParcelManagementWidget;
}

class ParcelManagementWidget : public QWidget
{
    Q_OBJECT

public:
    explicit ParcelManagementWidget(QWidget *parent = 0);
    ~ParcelManagementWidget();

    void resetDisplayData();

    int getAllParclesInfoFromDB();
    void updateTableWidget();

    void sleep(unsigned int msec)
    {
    QTime dieTime = QTime::currentTime().addMSecs(msec);
    while( QTime::currentTime() < dieTime )
    QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
    }

private:
    void initUi();//初始化界面参数
    void initConnect();//初始化信号和槽连接
    void initData();//初始化参数
    bool checkParcelID();
    bool checkBookID();
    bool checkPhoneNum();
    bool checkIsEmpty();
    std::string getQueryCondtion();
    QString parcelStatusMap(QString);
    QString parcelStatusMap_inv(QString);
    bool checkQueryReslut(std::vector<std::vector<std::string> >&);

    QString parcelID;
    QString bookID;
    QString parcelState;
    QString name;
    QString phone;
    QString startTime;
    QString endTime;
    QString deliverySchedule;

    int parcelNum;
    std::vector<QString> parcelIDClusters;
    std::vector<QString> bookIDClusters;
    std::vector<QString> parcelStateClusters;
    std::vector<QString> nameClusters;
    //std::vector<QString> phoneNumClusters;
    std::vector<QString> deliveryTimeClusters;
    std::vector<QString> deliveryScheduleClusters;

public slots:
    void on_pushButton_query_clicked();
    void on_pushButton_query_reset_clicked();
    void on_pushButton_startTime_clicked();
    void on_pushButton_endTime_clicked();
    void  clickCell(int , int);
    void slot_calendarStartTimeClicked(QDate);
    void slot_calendarEndTimeClicked(QDate);
private:
    Ui::ParcelManagementWidget *ui;
    ParcelInfoWidget parcelInfoWidget;
    CalendarWidget calendarWidget;
};

#endif // PARCELMANAGEMENTWIDGET_H
