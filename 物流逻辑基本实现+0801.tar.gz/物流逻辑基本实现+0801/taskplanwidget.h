#ifndef TASKPLANWIDGET_H
#define TASKPLANWIDGET_H

#include <QWidget>
#include "task_plan.h"
namespace Ui {
class TaskPlanWidget;
}

class TaskPlanWidget : public QWidget
{
    Q_OBJECT

public:
    explicit TaskPlanWidget(QWidget *parent = 0);
    ~TaskPlanWidget();
    void initUi();//初始化界面参数
    void initConnect();//初始化信号和槽连接

    void setPixmapPlanning();
    void setPixmapPlanSuccess();
    void TaskPlanInfoShow(result planRes);
private:
    Ui::TaskPlanWidget *ui;
};

#endif // TASKPLANWIDGET_H
