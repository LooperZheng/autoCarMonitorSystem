#ifndef STARTDELIVERYWIDGET_H
#define STARTDELIVERYWIDGET_H

#include <QWidget>
#include <vector>
#include "mydb.h"
namespace Ui {
class StartDeliveryWidget;
}

class StartDeliveryWidget : public QWidget
{
    Q_OBJECT

public:
    explicit StartDeliveryWidget(QWidget *parent = 0);
    ~StartDeliveryWidget();
    int getAllParcleTobeCancellFromDB();
    void updateTableWidget();
    void resetUI();
    void setSecondRefreshUI();
    void setFirstRefreshUI();
    int refreshTimes;

private:
    void initUi();//初始化界面参数
    void initConnect();//初始化信号和槽连接
public slots:
    void on_pushButton_ok_clicked();
    void on_pushButton_start_clicked();
    void on_pushButton_takeOutParcel_clicked();
signals:
    void signal_startTaskPlan();
    void signal_openBox_startDelivery(std::vector<int>);
    void signal_exeSchedulePlanAlgorithm(QString);
private:
    Ui::StartDeliveryWidget *ui;
    int parcelNum;
    std::vector<QString> parcelIDClusters;
    std::vector<QString> nameClusters;
    std::vector<QString> phoneNumClusters;
    std::vector<QString> boxTypeClusters;
    std::vector<QString> boxIDClusters;
    std::vector<QString> boxPosClusters;

    std::vector<int> taskSeq;
};

#endif // STARTDELIVERYWIDGET_H
