#ifndef REJECTIONCHECKWIDGET_H
#define REJECTIONCHECKWIDGET_H

#include <QWidget>
#include <QButtonGroup>
#include "agreerejection.h"
#include "disagreerejection.h"
namespace Ui {
class RejectionCheckWidget;
}

class RejectionCheckWidget : public QWidget
{
    Q_OBJECT

public:
    explicit RejectionCheckWidget(QWidget *parent = 0);
    ~RejectionCheckWidget();

    bool getAllRejectionParcelInfoFromDB();
    void updateTableWidget();

    void getParcelID_vpFromLogistics(QString);
private:
    void initUi();//初始化界面参数
    void initConnect();//初始化信号和槽连接
public slots:
    void on_pushButton_clicked();
private:
    Ui::RejectionCheckWidget *ui;
    AgreeRejection agreeRejection;
    DisagreeRejection disagreeRejection;
    QButtonGroup *m_pButtonGroup;

    std::vector<QString> parcelIDClusters;
    std::vector<QString> parcelID_vpClusters;
    std::vector<QString> nameClusters;
    std::vector<QString> phoneClusters;

    int parcelNum;
    QString parcelID;
    QString parcelID_vp;
};

#endif // REJECTIONCHECKWIDGET_H
