#ifndef PARCELINFOWIDGET_H
#define PARCELINFOWIDGET_H

#include <QWidget>
#include "detentionreasonwidget.h"
namespace Ui {
class ParcelInfoWidget;
}

class ParcelInfoWidget : public QWidget
{
    Q_OBJECT

public:
    explicit ParcelInfoWidget(QWidget *parent = 0);
    ~ParcelInfoWidget();

    void getParcelID(QString str);
    //from DB
    bool queryParcelnfo();
public slots:
    void on_pushButton_man_clicked();
    void on_pushButton_detention_clicked();

private:
    void initUi();//初始化界面参数
    void initConnect();//初始化信号和槽连接

    QString parcelStatusMap_inv(QString);

    QString parcelID;
    QString bookID;
    QString name;
    QString phone;
    QString boxType;
    QString parcelState;
    QString parcelPosition;
    QString bookTime;
    QString bookPlace;
    QString deliveryTime;
    QString deliverySchedule;
    QString deliveryPlace;
    QString receiverAddress;

private:
    Ui::ParcelInfoWidget *ui;
    DetentionReasonWidget detentionReasonWidget;
};

#endif // PARCELINFOWIDGET_H
