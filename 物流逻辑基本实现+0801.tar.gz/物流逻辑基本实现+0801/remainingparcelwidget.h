#ifndef REMAININGPARCELWIDGET_H
#define REMAININGPARCELWIDGET_H

#include <QWidget>
#include <QButtonGroup>
#include "mydb.h"
namespace Ui {
class RemainingParcelWidget;
}

class RemainingParcelWidget : public QWidget
{
    Q_OBJECT

public:
    explicit RemainingParcelWidget(QWidget *parent = 0);
    ~RemainingParcelWidget();

    int getAllRemainingParcelInfoFromDB();
    void updateTableWidget();
    void updateParcelStateInDB_handle();
    void resetUI();
private:
    void initUi();//初始化界面参数
    void initConnect();//初始化信号和槽连接
    bool checkParcelID(QString parcelID);
public slots:
    void on_pushButton_pickUpParcel_clicked();
    void onButtonClicked(QAbstractButton*);
    void getParcelIDFromScanner();
    void getParcelInfo();
signals:
    void signal_openBox_remainingParcel(std::vector<int>);
private:
    Ui::RemainingParcelWidget *ui;
    int parcelNum;
    QString parcelID;
    QString parcelID_scanner;
    QString parcelStatus;
    QString parcelInfo;
    std::vector<QString> parcelIDClusters;
    std::vector<QString> nameClusters;
    std::vector<QString> parcelTypeClusters;
    std::vector<QString> boxPosClusters;
    std::vector<QString> boxTypeClusters;

    std::vector<QString> parcelIDClusters_handle;
    std::vector<QString> nameClusters_handle;
    std::vector<QString> parcelTypeClusters_handle;
    std::vector<QString> boxPosClusters_handle;

    QButtonGroup *m_pButtonGroup;
};

#endif // REMAININGPARCELWIDGET_H
