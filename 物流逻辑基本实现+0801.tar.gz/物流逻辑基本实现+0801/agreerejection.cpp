#include "agreerejection.h"
#include "ui_agreerejection.h"
#include <QDesktopWidget>
#include <QDebug>
#include <QMessageBox>
#include "mydb.h"
AgreeRejection::AgreeRejection(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AgreeRejection)
{
    ui->setupUi(this);
    initUi();//初始化界面参数
    initConnect();//初始化信号和槽连接
}

AgreeRejection::~AgreeRejection()
{
    delete ui;
}
void AgreeRejection::initUi()
{
    // 固定窗口的大小
    this->setFixedSize(this->width(), this->height());
    this->setWindowTitle("拒收审核");
    //设置弹出窗口的位置（在屏幕中央）
    QDesktopWidget *deskdop=QApplication::desktop();
    this->move((deskdop->width()-this->width())/2,      (deskdop->height()-this->height())/2);
    //初始化下拉列表
    QString  itemText = "商品不合适";
    ui->comboBox->insertItem(0,itemText);
    itemText = "电话拒收";
    ui->comboBox->insertItem(1,itemText);
    itemText = "唯品会通知退回";
    ui->comboBox->insertItem(2,itemText);
    itemText = "联系不上收货人";
    ui->comboBox->insertItem(3,itemText);
    itemText = "商品质量问题";
    ui->comboBox->insertItem(4,itemText);
    itemText = "保留时效过长";
    ui->comboBox->insertItem(5,itemText);
    itemText = "重复订购";
    ui->comboBox->insertItem(6,itemText);
    itemText = "不在收货地址";
    ui->comboBox->insertItem(7,itemText);
    itemText = "破损";
    ui->comboBox->insertItem(8,itemText);
    itemText = "错漏发";
    ui->comboBox->insertItem(9,itemText);
    itemText = "延误配送";
    ui->comboBox->insertItem(10,itemText);
}
void AgreeRejection::initConnect()
{

}
void AgreeRejection::getParcelID(std::vector<QString> IDClusters)
{
    parcelIDClusters = IDClusters;
}
int AgreeRejection::getParcelID_pj()
{
    // from app socket
    parcelID_pj = "903139";
    return 1;
}
void AgreeRejection::getAgreeRejectionReason()
{
    if(ui->lineEdit->text().size() == 0)
        reason = ui->comboBox->currentText();
    else
        reason = ui->lineEdit->text();
}
void AgreeRejection::on_pushButton_clicked()
{
    //write to DB
    getAgreeRejectionReason();
    if(getParcelID_pj() == 1)
    {
        //insert to DB
        MyDB mydb;
        if( !mydb.initDB("localhost","root","vip","db_vip"))
        {
            QMessageBox::information(NULL, "提示", "数据库连接失败 !\n");
            return;
        }
        else
        {
            string insert = "insert into db_vip.order_rejections(pj_order_sn,rejection_or_no,rejection_reason)  values";
            insert += "\(";
            insert += "\'";
            insert += parcelID_pj.toStdString();
            insert += "\'";
            insert += "\,";
            insert += "\'";
            insert += "是";
            insert += "\'";
            insert += "\,";
            insert += "\'";
            insert += reason.toStdString();
            insert += "\'";
            insert += "\)";
            qDebug()<<QString::fromStdString(insert);
            if( !mydb.insertData(insert))
            {
                QMessageBox::information(NULL, "提示", "数据库插入拒收原因失败 !\n");
                return;
            }
            else
            {
                qDebug()<<"insert parcel rejection reason  success";
                ui->comboBox->setCurrentIndex(0);
                ui->lineEdit->clear();
                this->close();
                return;
            }
        }
    }
    else
    {
        qDebug()<<"get parcel ID pj fail";
        return;
    }
}
