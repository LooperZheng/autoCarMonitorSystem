#include "statisticalreportwidget.h"
#include "ui_statisticalreportwidget.h"
#include <QDesktopWidget>
#include <QDebug>
#include <QMessageBox>
StatisticalReportWidget::StatisticalReportWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::StatisticalReportWidget)
{
    ui->setupUi(this);
    initUi();//初始化界面参数
    initConnect();//初始化信号和槽连接
}

StatisticalReportWidget::~StatisticalReportWidget()
{
    delete ui;
}
void StatisticalReportWidget::initUi()
{
    // 固定窗口的大小
    this->setFixedSize(this->width(), this->height());
    this->setWindowTitle("统计报表");
    //设置弹出窗口的位置（在屏幕中央）
    QDesktopWidget *deskdop=QApplication::desktop();
    this->move((deskdop->width()-this->width())/2,      (deskdop->height()-this->height())/2);

    QString  itemText;
    itemText = "";
    ui->comboBox_state->insertItem(0,itemText);
    itemText = "班次一";
    ui->comboBox_state->insertItem(1,itemText);
    itemText = "班次二";
    ui->comboBox_state->insertItem(2,itemText);
    itemText = "班次三";
    ui->comboBox_state->insertItem(3,itemText);
    itemText = "班次四";
    ui->comboBox_state->insertItem(4,itemText);

    itemText = "";
    ui->comboBox_parcelInfo->insertItem(0,itemText);
    itemText = "验收";
    ui->comboBox_parcelInfo->insertItem(1,itemText);
    itemText = "签收";
    ui->comboBox_parcelInfo->insertItem(2,itemText);
    itemText = "拒收";
    ui->comboBox_parcelInfo->insertItem(3,itemText);
    itemText = "滞留";
    ui->comboBox_parcelInfo->insertItem(4,itemText);
    itemText = "改班次";
    ui->comboBox_parcelInfo->insertItem(5,itemText);
    itemText = "改为人工配送";
    ui->comboBox_parcelInfo->insertItem(6,itemText);
    itemText = "10分钟未取";
    ui->comboBox_parcelInfo->insertItem(7,itemText);

    itemText = "";
    ui->comboBox_index->insertItem(0,itemText);
    itemText = "订单数量";
    ui->comboBox_index->insertItem(1,itemText);
    itemText = "包裹数量";
    ui->comboBox_index->insertItem(2,itemText);
    itemText = "配送次数";
    ui->comboBox_index->insertItem(3,itemText);


    itemText = "";
    ui->comboBox_queryTime->insertItem(0,itemText);
    itemText = "每天";
    ui->comboBox_queryTime->insertItem(1,itemText);
    itemText = "每周";
    ui->comboBox_queryTime->insertItem(2,itemText);
    itemText = "每月";
    ui->comboBox_queryTime->insertItem(3,itemText);
    itemText = "每年";
    ui->comboBox_queryTime->insertItem(4,itemText);

    itemText = "";
    ui->comboBox_station->insertItem(0,itemText);
    itemText = "图书馆";
    ui->comboBox_station->insertItem(1,itemText);
    itemText = "行政楼";
    ui->comboBox_station->insertItem(2,itemText);
    itemText = "电信楼";
    ui->comboBox_station->insertItem(3,itemText);
    //table Widget
    ui->tableWidget->setColumnCount(7);
    ui->tableWidget->setRowCount(9);
    ui->tableWidget->setHorizontalHeaderLabels(QStringList() <<"运单号"<< "订单号" <<"包裹状态"<< "收货人" << "手机号" <<"送货时间"<<"送货班次");

    QTableWidgetItem *item = new QTableWidgetItem();
    ui->tableWidget->setItem(0, 0, item);
    item->setFlags(item->flags() & (~Qt::ItemIsEditable));
    ui->tableWidget->item(0,0)->setText(QString::number(12345678911111));

    QTableWidgetItem *item1 = new QTableWidgetItem();
    ui->tableWidget->setItem(0, 1, item1);
    item1->setFlags(item1->flags() & (~Qt::ItemIsEditable));
    ui->tableWidget->item(0,1)->setText("1234786293892143");

    QTableWidgetItem *item2 = new QTableWidgetItem();
    ui->tableWidget->setItem(0, 2, item2);
    item2->setFlags(item2->flags() & (~Qt::ItemIsEditable));
    ui->tableWidget->item(0,2)->setText("签收");

    QTableWidgetItem *item3 = new QTableWidgetItem();
    ui->tableWidget->setItem(0, 3, item3);
    ui->tableWidget->setColumnWidth(0, 150);
    ui->tableWidget->setColumnWidth(1, 150);
    ui->tableWidget->setColumnWidth(4, 120);
    ui->tableWidget->setColumnWidth(5, 190);
    ui->tableWidget->setColumnWidth(6, 80);
    item3->setFlags(item3->flags() & (~Qt::ItemIsEditable));
    ui->tableWidget->item(0,3)->setText("张小明");

    QTableWidgetItem *item4 = new QTableWidgetItem();
    ui->tableWidget->setItem(0, 4, item4);
    item4->setFlags(item4->flags() & (~Qt::ItemIsEditable));
    ui->tableWidget->item(0,4)->setText("13167898796");

    QTableWidgetItem *item5 = new QTableWidgetItem();
    ui->tableWidget->setItem(0, 5, item5);
    item5->setFlags(item5->flags() & (~Qt::ItemIsEditable));
    ui->tableWidget->item(0,5)->setText("2017/05/07/11:30-12:30");

    QTableWidgetItem *item6 = new QTableWidgetItem();
    ui->tableWidget->setItem(0, 6, item6);
    item6->setFlags(item6->flags() & (~Qt::ItemIsEditable));
    ui->tableWidget->item(0,6)->setText("2");

}
void StatisticalReportWidget::initConnect()
{

}
void StatisticalReportWidget::resetDisplayData()
{
    ui->comboBox_index->setCurrentIndex(0);
    ui->comboBox_parcelInfo->setCurrentIndex(0);
    ui->comboBox_queryTime->setCurrentIndex(0);
    ui->comboBox_state->setCurrentIndex(0);
    ui->comboBox_station->setCurrentIndex(0);

    ui->tableWidget->clear();
}
bool StatisticalReportWidget::checkIsEmpty()
{
    if(parcelInfo.length() == 0 && parcelState.length() ==0 && queryIndex.length() == 0 && queryTime.length()==0 && queryStation.length() == 0)
        return true;
    else
        return false;
}
void StatisticalReportWidget::on_pushButton_query_clicked()
{
    parcelInfo = ui->comboBox_parcelInfo->currentText();
    parcelState = ui->comboBox_state->currentText();
    queryIndex = ui->comboBox_index->currentText();
    queryStation = ui->comboBox_station->currentText();
    queryTime = ui->comboBox_queryTime->currentText();

    if(checkIsEmpty())
        QMessageBox::information(NULL, "提示", "输入信息为空 !\n");
    else
        getQueryParcelInfoFromDB();
        updateTableWidget();
}
void StatisticalReportWidget::on_pushButton_reset_clicked()
{
    ui->comboBox_index->setCurrentIndex(0);
    ui->comboBox_parcelInfo->setCurrentIndex(0);
    ui->comboBox_queryTime->setCurrentIndex(0);
    ui->comboBox_state->setCurrentIndex(0);
    ui->comboBox_station->setCurrentIndex(0);
}
void StatisticalReportWidget::on_pushButton_output_clicked()
{
    //socket to logistics
    QString msg = "test";
    emit signal_exeOutputTable(msg);
}
int StatisticalReportWidget::getQueryParcelInfoFromDB()
{
    MyDB mydb;
    if( !mydb.initDB("localhost","root","vip","db_vip"))
    {
        QMessageBox::information(NULL, "提示", "数据库连接失败 !\n");
        return 2;
    }
    else
    {
        //query table of transport_sn
        string query = "select transport_sn,vp_order_sn,status,receiver_name from db_vip.transport_sns ";
        vector<vector<string> > result_transport_sn;
        if( !mydb.exeSQL(query, result_transport_sn ))
        {
            QMessageBox::information(NULL, "提示", "查询数据失败 !\n");
            return 2;
        }
        else
        {

        }
    }
}
void  StatisticalReportWidget::updateTableWidget()
{

}
