﻿#include "remainingparcelwidget.h"
#include "ui_remainingparcelwidget.h"
#include <QDesktopWidget>
#include <QDebug>
#include <QMessageBox>
#include <QList>
#define TEXT_COLOR  QColor(255,12,12)
RemainingParcelWidget::RemainingParcelWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::RemainingParcelWidget)
{
    ui->setupUi(this);
    initUi();//初始化界面参数
    initConnect();//初始化信号和槽连接
}

RemainingParcelWidget::~RemainingParcelWidget()
{
    delete ui;
}
void RemainingParcelWidget::initUi()
{
    // 固定窗口的大小
    this->setFixedSize(this->width(), this->height());

    this->setWindowTitle("包裹回收");

    //设置弹出窗口的位置（在屏幕中央）
    QDesktopWidget *deskdop=QApplication::desktop();
    this->move((deskdop->width()-this->width())/2,(deskdop->height()-this->height())/2);

    ui->textBrowser_parcelInfo->clear();

    ui->lineEdit_parcelID->setDisabled(true);
    ui->radioButton_handleInput->setDisabled(true);
    ui->radioButton_scanner->setChecked(true);
    ui->radioButton_scanner->setDisabled(true);
    ui->pushButton_query->setDisabled(true);

    m_pButtonGroup = new QButtonGroup(this);
    m_pButtonGroup->addButton(ui->radioButton_handleInput);
    m_pButtonGroup->addButton(ui->radioButton_scanner);

    //table Widget
    ui->tableWidget->setColumnCount(4);
    ui->tableWidget->setRowCount(5);
    ui->tableWidget->setHorizontalHeaderLabels(QStringList() <<"运单号"<< "收货人" << "箱格位置" <<"包裹类型");

    ui->tableWidget->setColumnWidth(0, 150);



    QTableWidgetItem *item = new QTableWidgetItem();
    ui->tableWidget->setItem(0, 0, item);
    item->setFlags(item->flags() & (~Qt::ItemIsEditable));
    ui->tableWidget->item(0,0)->setText(QString::number(12345678911111));

    QTableWidgetItem *item1 = new QTableWidgetItem();
    ui->tableWidget->setItem(0, 1, item1);
    item1->setFlags(item1->flags() & (~Qt::ItemIsEditable));
    ui->tableWidget->item(0,1)->setText("张小明");

    QTableWidgetItem *item2 = new QTableWidgetItem();
    ui->tableWidget->setItem(0, 2, item2);
    item2->setFlags(item2->flags() & (~Qt::ItemIsEditable));
    ui->tableWidget->item(0,2)->setText("A1,A2");

    QTableWidgetItem *item3 = new QTableWidgetItem();
    ui->tableWidget->setItem(0, 3, item3);
    item3->setFlags(item3->flags() & (~Qt::ItemIsEditable));
    ui->tableWidget->item(0,3)->setText("重新预约");
}
void RemainingParcelWidget::resetUI()
{
    ui->textBrowser_parcelInfo->clear();
    ui->lineEdit_parcelID->clear();

    ui->lineEdit_parcelID->setDisabled(true);
    ui->radioButton_handleInput->setDisabled(true);
    ui->radioButton_scanner->setChecked(true);
    ui->radioButton_scanner->setDisabled(true);
    ui->pushButton_query->setDisabled(true);
}
void RemainingParcelWidget::initConnect()
{
    connect(ui->lineEdit_parcelID, SIGNAL( returnPressed()), this, SLOT(getParcelIDFromScanner()));
    connect(ui->pushButton_query, SIGNAL(clicked()), this, SLOT(getParcelInfo()));
    connect(m_pButtonGroup, SIGNAL(buttonClicked(QAbstractButton *)),this, SLOT(onButtonClicked(QAbstractButton*)));
}
void RemainingParcelWidget::on_pushButton_pickUpParcel_clicked()
{
    if(boxTypeClusters.size() == 0)
        QMessageBox::information(NULL, "提示", "没有要回收的包裹\n车门无需打开 !\n");
    else
    {
        // 使能控件
        ui->lineEdit_parcelID->setDisabled(false);
        ui->radioButton_handleInput->setDisabled(false);
        ui->radioButton_scanner->setDisabled(false);
        ui->pushButton_query->setDisabled(false);

        ui->lineEdit_parcelID->setFocus();
        ui->radioButton_scanner->setChecked(true);
        ui->pushButton_query->setDisabled(true);

        //获得需要打开车门的信息
        std::vector<int> boxIndex;
        //数据库货柜信息与实际车辆对应
        for(int i=0; i<boxTypeClusters.size();i++)
        {
            //box id just for  test
            QString boxIDSeg = "2,3,4";
            //QString boxIDSeg = boxPosClusters[i];
            QStringList boxIdList;
            boxIdList =  boxIDSeg.split(',');
            if(boxTypeClusters[i]=="A")
            {
                for(int j=0;j<boxIdList.size();j++)
                {
                    boxIndex.push_back(boxIdList[j].toInt());
                    //qDebug()<<boxIndex[j];
                }
            }
            if(boxTypeClusters[i]=="B")
            {
                int offset_B = 8;
                for(int j=0;j<boxIdList.size();j++)
                {
                    boxIndex.push_back(boxIdList[j].toInt()+offset_B);
                }
            }
            if(boxTypeClusters[i]=="C")
            {
                int offset_C = 16;
                for(int j=0;j<boxIdList.size();j++)
                {
                    boxIndex.push_back(boxIdList[j].toInt()+offset_C);
                }
            }
        }
        emit signal_openBox_remainingParcel(boxIndex);
    }
}
bool RemainingParcelWidget::checkParcelID(QString parcelID)
{
    qDebug()<<parcelID;
    if(parcelID.length() == 0)
        return false;
    else
    {
        if(parcelID.length()!= 10)
            return false;
        else
        {
            for(int i=0; i<parcelID.length(); i++)
            {
                if(parcelID[i]>='0' && parcelID[i]<='9');
                else
                    return false;
            }
        }
        return true;
    }
}
int RemainingParcelWidget::getAllRemainingParcelInfoFromDB()
{
    //get from DB
    QString parcelID;
    QString name;
    QString parcelType;
    QString boxPos;

    parcelIDClusters_handle.clear();
    nameClusters_handle.clear();
    boxPosClusters_handle.clear();
    parcelIDClusters_handle.clear();

    MyDB mydb;
    if( !mydb.initDB("localhost","root","vip","db_vip"))
    {
        QMessageBox::information(NULL, "提示", "数据库连接失败 !\n");
        return 2;
    }
    else
    {
        //query table of transport_sn
        //运单状态, status，enum(未装车[000]，已装车[100]，已出发[200]，
        //滞留[500]，拒收[400]，本人签收[301]，他人签收[302]，人工配送[600[按照品骏接口设计文档设置，
        //在21.21.1.2.6.5中feedbackStatus, 30-签收，40-拒收，50-滞留，signType,0-本人签收，1-他人签收]]) default 未装车 or status='400' or status='400'
        string query = "select transport_sn,receiver_name,status,box_type from db_vip.transport_sns where status='200' or status='400' or status='600' ";
        vector<vector<string> > result_transport_sn;
        if( !mydb.exeSQL(query, result_transport_sn ))
        {
            QMessageBox::information(NULL, "提示", "查询数据失败 !\n");
            return 2;
        }
        else
        {
            if(result_transport_sn[0].size() == 0)
            {
                qDebug()<<"no remaining parcel";
                return -1;
            }
            else
            {
                parcelIDClusters.clear();
                nameClusters.clear();
                parcelTypeClusters.clear();
                boxPosClusters.clear();
                boxTypeClusters.clear();
                parcelNum = result_transport_sn[0].size();
                for(int i=0;i<result_transport_sn[0].size();i++)
                {
                    parcelIDClusters.push_back(QString::fromStdString(result_transport_sn[0][i]));
                    nameClusters.push_back(QString::fromStdString(result_transport_sn[1][i]));
                    parcelTypeClusters.push_back(QString::fromStdString(result_transport_sn[2][i]));
                    boxTypeClusters.push_back(QString::fromStdString(result_transport_sn[3][i]));
                }

                //query table of ransport_sn_box_assignment
                for(int i = 0; i<parcelNum; i++)
                {
                    string query = "select box_id from db_vip.transport_sn_box_assignment where transport_sn=";
                    vector<vector<string> > result_transport_sn_box_assignment;
                    QString condition = parcelIDClusters[i];
                    query += "\'";
                    query += condition.toStdString();
                    query += "\'";
                    if( !mydb.exeSQL(query, result_transport_sn_box_assignment ))
                    {
                        QMessageBox::information(NULL, "提示", "查询数据失败 !\n");
                        return 2;
                    }
                    else
                    {
                        if(result_transport_sn_box_assignment[0].size() != 0)
                            boxPosClusters.push_back(QString::fromStdString(result_transport_sn_box_assignment[0][0]));
                        else
                            boxPosClusters.push_back(QString("未查询到"));
                    }
                }
                return 1;
            }
        }
    }

}
void RemainingParcelWidget::updateTableWidget()
{
    ui->tableWidget->clear();
    ui->tableWidget->setColumnCount(4);
    ui->tableWidget->setRowCount(parcelNum);
    ui->tableWidget->setHorizontalHeaderLabels(QStringList() <<"运单号"<< "收货人" << "箱格位置" <<"包裹类型");

    for(int i =0; i<parcelIDClusters_handle.size();i++)
    {
        QTableWidgetItem *item = new QTableWidgetItem();
        ui->tableWidget->setItem(i, 0, item);
        item->setFlags(item->flags() & (~Qt::ItemIsEditable));
        item->setTextColor(TEXT_COLOR);
        ui->tableWidget->item(i,0)->setText(parcelIDClusters_handle[i]);

        QTableWidgetItem *item1 = new QTableWidgetItem();
        ui->tableWidget->setItem(i, 1, item1);
        item1->setFlags(item1->flags() & (~Qt::ItemIsEditable));
        item1->setTextColor(TEXT_COLOR);
        ui->tableWidget->item(i,1)->setText(nameClusters_handle[i]);

        QTableWidgetItem *item2 = new QTableWidgetItem();
        ui->tableWidget->setItem(i, 2, item2);
        item2->setFlags(item2->flags() & (~Qt::ItemIsEditable));
        item2->setTextColor(TEXT_COLOR);
        ui->tableWidget->item(i,2)->setText(boxPosClusters_handle[i]);

        QTableWidgetItem *item3 = new QTableWidgetItem();
        ui->tableWidget->setItem(i, 3, item3);
        item3->setFlags(item3->flags() & (~Qt::ItemIsEditable));
        item3->setTextColor(TEXT_COLOR);
        ui->tableWidget->item(i,3)->setText(parcelTypeClusters_handle[i]);
    }
    for(int i =0; i<parcelIDClusters.size();i++)
    {
        int index = 0;
        index = parcelIDClusters_handle.size()+i;

        QTableWidgetItem *item = new QTableWidgetItem();
        ui->tableWidget->setItem(index, 0, item);
        item->setFlags(item->flags() & (~Qt::ItemIsEditable));
        ui->tableWidget->item(index,0)->setText(parcelIDClusters[i]);

        QTableWidgetItem *item1 = new QTableWidgetItem();
        ui->tableWidget->setItem(index, 1, item1);
        item1->setFlags(item1->flags() & (~Qt::ItemIsEditable));
        ui->tableWidget->item(index,1)->setText(nameClusters[i]);

        QTableWidgetItem *item2 = new QTableWidgetItem();
        ui->tableWidget->setItem(index, 2, item2);
        item2->setFlags(item2->flags() & (~Qt::ItemIsEditable));
        ui->tableWidget->item(index,2)->setText(boxPosClusters[i]);

        QTableWidgetItem *item3 = new QTableWidgetItem();
        ui->tableWidget->setItem(index, 3, item3);
        item3->setFlags(item3->flags() & (~Qt::ItemIsEditable));
        ui->tableWidget->item(index,3)->setText(parcelTypeClusters[i]);
    }

}
void RemainingParcelWidget::onButtonClicked(QAbstractButton *)
{
    if(ui->radioButton_handleInput->isChecked() == true)
    {
        ui->pushButton_query->setDisabled(false);
        ui->lineEdit_parcelID->clear();
        ui->lineEdit_parcelID->setFocus();
        ui->textBrowser_parcelInfo->clear();
    }
    if(ui->radioButton_scanner->isChecked() == true)
    {
        ui->pushButton_query->setDisabled(true);
        ui->lineEdit_parcelID->clear();
        ui->lineEdit_parcelID->setFocus();
        ui->textBrowser_parcelInfo->clear();
    }
}

void RemainingParcelWidget::getParcelIDFromScanner()
{
    qDebug()<<"get parcel ID from scanner";
    if(ui->radioButton_handleInput->isChecked() == true)
    {
        ui->lineEdit_parcelID->clear();
        QMessageBox::information(NULL, "提示", "请选择正确的查询方式 !\n");
    }
    else
    {
        parcelID_scanner = ui->lineEdit_parcelID->text();
        ui->lineEdit_parcelID->clear();
        getParcelInfo();
    }
}
void RemainingParcelWidget::getParcelInfo()
{
    if(ui->radioButton_handleInput->isChecked() == true)
        parcelID = ui->lineEdit_parcelID->text();
    else
        parcelID = parcelID_scanner;
    qDebug()<<"get parcel info of remaining";

    if( !checkParcelID(parcelID))
        QMessageBox::information(NULL, "提示", "包裹单号格式不正确 !\n");
    else
    {
        //update parcel in DB
        MyDB mydb;
        if( !mydb.initDB("localhost","root","vip","db_vip"))
        {
            QMessageBox::information(NULL, "提示", "数据库连接失败 !\n");
            return;
        }
        else
        {
            parcelInfo.clear();
            //query info
            string query = "select transport_sn,receiver_name,status,box_type from db_vip.transport_sns where transport_sn=";
            query += "\'";
            query += parcelID.toStdString();
            query += "\'";
            vector<vector<string> > result_transport_sn;
            if( !mydb.exeSQL(query, result_transport_sn))
            {
                QMessageBox::information(NULL, "提示", "查询数据失败 !\n");
                return;
            }
            else
            {
                parcelInfo.append("运单号         : ");
                parcelInfo.append(QString::fromStdString(result_transport_sn[0][0]));
                parcelInfo.append("\n");
                parcelInfo.append("用户名         : ");
                parcelInfo.append(QString::fromStdString(result_transport_sn[1][0]));
                parcelInfo.append("\n");
                parcelInfo.append("运单状态     : ");
                parcelInfo.append(QString::fromStdString(result_transport_sn[2][0]));
                parcelInfo.append("\n");
                parcelStatus = QString::fromStdString(result_transport_sn[2][0]);

                parcelInfo.append("运单箱型     : ");
                parcelInfo.append(QString::fromStdString(result_transport_sn[3][0]));
                parcelInfo.append("\n");
            }
            //query table of transport_sn_box_assignment
            string query_box =  "select box_id from db_vip.transport_sn_box_assignment where transport_sn=";
            query_box += "\'";
            query_box += parcelID.toStdString();
            query_box += "\'";
            vector<vector<string> > result_box;
            if( !mydb.exeSQL(query_box, result_box))
            {
                QMessageBox::information(NULL, "提示", "查询数据失败 !\n");
                return;
            }
            else
            {
                qDebug()<<"query transport_sn_box_assignment ";
                //display
                parcelInfo.append("箱格位置     : ");
                //cout<<result_box[0].size()<<endl;
                if(result_box[0].size()==0)
                {
                    parcelInfo.append("未查询到位置");
                }
                else
                {
                    parcelInfo.append(QString::fromStdString(result_box[0][0]));
                }
            }
            //display on textbrower
            ui->textBrowser_parcelInfo->setText(parcelInfo);

            //update table data
            int index =0;
            for(int i = 0; i<parcelIDClusters.size(); i++)
            {
                if(parcelID == parcelIDClusters[i])
                {
                    index = i;
                    break;
                }
            }
            //update table
            qDebug()<<"index = "<<index;
            if(std::find(parcelIDClusters.begin(),parcelIDClusters.end(), parcelID) != parcelIDClusters.end())
            {
                qDebug()<<parcelIDClusters[index];
                parcelIDClusters_handle.push_back(parcelIDClusters[index]);
                parcelIDClusters.erase(parcelIDClusters.begin()+index);

                nameClusters_handle.push_back(nameClusters[index]);
                nameClusters.erase(nameClusters.begin()+index);

                boxPosClusters_handle.push_back(boxPosClusters[index]);
                boxPosClusters.erase(boxPosClusters.begin()+index);

                parcelTypeClusters_handle.push_back(parcelTypeClusters[index]);
                parcelTypeClusters.erase(parcelTypeClusters.begin()+index);

                updateTableWidget();
                //200的话是没有收的，所以状态要改成000待出发，400是拒收，600是转人工所以应该是不会再送了，状态应该不改
                if( parcelStatus == "200")
                    updateParcelStateInDB_handle();
            }
            else
            {
                if(std::find(parcelIDClusters_handle.begin(),parcelIDClusters_handle.end(), parcelID) != parcelIDClusters_handle.end())
                    QMessageBox::information(NULL, "提示", "该包裹已处理 !");
                else
                    QMessageBox::information(NULL, "提示", "该包裹不是待回收的包裹 !");
            }
        }
    }
}
void RemainingParcelWidget::updateParcelStateInDB_handle()
{
    //update parcel info
    //200的话是没有收的，所以状态要改成000待出发，400是拒收，600是转人工所以应该是不会再送了，状态应该不改
    MyDB mydb;
    if( !mydb.initDB("localhost","root","vip","db_vip"))
    {
        QMessageBox::information(NULL, "提示", "数据库连接失败 !\n");
        return;
    }
    else
    {
        string update = "update db_vip.transport_sns set status='000' where transport_sn=";
        update += "\'";
        update += parcelID.toStdString();
        update += "\'";
        if( !mydb.updateData(update))
        {
            QMessageBox::information(NULL, "提示", "运单状态更新失败 !\n");
            return;
        }
        else
        {
            qDebug()<<"update  parcel status";
            return;
        }
    }
}
