#include "taskplanwidget.h"
#include "ui_taskplanwidget.h"
#include <QDesktopWidget>
#include <QDebug>
#include <QMessageBox>
TaskPlanWidget::TaskPlanWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::TaskPlanWidget)
{
    ui->setupUi(this);
    initUi();//初始化界面参数
    initConnect();//初始化信号和槽连接

}
TaskPlanWidget::~TaskPlanWidget()
{
    delete ui;
}
void TaskPlanWidget::initUi()
{
    // 固定窗口的大小
    this->setFixedSize(this->width(), this->height());
    this->setWindowTitle("任务规划");
    //设置弹出窗口的位置（在屏幕中央）
    QDesktopWidget *deskdop=QApplication::desktop();
    this->move((deskdop->width()-this->width())/2,    (deskdop->height()-this->height())/2);

}
void TaskPlanWidget::initConnect()
{

}
void TaskPlanWidget::setPixmapPlanning()
{
    QPixmap pixmap_planing(":/images/planning.png");
    ui->label_img->setPixmap(pixmap_planing);
}
void TaskPlanWidget::setPixmapPlanSuccess()
{
    QPixmap pixmap_planing(":/images/success.png");
    ui->label_img->setPixmap(pixmap_planing);
}
void TaskPlanWidget::TaskPlanInfoShow(result planRes)
{
    //输出显示规划结果
    QString text;
    text.append("规划结果");
    if( planRes.isValid == true)
    {
        text.append("成功");
        text.append("\n");
        text.append("规划路程：");
        text.append(QString::number(planRes.dis));
        text.append("m\n");
        text.append("预计行驶时间：");
        text.append(QString::number(planRes.dis/20));
        text.append("min\n");
        text.append("路径点个数：");
        text.append(QString::number(planRes.path.size()));
        text.append("\n");
        text.append("任务点个数：");
        text.append(QString::number(planRes.taskSeq.size()));
    }
    else
    {
        text.append("失败");
    }
    ui->textBrowser_res->setText(text);

    //输出显示规划任务序列
    QString taskSeqText;
    for(int i =0; i<planRes.taskSeq.size();i++)
    {
        taskSeqText.append("task_");
        taskSeqText.append(QString::number(planRes.taskSeq[i]));
        taskSeqText.append("\n");
    }
    ui->textBrowser_taskSeq->setText(taskSeqText);
}
