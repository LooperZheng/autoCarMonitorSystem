#include "detentionreasonwidget.h"
#include "ui_detentionreasonwidget.h"
#include <QDesktopWidget>
#include <QDebug>
#include <QMessageBox>
#include "mydb.h"
DetentionReasonWidget::DetentionReasonWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DetentionReasonWidget)
{
    ui->setupUi(this);
    initUi();//初始化界面参数
    initConnect();//初始化信号和槽连接
}

DetentionReasonWidget::~DetentionReasonWidget()
{
    delete ui;
}
void DetentionReasonWidget::initUi()
{
    // 固定窗口的大小
    this->setFixedSize(this->width(), this->height());
    this->setWindowTitle("包裹管理");
    //设置弹出窗口的位置（在屏幕中央）
    QDesktopWidget *deskdop=QApplication::desktop();
    this->move((deskdop->width()-this->width())/2,      (deskdop->height()-this->height())/2);
    //初始化下拉列表
    QString  itemText = "收货人更改收货信息";
    ui->comboBox_detentionReason->insertItem(0,itemText);
    itemText = "暂时联系不上收货人";
    ui->comboBox_detentionReason->insertItem(1,itemText);
    itemText = "收货人更改送货时间";
    ui->comboBox_detentionReason->insertItem(2,itemText);
    itemText = "航班管理,交通意外,恶劣天气等不可抗力因素";
    ui->comboBox_detentionReason->insertItem(3,itemText);
}
void DetentionReasonWidget::initConnect()
{

}
void DetentionReasonWidget::getParcelID( QString ID)
{
    parcelID = ID;
}
int DetentionReasonWidget::getParcelID_pj()
{

    MyDB mydb;
    if( !mydb.initDB("localhost","root","vip","db_vip"))
    {
        QMessageBox::information(NULL, "提示", "数据库连接失败 !\n");
        return 2;
    }
    else
    {
        //query table of transport_sn
        string query = "select pj_order_sn from db_vip.transport_sns where transport_sn=";
        query += "\'";
        query += parcelID.toStdString();
        query += "\'";
        vector<vector<string> > result_transport_sn;
        if( !mydb.exeSQL(query, result_transport_sn ))
        {
            QMessageBox::information(NULL, "提示", "查询数据失败 !\n");
            return 2;
        }
        else
        {
            if(result_transport_sn[0].size()==0)
            {
                QMessageBox::information(NULL, "提示", "没有查找到相应数据 !\n");
                return -1;
            }
            else
            {
                parcelID_pj = QString::fromStdString(result_transport_sn[0][0]);
                return 1;
            }
        }
    }
}
void DetentionReasonWidget::getRententionReason()
{
    if(ui->lineEdit_inputReason->text().size() == 0)
        reason = ui->comboBox_detentionReason->currentText();
    else
        reason = ui->lineEdit_inputReason->text();
}
void DetentionReasonWidget::on_pushButton_yes_clicked()
{
    getRententionReason();
    if(getParcelID_pj() == 1)
    {
        //insert to DB
        MyDB mydb;
        if( !mydb.initDB("localhost","root","vip","db_vip"))
        {
            QMessageBox::information(NULL, "提示", "数据库连接失败 !\n");
            return;
        }
        else
        {
            //insert to table of order_retentions
            string insert = "insert into db_vip.order_retentions(pj_order_sn,retention_reason)  values";
            insert += "\(";
            insert += "\'";
            insert += parcelID_pj.toStdString();
            insert += "\'";
            insert += "\,";
            insert += "\'";
            insert += reason.toStdString();
            insert += "\'";
            insert += "\)";
            qDebug()<<QString::fromStdString(insert);
            if( !mydb.insertData(insert))
            {
                QMessageBox::information(NULL, "提示", "数据库插入滞留原因失败 !\n");
                return;
            }
            else
            {
                qDebug()<<"insert parcel detrntion success";
            }
            //update table of tansport_sns : status = 500(滞留);
            string update = "update db_vip.transport_sns set status='500' where transport_sn=";
            update += "\'";
            update += parcelID.toStdString();
            update += "\'";
            if( !mydb.updateData(update))
            {
                QMessageBox::information(NULL, "提示", "更新 status = 500 (滞留) 失败 !\n");
                return;
            }
            else
            {
                qDebug()<<"update  parcel status to 500 (滞留);";
                ui->comboBox_detentionReason->setCurrentIndex(0);
                ui->lineEdit_inputReason->clear();
                this->close();
                return;
            }
        }
    }
    else
    {
        qDebug()<<"get parcel ID pj fail";
        return;
    }
}
void DetentionReasonWidget::on_pushButton_cancell_clicked()
{
    ui->comboBox_detentionReason->setCurrentIndex(0);
    ui->lineEdit_inputReason->clear();
    this->close();
}
