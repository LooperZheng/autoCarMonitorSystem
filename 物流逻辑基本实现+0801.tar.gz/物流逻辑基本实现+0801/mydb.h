#ifndef MYDB_H
#define MYDB_H
#include <mysql/mysql.h>
#include <string>
#include <vector>
using namespace std;

class MyDB
{
public:
    MyDB();
    ~MyDB();
    bool initDB(string host, string user, string pwd, string db_name);
    bool exeSQL(string sql , std::vector<std::vector<string> > &query_result);
    bool deleteData(string sql);
    bool updateData(string sql);
    bool insertData(string sql);
    MYSQL *connection;
    MYSQL_RES *result;
    MYSQL_ROW row;
};
#endif // MYDB_H
