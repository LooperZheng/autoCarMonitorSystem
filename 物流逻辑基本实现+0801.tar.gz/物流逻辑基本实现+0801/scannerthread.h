#ifndef SCANNERTHREAD_H
#define SCANNERTHREAD_H

#include <QObject>
#include <QThread>
#include <QString>
class ScannerThread : public QThread
{
    Q_OBJECT
public:
    explicit ScannerThread();
    ~ScannerThread();

    void disableScanner();
    void enableScanner();
    void waittingGetParcelID();
    bool checkParcelID(QString);

    bool activeScanner;

    void run();
signals:
    void sig_getParcelID(QString);
};

#endif // SCANNERTHREAD_H
