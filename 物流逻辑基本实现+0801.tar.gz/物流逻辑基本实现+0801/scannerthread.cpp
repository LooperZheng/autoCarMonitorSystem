#include "scannerthread.h"
#include <QDebug>
#include <iostream>
#include <string>
using namespace std;
ScannerThread::ScannerThread()
{

}
ScannerThread::~ScannerThread()
{

}
void ScannerThread::waittingGetParcelID()
{
    while(activeScanner)
    {
        //qDebug()<<"waitting input";
        cout<<"waitting "<<endl;
        string parcelID = "1234";
        std::cin>>parcelID;
        std::cout<<"parcel ID = "<<parcelID<<std::endl;
        if(checkParcelID(QString::fromStdString(parcelID)))
            emit sig_getParcelID(QString::fromStdString(parcelID));

        activeScanner = false;
    }
}
bool ScannerThread::checkParcelID(QString parcelID)
{
    qDebug()<<parcelID;
    if(parcelID.length() == 0)
        return true;
    else
    {
        if(parcelID.length()!= 10)
            return false;
        else
        {
            for(int i=0; i<parcelID.length(); i++)
            {
                if(parcelID[i]>='0' && parcelID[i]<='9');
                else
                    return false;
            }
        }
        return true;
    }
}
void ScannerThread::run()
{
    cout<<"scanner thread run"<<endl;
    activeScanner = true;
    waittingGetParcelID();
}
void ScannerThread::enableScanner()
{

}
void ScannerThread::disableScanner()
{
    activeScanner = false;
}
