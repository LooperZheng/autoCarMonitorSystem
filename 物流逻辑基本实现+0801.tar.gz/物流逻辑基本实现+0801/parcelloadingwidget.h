#ifndef PARCELLOADINGWIDGET_H
#define PARCELLOADINGWIDGET_H

#include <QWidget>
#include <QButtonGroup>
#include <vector>
#include "mydb.h"
namespace Ui {
class ParcelLoadingWidget;
}

class ParcelLoadingWidget : public QWidget
{
    Q_OBJECT

public:
    explicit ParcelLoadingWidget(QWidget *parent = 0);
    ~ParcelLoadingWidget();

    bool activeScanner;
    bool isTextbrowserHaveContext;
    QButtonGroup *m_pButtonGroup;
    QString parcelID_scanner;
    QString parcelInfo;

    QString parcelID;
    QString name;
    QString phone;
    QString boxPos;

    QString parcelID_cur;
    QString name_cur;
    QString phone_cur;
    QString boxPos_cur;

    int getAllParcleTobeLoaded();
    void updateTableWidget();
    void updateParcelStateInDB_load();
    void updateParcelStateInDB_giveUpLoad();
    bool checkParcelID(QString parcelID);
    void resetUI();
private:
    void initUi();//初始化界面参数
    void initConnect();//初始化信号和槽连接

public slots:
    void on_pushButton_haveLoad_clicked();
    void on_pushButton_giveUp_clicked();
    void getParcelIDFromScanner();
    void getParcelInfo();
    void onButtonClicked(QAbstractButton*);
private:
    Ui::ParcelLoadingWidget *ui;
    int parcelNum;
    std::vector<QString> parcelIDClusters;
    std::vector<QString> nameClusters;
    std::vector<QString> phoneNumClusters;
    std::vector<QString> boxPosClusters;

    std::vector<QString> parcelIDClusters_load;
    std::vector<QString> nameClusters_load;
    std::vector<QString> phoneNumClusters_load;
    std::vector<QString> boxPosClusters_load;

};

#endif // PARCELLOADINGWIDGET_H
