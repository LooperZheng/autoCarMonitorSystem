#include "detentionreasonwidget.h"
#include "ui_detentionreasonwidget.h"
#include <QDesktopWidget>
#include <QDebug>
#include <QMessageBox>
#include "mydb.h"
DetentionReasonWidget::DetentionReasonWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DetentionReasonWidget)
{
    ui->setupUi(this);
    initUi();//初始化界面参数
    initConnect();//初始化信号和槽连接
}

DetentionReasonWidget::~DetentionReasonWidget()
{
    delete ui;
}
void DetentionReasonWidget::initUi()
{
    // 固定窗口的大小
    this->setFixedSize(this->width(), this->height());
    this->setWindowTitle("包裹管理");
    //设置弹出窗口的位置（在屏幕中央）
    QDesktopWidget *deskdop=QApplication::desktop();
    this->move((deskdop->width()-this->width())/2,      (deskdop->height()-this->height())/2);
    //初始化下拉列表
    QString  itemText = "收货人更改收货信息";
    ui->comboBox_detentionReason_2->insertItem(0,itemText);
    itemText = "暂时联系不上收货人";
    ui->comboBox_detentionReason_2->insertItem(1,itemText);
    itemText = "收货人更改送货时间";
    ui->comboBox_detentionReason_2->insertItem(2,itemText);
    itemText = "航班管理,交通意外,恶劣天气等不可抗力因素";
    ui->comboBox_detentionReason_2->insertItem(3,itemText);

    itemText = "客户原因";
    ui->comboBox_detentionReason->insertItem(0,itemText);
    itemText = "配送延误";
    ui->comboBox_detentionReason->insertItem(1,itemText);
}
void DetentionReasonWidget::initConnect()
{

}
void DetentionReasonWidget::getParcelID_pj(QString ID)
{
    parcelID_pj = ID;
}
void DetentionReasonWidget::getRententionReason()
{
    reason = ui->comboBox_detentionReason->currentText();
    reason_2 = ui->comboBox_detentionReason_2->currentText();
}
void DetentionReasonWidget::on_pushButton_yes_clicked()
{
    getRententionReason();
    //if(check(parcelID_pj))
    if(1)
    {
        //insert to DB
        MyDB mydb;
        if( !mydb.initDB("localhost","root","vip","db_vip"))
        {
            QMessageBox::information(NULL, "提示", "数据库连接失败 !\n");
            return;
        }
        else
        {
            //insert to table of order_retentions
            string insert = "replace into db_vip.order_retentions(pj_order_sn,retention_reason_first,retention_reason_second)  values";
            insert += "\(";
            insert += "\'";
            insert += parcelID_pj.toStdString();
            insert += "\'";
            insert += "\,";
            insert += "\'";
            insert += reason.toStdString();
            insert += "\'";
            insert += "\,";
            insert += "\'";
            insert += reason_2.toStdString();
            insert += "\'";
            insert += "\)";
            qDebug()<<QString::fromStdString(insert);
            if( !mydb.insertData(insert))
            {
                QMessageBox::information(NULL, "提示", "数据库插入滞留原因失败 !\n");
                return;
            }
            else
            {
                qDebug()<<"insert parcel detrntion success";
                emit signal_parcelInfoWidget_changeDetention(parcelID_pj);
                this->close();
            }
            //update table of tansport_sns : status = 500(滞留);
//            string update = "update db_vip.transport_sns set status='500' where pj_order_sn=";
//            update += "\'";
//            update += parcelID_pj.toStdString();
//            update += "\'";
//            if( !mydb.updateData(update))
//            {
//                QMessageBox::information(NULL, "提示", "更新 status = 500 (滞留) 失败 !\n");
//                return;
//            }
//            else
//            {
//                qDebug()<<"update  parcel status to 500 (滞留);";
//                ui->comboBox_detentionReason->setCurrentIndex(0);
//                ui->lineEdit_inputReason->clear();
//                this->close();
//                emit signal_parcelInfoWidget_changeDetention(parcelID_pj);
//            }
            return;
        }
    }
    else
    {
        qDebug()<<"parcel_pj ID format is error";
        return;
    }
}
void DetentionReasonWidget::on_pushButton_cancell_clicked()
{
    ui->comboBox_detentionReason->setCurrentIndex(0);
    ui->lineEdit_inputReason->clear();
    this->close();
}
