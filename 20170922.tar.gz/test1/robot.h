#ifndef ROBOT_H
#define ROBOT_H

#include <iostream>
#include <QObject>
#include <QWidget>
#include <QPushButton>
#include <QLineEdit>
#include <QLabel>
#include <vector>
#include <map>
#include <string>
#include "task_plan.h"
#include "sever_car.h"
using namespace std;

//上传车辆信息
struct CarInfo
{
    QString ID;
    double longitude;
    double latitude;
    double vel;
    double miles;
    double miles_left;
    int battery;
    bool state;
};
//上传路况信息
struct RoadInfo
{
    std::vector<double> ultrasonicObstacleDistance;
    bool passable;
};
//上传系统信息
struct SysInfo
{
    int communicationState;
    int laserState;
    int radarState;
    int ultrasonicState;
};
//货柜信息
struct BoxInfo
{
    std::vector<int> boxState;
    int boxIsOpen;
    int boxIsClose;
};
//货柜信息
struct TaskInfo
{
    bool isInTaskPoint;
    int taskPoint;
};


struct taskPoint
{
    int ID;
    double longitude;
    double latitude;
    QString taskInfo;
};
struct Path
{
    int from;
    int to;
    double dis;
};

struct vehicleCoordinate
{
  QString ID;
  double vehicle_x;
  double vehicle_y;
  QString vehicle_info;
};
class Robot: public QObject
{
     Q_OBJECT
public:
     explicit Robot(QObject *parent=0);
     ~Robot();

    void initConnect();
    void initTCPServer();
    void getTaskSeqPlanTime();
    std::vector<int> taskSeqPlanTime;
    std::vector<int> taskSeq;
    std::vector<int> pathSeq;
    std::set<int> completedTaskSeq;
    std::vector<Path> pathMap;
    std::vector<taskPoint> taskPointCluster;
    std::map<int, std::pair<double,double> > pathPointID2Coordinate;
    std::map<int, bool>  pathPointID2IsTaskPoint;
    vehicleCoordinate vehicleCoor;
    int currentTaskID;
    int nodeNum;
    result planRes;
    //存放所有路径点，包含曲线
    std::vector<int> pathAll;
    std::map<int, std::pair<double,double> > pathPointID2CoordinateAll;

    //上传信息
    CarInfo carInfo;
    RoadInfo roadInfo;
    SysInfo sysInfo;
    BoxInfo boxInfo;
    TaskInfo taskInfo;
    //完成的任务序列
    std::vector<int> taskSeqCompleted;
    //转换后的小车经纬度
    double lng_transformed;
    double lat_transformed;
    //test
    double lo;
    double la;
    int iii;
public slots:
     //local
     void getPathMapFromTopoMap();
     void getPathPointFromTopoMap();
     void getPathPointAllFromTopoMap();
     // DataBase from logistic
     void getTaskSeqFromLogisticDB();
     // data from vehicle
     void getVehicelCoor();


     //JS调用Robot对象的函数，访问对象数据 ,供javascript调用的槽
     int returnTaskNum() {return taskPointCluster.size();}
     double returnTaskPointLongitude(int num) {return taskPointCluster[num].longitude;}
     double returnTaskPointLatitude(int num) {return taskPointCluster[num].latitude;}
     QString returnTaskInfo(int num) {return taskPointCluster[num].taskInfo;}
     int returnTaskID(int num) {return taskPointCluster[num].ID;}

     int returnPathPointNum(){return pathSeq.size();}
     double returnPathPointLongitude(int num) {return pathPointID2Coordinate[pathSeq[num]].first;}
     double returnPathPointLatitude(int num) {return pathPointID2Coordinate[pathSeq[num]].second;}

//     //test for map
//     int returnAllPathPointNum(){return pathMap.size();}
//     double returnAllPathPointLongitudeFrom(int num) {return pathPointID2Coordinate[pathMap[num].from].first;}
//     double returnAllPathPointLatitudeFrom(int num) {return pathPointID2Coordinate[pathMap[num].from].second;}
//     double returnAllPathPointLongitudeEnd(int num) {return pathPointID2Coordinate[pathMap[num].to].first;}
//     double returnAllPathPointLatitudeEnd(int num) {return pathPointID2Coordinate[pathMap[num].to].second;}

     //draw path (not test)
     int returnAllPathPointNum(){return pathAll.size()-1;}
     double returnAllPathPointLongitudeFrom(int num) {return pathPointID2CoordinateAll[pathAll[num]].first;}
     double returnAllPathPointLatitudeFrom(int num) {return pathPointID2CoordinateAll[pathAll[num]].second;}
     double returnAllPathPointLongitudeEnd(int num) {return pathPointID2CoordinateAll[pathAll[num+1]].first;}
     double returnAllPathPointLatitudeEnd(int num) {return pathPointID2CoordinateAll[pathAll[num+1]].second;}

     //vehicle
     double returnVehicle_x() {return vehicleCoor.vehicle_x;}
     double returnVehicle_y() {return vehicleCoor.vehicle_y;}
     QString returnVehicle_info() {return vehicleCoor.vehicle_info;}
     void getTransformedPoint(double lng,double lat)
     {
         //qDebug()<<"------------------------";
         lng_transformed=lng;
         lat_transformed=lat;
//         qDebug()<<QString::number(lng_transformed,10,6);
//         qDebug()<<QString::number(lat_transformed,10,6);
         //qDebug()<<"==========================";
     }

     //current task
     int returnCurrentTaskID() {return currentTaskID;}

     //taskplan
     result executeTaskPlan();

     void slot_acceptMsgFromClient();
     void calculateTime();
     void slot_startTime();
signals:
     void signal_getCurrentTaskID();
     void signal_completeAllTask();
     void signal_acceptBoxStateFromVehicle(BoxInfo);
     void signal_arriveTaskPoint(int);
     void signal_leaveTaskPoint(int);
private:
     TaskPlan planner;
public:
     SeverCar tcpIpSever;
     int time_sec;
     QTimer *timer;

public:
    void sendMessageToVehicle();

};
#endif // ROBOT_H
