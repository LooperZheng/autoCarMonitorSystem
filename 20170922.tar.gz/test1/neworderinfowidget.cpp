#include "neworderinfowidget.h"
#include "ui_neworderinfowidget.h"
#include <QDesktopWidget>
#include <QDebug>
#include <QMessageBox>
#include <algorithm>
#include <vector>
#include <string>
#include "mydb.h"
NewOrderInfoWidget::NewOrderInfoWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::NewOrderInfoWidget)
{
    ui->setupUi(this);
    parcelNum = 0;
    initUi();//初始化界面参数
    initConnect();//初始化信号和槽连接
}

NewOrderInfoWidget::~NewOrderInfoWidget()
{
    delete ui;
}
void NewOrderInfoWidget::initUi()
{
    // 固定窗口的大小
    this->setFixedSize(this->width(), this->height());
    //no window title
    //this->setWindowFlags(Qt::FramelessWindowHint);
    this->setWindowTitle("消息管理");

    QIcon ico(":/images/close.png");
    ui->pushButton_close->setIcon(ico);
    ui->pushButton_close->setIconSize(QSize(20,20));
    //设置弹出窗口的位置（在屏幕中央）
    QDesktopWidget *deskdop=QApplication::desktop();
    this->move((deskdop->width()-this->width())/2,(deskdop->height()-this->height())/2);

    //table Widget
    ui->tableWidget->setColumnCount(4);
    ui->tableWidget->setRowCount(9);
    ui->tableWidget->setHorizontalHeaderLabels(QStringList() << "订单号" << "收货人" << "目前状态" <<"原状态");

    ui->tableWidget->setColumnWidth(0, 150);
    ui->tableWidget->setColumnWidth(1, 110);
    ui->tableWidget->setColumnWidth(2, 153);
    ui->tableWidget->setColumnWidth(3, 153);

}
void NewOrderInfoWidget::initConnect()
{
    connect(ui->tableWidget, SIGNAL(cellClicked(int,int)), this, SLOT(clickCell(int, int)));
}
void NewOrderInfoWidget::on_pushButton_close_clicked()
{
    this->close();
}
void NewOrderInfoWidget::clickCell(int row, int col)
{
    if(col==0)
    {
        QString parcelID;
        parcelID=ui->tableWidget->item(row,0)->text();

        qDebug()<<row;
        if(parcelNum-row>isCheckCluster.size())
            qDebug()<<"error in isCheckCluster";
        else
            isCheckCluster[parcelNum-row-1]=true;

        updateTableWidget();
        //update msg num
        int num = std::count(isCheckCluster.begin(), isCheckCluster.end(), false);
        emit signal_updadeNewMsgNum(num);
    }
}
bool NewOrderInfoWidget::getMegFromDB()
{
    //read from DB
    MyDB mydb;
    if( !mydb.initDB("localhost","root","vip","db_vip"))
    {
        QMessageBox::information(NULL, "提示", "数据库连接失败 !\n");
        return false;
    }
    else
    {
        //根据时间戳进行降序排列，去第一个为最新更新的数据
        std::string query =  "select message_pjorder_sn,current_status,previous_status,creation_time from db_vip.messages order by creation_time DESC";
        std::vector<std::vector<std::string> > result_msg;
        if( !mydb.exeSQL(query, result_msg))
        {
            QMessageBox::information(NULL, "提示", "查询 db_vip.messages 失败 !\n");
            return false;
        }
        else
        {
            qDebug()<<"query db_vip.messages ";
            parcelID_pj = QString::fromStdString(result_msg[0][0]);
            currentState = QString::fromStdString(result_msg[1][0]);
            lastState = QString::fromStdString(result_msg[2][0]);
        }
    }
    //query table of transport_sn
    string query = "select receiver_name from db_vip.transport_sns where pj_order_sn=";
    query += "\'";
    query += parcelID_pj.toStdString();
    query += "\'";
    vector<vector<string> > result_transport_sn;
    if( !mydb.exeSQL(query, result_transport_sn ))
    {
        QMessageBox::information(NULL, "提示", "查询数据失败 !\n");
        return false;
    }
    else
    {
        if(result_transport_sn[0].size()==0)
        {
            QMessageBox::information(NULL, "提示", "没有查找到相应数据 !\n");
            return false;
        }
        else
        {
            name = QString::fromStdString(result_transport_sn[0][0]);
        }
    }
    return true;
}
// 当收到socket有新的信息时候，执行该函数
void NewOrderInfoWidget::getUpdateParcelState()
{
    if(getMegFromDB())
    {
        parcelNum++;
        parcelIDClusters.push_back(parcelID_pj);
        nameClusters.push_back(name);
        currentStateClusters.push_back(currentState);
        lastStateClusters.push_back(lastState);
        isCheckCluster.push_back(false);

        updateTableWidget();
        //update msg num
        int num = std::count(isCheckCluster.begin(),isCheckCluster.end(), false);
        emit signal_updadeNewMsgNum(num);
    }
}
void NewOrderInfoWidget::updateTableWidget()
{
    ui->tableWidget->clear();
    ui->tableWidget->setColumnCount(4);
    ui->tableWidget->setRowCount(parcelNum);
    ui->tableWidget->setHorizontalHeaderLabels(QStringList() << "订单号" << "收货人" << "目前状态" <<"原状态");
    int j =0;
    for(int i =parcelNum-1; i>=0; i--)
    {
        QTableWidgetItem *item = new QTableWidgetItem();
        ui->tableWidget->setItem(i, 0, item);
        item->setFlags(item->flags() & (~Qt::ItemIsEditable));
        if(isCheckCluster[j]==false)
            item->setBackground(QBrush(QColor(230, 30, 30)));
        else
            item->setBackground(QBrush(QColor(255, 255, 255)));
        ui->tableWidget->item(i,0)->setText(parcelIDClusters[j]);

        QTableWidgetItem *item1 = new QTableWidgetItem();
        ui->tableWidget->setItem(i, 1, item1);
        item1->setFlags(item1->flags() & (~Qt::ItemIsEditable));
        if(isCheckCluster[j]==false)
            item1->setBackground(QBrush(QColor(230, 30, 30)));
        else
            item1->setBackground(QBrush(QColor(255, 255, 255)));
        ui->tableWidget->item(i,1)->setText(nameClusters[j]);

        QTableWidgetItem *item2 = new QTableWidgetItem();
        ui->tableWidget->setItem(i, 2, item2);
        item2->setFlags(item2->flags() & (~Qt::ItemIsEditable));
        if(isCheckCluster[j]==false)
            item2->setBackground(QBrush(QColor(230, 30, 30)));
        else
            item2->setBackground(QBrush(QColor(255, 255, 255)));
        ui->tableWidget->item(i,2)->setText(currentStateClusters[j]);

        QTableWidgetItem *item3 = new QTableWidgetItem();
        ui->tableWidget->setItem(i, 3, item3);
        item3->setFlags(item3->flags() & (~Qt::ItemIsEditable));
        if(isCheckCluster[j]==false)
            item3->setBackground(QBrush(QColor(230, 30, 30)));
        else
            item3->setBackground(QBrush(QColor(255, 255, 255)));
        ui->tableWidget->item(i,3)->setText(lastStateClusters[j]);

        j++;
    }
}
