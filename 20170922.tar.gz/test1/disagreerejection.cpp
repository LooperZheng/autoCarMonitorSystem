#include "disagreerejection.h"
#include "ui_disagreerejection.h"
#include <QDesktopWidget>
#include <QDebug>
#include <QMessageBox>
#include "mydb.h"
DisagreeRejection::DisagreeRejection(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DisagreeRejection)
{
    ui->setupUi(this);
    initUi();//初始化界面参数
    initConnect();//初始化信号和槽连接
}

DisagreeRejection::~DisagreeRejection()
{
    delete ui;
}
void DisagreeRejection::initUi()
{
    // 固定窗口的大小
    this->setFixedSize(this->width(), this->height());
    this->setWindowTitle("拒收审核");
    //设置弹出窗口的位置（在屏幕中央）
    QDesktopWidget *deskdop=QApplication::desktop();
    this->move((deskdop->width()-this->width())/2,      (deskdop->height()-this->height())/2);
        //初始化下拉列表
    QString  itemText = "商品因客户原因导致损坏";
    ui->comboBox->insertItem(0,itemText);
    itemText = "商品按照规定不可试用或试穿";
    ui->comboBox->insertItem(1,itemText);
}
void DisagreeRejection::initConnect()
{

}
void DisagreeRejection::getParcelIDandPjID(std::vector<QString> IDClusters, QString pjID)
{
    parcelIDClusters = IDClusters;
    parcelID_pj = pjID;
}
int DisagreeRejection::getParcelID_pj()
{
    parcelID_pj = "47194";
    return 1;
}
void DisagreeRejection::getDisagreeRejectionReason()
{
    if(ui->lineEdit->text().size() == 0)
        reason = ui->comboBox->currentText();
    else
        reason = ui->lineEdit->text();
}
void DisagreeRejection::on_pushButton_clicked()
{
    //write to DB
    getDisagreeRejectionReason();
    //insert to DB
    MyDB mydb;
    if( !mydb.initDB("localhost","root","vip","db_vip"))
    {
        QMessageBox::information(NULL, "提示", "数据库连接失败 !\n");
        return;
    }
    else
    {
        string insert = "replace into db_vip.order_rejections(pj_order_sn,rejection_or_no,rejection_reason_first)  values";
        insert += "\(";
        insert += "\'";
        insert += parcelID_pj.toStdString();
        insert += "\'";
        insert += "\,";
        insert += "\'";
        insert += "否";
        insert += "\'";
        insert += "\,";
        insert += "\'";
        insert += reason.toStdString();
        insert += "\'";
        insert += "\)";
        qDebug()<<QString::fromStdString(insert);
        if( !mydb.insertData(insert))
        {
            QMessageBox::information(NULL, "提示", "数据库插入拒收原因失败 !\n");
            return;
        }
        else
        {
            emit signal_disagree_rejection("0");
            qDebug()<<"insert parcel rejection reason  success";
            ui->comboBox->setCurrentIndex(0);
            ui->lineEdit->clear();
            this->close();
            return;
        }
    }

}
