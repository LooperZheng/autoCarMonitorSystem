#include "startdeliverywidget.h"
#include "ui_startdeliverywidget.h"
#include <QDesktopWidget>
#include <QDebug>
#include <QMessageBox>
#include <QDateTime>
StartDeliveryWidget::StartDeliveryWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::StartDeliveryWidget)
{
    ui->setupUi(this);
    refreshTimes = 0;
    initUi();//初始化界面参数
    initConnect();//初始化信号和槽连接
}

StartDeliveryWidget::~StartDeliveryWidget()
{
    delete ui;
}
void StartDeliveryWidget::initUi()
{
    // 固定窗口的大小
    this->setFixedSize(this->width(), this->height());
    this->setWindowTitle("出发送货");
    //设置弹出窗口的位置（在屏幕中央）
    QDesktopWidget *deskdop=QApplication::desktop();
    this->move((deskdop->width()-this->width())/2,      (deskdop->height()-this->height())/2);

    //table Widget
    ui->tableWidget->setColumnCount(4);
    ui->tableWidget->setRowCount(5);
    ui->tableWidget->setHorizontalHeaderLabels(QStringList() <<"运单号"<< "收货人" << "手机号"<<"箱格位置");

    ui->tableWidget->setColumnWidth(0, 150);
    ui->tableWidget->setColumnWidth(2, 120);

    QTableWidgetItem *item = new QTableWidgetItem();
    ui->tableWidget->setItem(0, 0, item);
    item->setFlags(item->flags() & (~Qt::ItemIsEditable));
    ui->tableWidget->item(0,0)->setText(QString::number(12345678911111));

    QTableWidgetItem *item1 = new QTableWidgetItem();
    ui->tableWidget->setItem(0, 1, item1);
    item1->setFlags(item1->flags() & (~Qt::ItemIsEditable));
    ui->tableWidget->item(0,1)->setText("张小明");

    QTableWidgetItem *item2 = new QTableWidgetItem();
    ui->tableWidget->setItem(0, 2, item2);
    item2->setFlags(item2->flags() & (~Qt::ItemIsEditable));
    ui->tableWidget->item(0,2)->setText("8888");

    QTableWidgetItem *item3 = new QTableWidgetItem();
    ui->tableWidget->setItem(0, 3, item3);
    item3->setFlags(item3->flags() & (~Qt::ItemIsEditable));
    ui->tableWidget->item(0,3)->setText("A1,A2");
}
void StartDeliveryWidget::initConnect()
{

}
void StartDeliveryWidget::resetUI()
{
    ui->tableWidget->clear();
}
void StartDeliveryWidget::setSecondRefreshUI()
{
    ui->textBrowser->setTextColor(QColor(255,0,0));
    ui->textBrowser->setText("已经刷新过，请点击”继续出发”按钮，进行任务规划.");

    ui->pushButton_ok->setDisabled(true);
    ui->pushButton_takeOutParcel->setDisabled(true);
}
void StartDeliveryWidget::setFirstRefreshUI()
{
    ui->textBrowser->setTextColor(QColor(255,0,0));
    ui->textBrowser->setText("第一次刷新，可以点击“取出包裹”和“确定”按钮,取出包裹, 重新装车; 或者点击“继续出发”按钮，进行任务规划.");

    ui->pushButton_ok->setDisabled(false);
    ui->pushButton_takeOutParcel->setDisabled(false);
}
int StartDeliveryWidget::getAllParcleTobeCancellFromDB()
{
    refreshTimes ++;
    MyDB mydb;
    if( !mydb.initDB("localhost","root","vip","db_vip"))
    {
        QMessageBox::information(NULL, "提示", "数据库连接失败 !\n");
        return 2;
    }
    else
    {
        //query table of transport_sn
        string query = "select transport_sn from db_vip.transport_sn_scheduling_plan";
        vector<vector<string> > result;
        if( !mydb.exeSQL(query, result ))
        {
            QMessageBox::information(NULL, "提示", "查询数据失败 !\n");
            return 2;
        }
        else
        {
            parcelIDClusters.clear();
            for(int i= 0; i<result[0].size();i++)
            {
                parcelIDClusters.push_back(QString::fromStdString(result[0][i]));
            }
        }
    }
    //debug
    for(int i=0; i<parcelIDClusters.size();i++)
        qDebug()<<parcelIDClusters[i];

    parcelIDClusters_cancell.clear();
    nameClusters.clear();
    phoneNumClusters.clear();
    boxTypeClusters.clear();
    boxIDClusters.clear();

    //get time_slot_id
    string time_slot_id;
    QDateTime time = QDateTime::currentDateTime();//获取系统现在的时间
    QString str = time.toString("yyyy-MM-dd hh:mm:ss"); //设置显示格式
    string hour = str.toStdString().substr(11,2);
    string minute = str.toStdString().substr(14,2);
    int hour_int = atoi(hour.c_str());
    int minute_int = atoi(minute.c_str());
    qDebug()<<str;
    qDebug()<<hour_int;
    qDebug()<<minute_int;
    if (hour_int*60+minute_int < 10*60+30)
        time_slot_id = "1";
    if ((hour_int*60+minute_int > 10*60+31) && (hour_int*60+minute_int < 13*60+0))
        time_slot_id = "2";
    if ((hour_int*60+minute_int > 13*60+1) && (hour_int*60+minute_int < 15*60+30))
        time_slot_id = "3";
    if (hour_int*60+minute_int > 15*60+31 && (hour_int*60+minute_int < 18*60+00))
        time_slot_id = "4";
    // test
    if (hour_int*60+minute_int > 18*60+1 && (hour_int*60+minute_int < 22*60+40))
        time_slot_id = "5";
    if (hour_int*60+minute_int > 22*60+41 && (hour_int*60+minute_int < 24*60+00))
        time_slot_id = "6";

    //query table of ransport_sns
    for(int i = 0; i<parcelIDClusters.size(); i++)
    {
        string query = "select receiver_name,receiver_mobile,box_type,status,time_slot_id from db_vip.transport_sns where transport_sn=";
        vector<vector<string> > result_transport_sn;
        QString condition = parcelIDClusters[i];
        query += "\'";
        query += condition.toStdString();
        query += "\'";

        qDebug()<<QString::fromStdString(query);
        if( !mydb.exeSQL(query, result_transport_sn ))
        {
            QMessageBox::information(NULL, "提示", "查询数据失败 !\n");
            return 2;
        }
        else
        {
            if(result_transport_sn[0].size() != 0)
            {
                string parcelStatus = result_transport_sn[3][0];
                string timeSlotID = result_transport_sn[4][0];
                //改为人工配送或者班次修改（不是本班次）需要作为取消列表
                if( string(parcelStatus) == "600" || string(timeSlotID) != string(time_slot_id))
                //if( 0)
                {
                    qDebug()<<"********************";
                    qDebug()<<QString::fromStdString(time_slot_id);
                    qDebug()<<QString::fromStdString(timeSlotID);
                    nameClusters.push_back(QString::fromStdString(result_transport_sn[0][0]));
                    phoneNumClusters.push_back(QString::fromStdString(result_transport_sn[1][0]));
                    boxTypeClusters.push_back(QString::fromStdString(result_transport_sn[2][0]));

                    parcelIDClusters_cancell.push_back(parcelIDClusters[i]);
                    qDebug()<<parcelIDClusters[i];
                }
            }
        }
    }

    parcelNum = parcelIDClusters_cancell.size();
    //qDebug()<<"**********************";
    //qDebug()<<parcelNum;
    //query table of ransport_sns_box_assignment
    for(int i = 0; i<parcelIDClusters_cancell.size(); i++)
    {
        string query = "select box_id from db_vip.transport_sn_box_assignment where transport_sn=";
        vector<vector<string> > result_transport_sn_box_assignment;
        QString condition = parcelIDClusters_cancell[i];
        query += "\'";
        query += condition.toStdString();
        query += "\'";
        qDebug()<<i;
        qDebug()<<QString::fromStdString(query);
        if( !mydb.exeSQL(query, result_transport_sn_box_assignment ))
        {
            QMessageBox::information(NULL, "提示", "查询数据失败 !\n");
            return 2;
        }
        else
        {
            if(result_transport_sn_box_assignment[0].size() != 0)
            {
                boxIDClusters.push_back(QString::fromStdString(result_transport_sn_box_assignment[0][0]));
            }
            else
            {
                boxIDClusters.push_back(QString("未查询到"));
            }
        }
    }

    if(parcelIDClusters_cancell.size() == 0)
        return  -1;
    else
        return 1;
}
void StartDeliveryWidget::updateTableWidget()
{
    ui->tableWidget->clear();
    ui->tableWidget->setColumnCount(4);
    ui->tableWidget->setRowCount(parcelNum);
    ui->tableWidget->setHorizontalHeaderLabels(QStringList() <<"运单号"<< "收货人" << "手机号"<<"箱格位置");

    for(int i =0; i<parcelNum; i++)
    {
        QTableWidgetItem *item = new QTableWidgetItem();
        ui->tableWidget->setItem(i, 0, item);
        item->setFlags(item->flags() & (~Qt::ItemIsEditable));
        ui->tableWidget->item(i,0)->setText(parcelIDClusters_cancell[i]);

        QTableWidgetItem *item1 = new QTableWidgetItem();
        ui->tableWidget->setItem(i, 1, item1);
        item1->setFlags(item1->flags() & (~Qt::ItemIsEditable));
        ui->tableWidget->item(i,1)->setText(nameClusters[i]);

        QTableWidgetItem *item2 = new QTableWidgetItem();
        ui->tableWidget->setItem(i, 2, item2);
        item2->setFlags(item2->flags() & (~Qt::ItemIsEditable));
        ui->tableWidget->item(i,2)->setText(phoneNumClusters[i]);

        QTableWidgetItem *item3 = new QTableWidgetItem();
        ui->tableWidget->setItem(i, 3, item3);
        item3->setFlags(item3->flags() & (~Qt::ItemIsEditable));
        ui->tableWidget->item(i,3)->setText(boxIDClusters[i]);
    }
}
void StartDeliveryWidget::on_pushButton_start_clicked()
{
    QMessageBox::StandardButton rb=QMessageBox::information(NULL, "提示", "  车辆准备出发\n即将执行任务规划", QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes);
    if(rb == QMessageBox::Yes)
    {
        this->hide();
        //恢复计数次数为0
        refreshTimes = 0;
        emit signal_startTaskPlan();
    }
    else
        qDebug()<<"no";
}

void StartDeliveryWidget::on_pushButton_takeOutParcel_clicked()
{
    if(boxIDClusters.size() == 0)
        QMessageBox::information(NULL, "提示", "没有要取出的包裹\n车门无需打开 !\n");
    else
    {
        //获得需要打开车门的信息
        std::vector<int> boxIndex;
        //数据库货柜信息与实际车辆对应
        for(int i=0; i<boxIDClusters.size();i++)
        {
            //QString boxIDSeg = "A1,A2";
            QString boxIDSeg = boxIDClusters[i];
            QStringList boxIdList;
            boxIdList =  boxIDSeg.split(',');
            for(int i=0;i<boxIdList.size();i++)
            {
                QString boxID = boxIdList[i];
                qDebug()<<boxID;
                int boxTmp = getBoxIndexAccordingToBoxID(boxID);
                if(boxTmp != 999)
                    boxIndex.push_back(boxTmp);
            }
        }
        emit signal_openBox_startDelivery(boxIndex);
    }
}
void StartDeliveryWidget::on_pushButton_ok_clicked()
{
    //关闭箱门后点击“确定”，调用排班算法,若当前班次有增加任务，则弹出包裹装车页面
    //socket to logistics
    this->close();
    //如果有取消的包裹，则重新调用排版算法，再包裹装车
    if(parcelIDClusters_cancell.size() != 0)
    {
        emit signal_exeSchedulePlanAlgorithm();
    }
}
// TBD
int StartDeliveryWidget::getBoxIndexAccordingToBoxID(QString boxID)
{
    if(boxID == "A1")
        return 1;
    if(boxID == "A2")
        return 2;
    if(boxID == "A3")
        return 3;
    if(boxID == "A4")
        return 4;
    if(boxID == "A5")
        return 5;
    if(boxID == "A6")
        return 6;
    if(boxID == "A7")
        return 7;
    if(boxID == "A8")
        return 8;
    if(boxID == "B1")
        return 9;
    if(boxID == "B2")
        return 10;
    if(boxID == "B3")
        return 11;
    if(boxID == "B4")
        return 12;
    if(boxID == "B5")
        return 13;
    if(boxID == "B6")
        return 14;
    if(boxID == "B7")
        return 15;
    if(boxID == "B8")
        return 16;
    if(boxID == "C1")
        return 17;
    if(boxID == "C2")
        return 18;
    if(boxID == "C3")
        return 19;
    if(boxID == "C4")
        return 20;
    else
        return 999;
}
