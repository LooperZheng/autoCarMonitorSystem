#ifndef DISAGREEREJECTION_H
#define DISAGREEREJECTION_H

#include <QWidget>

namespace Ui {
class DisagreeRejection;
}

class DisagreeRejection : public QWidget
{
    Q_OBJECT

public:
    explicit DisagreeRejection(QWidget *parent = 0);
    ~DisagreeRejection();

    void getDisagreeRejectionReason();
    int getParcelID_pj();
    void getParcelIDandPjID(std::vector<QString>, QString);
signals:
    void signal_disagree_rejection(QString);
private:
    void initUi();//初始化界面参数
    void initConnect();//初始化信号和槽连接
private slots:
    void on_pushButton_clicked();
private:
    Ui::DisagreeRejection *ui;
    QString parcelID;
    QString parcelID_pj;
    QString reason;
    std::vector<QString> parcelIDClusters;
};

#endif // DISAGREEREJECTION_H
