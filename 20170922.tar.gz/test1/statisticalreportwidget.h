#ifndef STATISTICALREPORTWIDGET_H
#define STATISTICALREPORTWIDGET_H

#include <QWidget>
#include "mydb.h"
namespace Ui {
class StatisticalReportWidget;
}

class StatisticalReportWidget : public QWidget
{
    Q_OBJECT

public:
    explicit StatisticalReportWidget(QWidget *parent = 0);
    ~StatisticalReportWidget();

    void resetDisplayData();
    int getQueryParcelInfoFromDB();
    void updateTableWidget();
private:
    void initUi();//初始化界面参数
    void initConnect();//初始化信号和槽连接
    bool checkIsEmpty();
signals:
    void signal_exeOutputTable(QString);
public slots:
    void on_pushButton_query_clicked();
    void on_pushButton_reset_clicked();
    void on_pushButton_output_clicked();
private:
    Ui::StatisticalReportWidget *ui;
    QString parcelInfo;
    QString parcelState;
    QString queryIndex;
    QString queryTime;
    QString queryStation;
};

#endif // STATISTICALREPORTWIDGET_H
