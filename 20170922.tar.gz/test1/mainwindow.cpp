﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDesktopWidget>
#include <QMediaPlayer>
#include <string>
#include <vector>
#include <json/json.h>
#include <json/value.h>
#include <json/writer.h>
#define TEXT_COLOR  QColor(255,255,255)

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent)
{
    ui=new Ui::MainWindow();
    myRobot=new Robot(this);
    myRobot->initTCPServer();
    myRobot->initConnect();
    initData();
    initUi();//初始化界面参数
    initConnect();//初始化信号和槽连接
    isArriveTaskPoint = true;
    nextTaskPoint = 0;
    audioPlayer = new QMediaPlayer;
    qDebug("start to tcp sever_logistics init 7771");
    tcpIpSever_Logistic.tcpSeverInit(7771);
    tcpIpSever_Logistic.tcpListening();
}
MainWindow::~MainWindow()
{
    delete ui;
    delete myRobot;
}

void MainWindow::initData()
{
    myRobot->getPathPointFromTopoMap();
    myRobot->getPathMapFromTopoMap();
    myRobot->getPathPointAllFromTopoMap();
    myRobot->getTaskSeqFromLogisticDB();
    //播放声音名称和标号映射表
    audioMap.insert(pair<QString,int>("箱门已打开",0));
    audioMap.insert(pair<QString,int>("包裹是第一批次",1));
    audioMap.insert(pair<QString,int>("包裹是第二批次",2));
    audioMap.insert(pair<QString,int>("包裹是第三批次",3));
    audioMap.insert(pair<QString,int>("包裹是第四批次",4));
    audioMap.insert(pair<QString,int>("单号错误",5));
    audioMap.insert(pair<QString,int>("回收成功",6));
    //任务点地址和编号映射表
    TaskPointMap.insert(pair<int,QString>(0,"配送站"));
    TaskPointMap.insert(pair<int,QString>(1,"农学院"));
    TaskPointMap.insert(pair<int,QString>(2,"生物医药"));
    TaskPointMap.insert(pair<int,QString>(3,"船建"));
    TaskPointMap.insert(pair<int,QString>(4,"行政楼"));
    TaskPointMap.insert(pair<int,QString>(5,"机动群楼"));
    TaskPointMap.insert(pair<int,QString>(6,"软微空天"));
    TaskPointMap.insert(pair<int,QString>(7,"宿舍东四区"));
    TaskPointMap.insert(pair<int,QString>(8,"宿舍东三区"));
    TaskPointMap.insert(pair<int,QString>(9,"宿舍东二区"));
    TaskPointMap.insert(pair<int,QString>(10,"宿舍东一区"));
    TaskPointMap.insert(pair<int,QString>(11,"文科群楼"));
    TaskPointMap.insert(pair<int,QString>(12,"宿舍西八"));
    TaskPointMap.insert(pair<int,QString>(14,"材料学院"));
    TaskPointMap.insert(pair<int,QString>(15,"西区学院群楼"));
    TaskPointMap.insert(pair<int,QString>(16,"宿舍西二区"));
    TaskPointMap.insert(pair<int,QString>(17,"光明体育场"));
    TaskPointMap.insert(pair<int,QString>(18,"宿舍西一区"));
    TaskPointMap.insert(pair<int,QString>(19,"西区老楼"));
    TaskPointMap.insert(pair<int,QString>(34,"宿舍西三区"));
    TaskPointMap.insert(pair<int,QString>(35,"宿舍西四区"));

    boxIDMap.insert(pair<int,QString>(1,"A1"));
    boxIDMap.insert(pair<int,QString>(2,"A2"));
    boxIDMap.insert(pair<int,QString>(3,"A3"));
    boxIDMap.insert(pair<int,QString>(4,"A4"));
    boxIDMap.insert(pair<int,QString>(5,"A5"));
    boxIDMap.insert(pair<int,QString>(6,"A6"));
    boxIDMap.insert(pair<int,QString>(7,"A7"));
    boxIDMap.insert(pair<int,QString>(8,"A8"));
    boxIDMap.insert(pair<int,QString>(9,"B1"));
    boxIDMap.insert(pair<int,QString>(10,"B2"));
    boxIDMap.insert(pair<int,QString>(11,"B3"));
    boxIDMap.insert(pair<int,QString>(12,"B4"));
    boxIDMap.insert(pair<int,QString>(13,"B5"));
    boxIDMap.insert(pair<int,QString>(14,"B6"));
    boxIDMap.insert(pair<int,QString>(15,"B7"));
    boxIDMap.insert(pair<int,QString>(16,"B8"));
    boxIDMap.insert(pair<int,QString>(17,"C1"));
    boxIDMap.insert(pair<int,QString>(18,"C2"));
    boxIDMap.insert(pair<int,QString>(19,"C3"));
    boxIDMap.insert(pair<int,QString>(20,"C4"));

    currentTaskPointParcelNum = 0;
    currentTaskPointParcelStatus = "在途";
}
void MainWindow::initConnect()
{
    //在跨页面的时候，该对象会被清除，所以要重新加回来
    //这一点跟GTK类似， 只要捕获WindowObjectCleared信号，在该信号处理函数里面执行addToJavaScriptWindowObject()
    connect(ui->webView->page()->mainFrame(), SIGNAL(javaScriptWindowObjectCleared()),this, SLOT(addJavaScriptObject()));//地图刷新调取
    QObject::connect(timer,SIGNAL(timeout()),this,SLOT(showTime()));
    QObject::connect(timer_mapRefresh,SIGNAL(timeout()),this,SLOT(refreshBaiduMapVehicle()));
    QObject::connect(timer_dbRefresh,SIGNAL(timeout()),this,SLOT(updateDB_vehiclePos()));

    QObject::connect(timer_InfoRefresh,SIGNAL(timeout()),this,SLOT(showVehicleInfo()));
    QObject::connect(timer_InfoRefresh,SIGNAL(timeout()),this,SLOT(showSysInfo()));
    QObject::connect(timer_InfoRefresh,SIGNAL(timeout()),this,SLOT(showRoadInfo()));
    QObject::connect(timer_InfoRefresh,SIGNAL(timeout()),this,SLOT(showTaskInfo()));
    QObject::connect(timer_InfoRefresh,SIGNAL(timeout()),this,SLOT(showParcelInfo()));
    QObject::connect(timer_InfoRefresh,SIGNAL(timeout()),this,SLOT(updateTeleoperationRobotInfo()));
    //不同类对象之间通信
    connect( &(this->teleoperation), SIGNAL(signal_showBoxQueryWidget()), this,SLOT (teleoperationWidget_BoxAskShow()));
    connect( &(this->teleoperation), SIGNAL(signal_showVehicleQueryWidget()), this,SLOT (teleoperationWidget_VehicleAskShow()));

    connect( &(this->teleoperation), SIGNAL(signal_vehicleControlCmd(int, int)), this,SLOT (teleoperationWidget_VehicleControlCmd(int, int)));

    connect( &(this->teleoperation), SIGNAL(signal_vehicleControlTurnLeft()), this,SLOT (teleoperationWidget_VehicleTurnLeft()));
    connect( &(this->teleoperation), SIGNAL(signal_vehicleControlTurnRight()), this,SLOT (teleoperationWidget_VehicleTurnRight()));
    connect( &(this->teleoperation), SIGNAL(signal_vehicleControlTurnForward()), this,SLOT (teleoperationWidget_VehicleForward()));
    connect( &(this->teleoperation), SIGNAL(signal_vehicleControlTurnBackward()), this,SLOT (teleoperationWidget_VehicleBackward()));
    connect( &(this->teleoperation), SIGNAL(signal_vehicleControlStop()), this,SLOT (teleoperationWidget_VehicleStop()));
    connect( &(this->teleoperation), SIGNAL(signal_vehicleControlStart()), this,SLOT (teleoperationWidget_VehicleStart()));
    connect( &(this->teleoperation), SIGNAL(signal_vehicleControlHorn()), this,SLOT (teleoperationWidget_VehicleHorn()));
    connect( &(this->teleoperation), SIGNAL(signal_vehicleControlLight()), this,SLOT (teleoperationWidget_VehicleLight()));
    connect( &(this->teleoperation), SIGNAL(signal_vehicleControlLightClose()), this,SLOT (teleoperationWidget_VehicleLightClose()));
    connect( &(this->teleoperation), SIGNAL(signal_operationExchange()), this,SLOT (teleoperationWidget_OperationExchange()));

    connect( &(this->boxInfoWidget), SIGNAL(signal_openBox(std::vector<int>)), this,SLOT (boxInfoWidget_openBox(std::vector<int>)));

    connect( &(this->remainingParcelWidget), SIGNAL(signal_openBox_remainingParcel(std::vector<int>)), this,SLOT (boxInfoWidget_openBox(std::vector<int>)));

    connect( &(this->parcelLoadingWidget), SIGNAL(signal_openBox_parcelLoading(std::vector<int>)), this,SLOT (boxInfoWidget_openBox(std::vector<int>)));

    connect( this->myRobot, SIGNAL(signal_getCurrentTaskID()), this,SLOT(refreshBaiduMapTask()));
    connect( this->myRobot, SIGNAL(signal_completeAllTask()), this,SLOT(refreshBaiduMapAll()));
    connect( this->myRobot, SIGNAL(signal_acceptBoxStateFromVehicle(BoxInfo)), this,SLOT(robot_getBoxState(BoxInfo)));
    connect( this->myRobot, SIGNAL(signal_arriveTaskPoint(int)), this,SLOT(slot_arriveTaskPoint_getTaskPointID(int)));
    connect( this->myRobot, SIGNAL(signal_leaveTaskPoint(int)), this,SLOT(slot_leaveTaskPointt_getTaskPointID(int)));

    connect( &(this->newOrderInfoWidget), SIGNAL(signal_updadeNewMsgNum(int)), this,SLOT (newOrderInfoWidget_updateMsgNum(int)));

    connect( &(this->startDeliveryWidget), SIGNAL(signal_openBox_startDelivery(std::vector<int>)), this,SLOT (boxInfoWidget_openBox(std::vector<int>)));
    connect( &(this->startDeliveryWidget), SIGNAL(signal_startTaskPlan()), this,SLOT (startDeliveryWidegt_startTaskPlan()));
    connect( &(this->startDeliveryWidget), SIGNAL(signal_exeSchedulePlanAlgorithm()), this,SLOT (on_button_parcelLoading_clicked()));

    connect( &(this->statisticalReportWidget), SIGNAL(signal_exeOutputTable(QString)), this,SLOT (sendSocketToLogistic(QString)));

    connect( &(this->tcpIpSever_Logistic), SIGNAL(signal_acceptMsgFromClient()), this,SLOT (slot_acceptMsgFromLogistic()));

    connect( &(this->rejectionCheckWidget.agreeRejection), SIGNAL(signal_agree_rejection(QString)), this,SLOT (rejectionWidget_agree(QString)));
    connect( &(this->rejectionCheckWidget.disagreeRejection), SIGNAL(signal_disagree_rejection(QString)), this,SLOT (rejectionWidget_disagree(QString)));
    connect( &(this->rejectionCheckWidget), SIGNAL(signal_boxIDCluster_rejection(std::vector<QString>)), this,SLOT (rejectionWidget_boxIDCluster(std::vector<QString>)));

    connect( &(this->parcelManagementWidget.parcelInfoWidget.detentionReasonWidget), SIGNAL(signal_parcelInfoWidget_changeDetention(QString)), this,SLOT (parcelInfoWidget_changeDetention(QString)));
    connect( &(this->parcelManagementWidget.parcelInfoWidget), SIGNAL(signal_parcelInfoWidget_changeMan(QString)), this,SLOT (parcelInfoWidget_changeMan(QString)));

    //test
    connect(this->ui->pushButton,SIGNAL(clicked()),this,SLOT(slot_arriveTaskPointAfterTenMinutes()));
    connect(this->ui->pushButton_2,SIGNAL(clicked()),this,SLOT(slot_arriveTaskPoint()));
    connect(this->ui->pushButton_3,SIGNAL(clicked()),this,SLOT(slot_returnStation()));
    connect(this->ui->pushButton_4,SIGNAL(clicked()),this,SLOT(slot_boxClose()));
    connect(this->ui->pushButton_6,SIGNAL(clicked()),this,SLOT(slot_leaveTaskPointt_getTaskPointID()));
}

void MainWindow::initUi()
{
    ui->setupUi(this);
    this->setWindowTitle("物流配送监控");
    // 固定窗口的大小
    this->setFixedSize(this->width(), this->height());

    timer = new QTimer();
    timer->start(1000);
    timer_mapRefresh = new QTimer();
    timer_InfoRefresh = new QTimer();
    timer_dbRefresh = new QTimer();
    //加载百度地图
    ui->webView->settings()->setAttribute(QWebSettings::JavascriptEnabled,true);//使能javascript
    ui->webView->settings()->setAttribute(QWebSettings::PluginsEnabled,true);//Qt窗口部件嵌入到网页
    addJavaScriptObject();
    QString mapHtmlUrl = "file:///home/zlp/qt_test/test1/htmlapi/baiduapi.html";
    ui->webView->load(mapHtmlUrl);
    //ui->webView->setUrl(QUrl("/home/zlp/qt_test/test1/htmlapi/baiduapi.html"));
    //ui->webView->show();
    //设置背景颜色
    this->setAutoFillBackground(true);//这个语句很重要，没有的话，子widget背景色修改不成功
    QPalette myPalette;
    myPalette.setBrush(backgroundRole(),QColor(10,20,35));
    this->setPalette(myPalette);
    //设置信息显示框的透明度，字体颜色
    ui->tabWidget->setStyleSheet("QTabWidget:pane {border-top:0px solid #e8f3f9;background:  transparent; }"
                                 "QTabBar::tab { height: 30px; width:90px;background-color:rgb(20,20,20); color: rgb(230,230,255);   border-radius: 1px; }"
                                 "QTabBar::tab:selected { background-color:rgb(125, 125, 125);   border: rgb(15 , 150 , 255); padding-left:-1px;  padding-top:-1px } ");
    ui->tabWidget->setCurrentIndex(0);
    ui->textBrowser_task->setStyleSheet("background-color:rgba(50,50,50,80)");
    ui->textBrowser_task->setTextColor(TEXT_COLOR);
    ui->textBrowser_task->setText( QString ("物流信息"));
    ui->textBrowser_parcel->setStyleSheet("background-color:rgba(50,50,50,80)");
    ui->textBrowser_parcel->setTextColor(TEXT_COLOR);
    ui->textBrowser_parcel->setText( QString ("包裹信息"));

    ui->tabWidget_2->setStyleSheet("QTabWidget:pane {border-top:0px solid #e8f3f9;background:  transparent; }"
                                   "QTabBar::tab { height: 30px; width:80px;background-color:rgb(20,20,20); color: rgb(230,230,255);   border-radius: 1px; }"
                                   "QTabBar::tab:selected { background-color:rgb(125, 125, 125);   border: rgb(15 , 150 , 255); padding-left:-1px;  padding-top:-1px } ");
    ui->tabWidget_2->setCurrentIndex(0);
    ui->textBrowser_vehicle->setStyleSheet("background-color:rgba(50,50,50,80)");
    ui->textBrowser_vehicle->setTextColor(TEXT_COLOR);
    ui->textBrowser_vehicle->setText( QString("车辆信息"));
    ui->textBrowser_road->setStyleSheet("background-color:rgba(50,50,50,80)");
    ui->textBrowser_road->setTextColor(TEXT_COLOR);
    ui->textBrowser_road->setText(QString ("路况信息"));
    ui->textBrowser_system->setStyleSheet("background-color:rgba(50,50,50,80)");
    ui->textBrowser_system->setTextColor(TEXT_COLOR);
    ui->textBrowser_system->setText(QString ("系统信息"));


    //设置按钮风格
    QString button_style="QPushButton{background-color:rgb(20,20,20); color: rgb(230,230,255);   border-radius: 2px;  border: 1px solid rgb(183 , 183 , 183);}"
                         "QPushButton:hover{background-color:rgb(40,40,40); color: rgb(230,230,255);  border: 1px solid rgb(15 , 150 , 255);}"
                         "QPushButton:pressed{background-color:rgb(30, 30, 30);    border: 1px solid rgb(15 , 150 , 255); padding-left:1px;  padding-top:1px;}";
    ui->button_cameraSet->setStyleSheet(button_style);
    ui->button_cameraSet->setFocusPolicy(Qt::NoFocus);
    ui->button_operationExchange->setStyleSheet(button_style);
    ui->button_operationExchange->setFocusPolicy(Qt::NoFocus);
    ui->button_vehicleStart->setStyleSheet(button_style);
    ui->button_vehicleStart->setFocusPolicy(Qt::NoFocus);
    ui->button_monitorStart->setStyleSheet(button_style);
    ui->button_monitorStart->setFocusPolicy(Qt::NoFocus);
    ui->button_sysRestart->setStyleSheet(button_style);
    ui->button_sysRestart->setFocusPolicy(Qt::NoFocus);

    ui->button_statisticalReport->setStyleSheet(button_style);
    ui->button_statisticalReport->setFocusPolicy(Qt::NoFocus);

    ui->button_messageHandle->setStyleSheet(button_style);
    ui->button_messageHandle->setFocusPolicy(Qt::NoFocus);
    ui->button_startDelivery->setStyleSheet(button_style);
    ui->button_startDelivery->setFocusPolicy(Qt::NoFocus);
    ui->button_parcelLoading->setStyleSheet(button_style);
    ui->button_parcelLoading->setFocusPolicy(Qt::NoFocus);
    ui->button_remainingHandle->setStyleSheet(button_style);
    ui->button_remainingHandle->setFocusPolicy(Qt::NoFocus);

    ui->button_rejectionCheck->setStyleSheet(button_style);
    ui->button_rejectionCheck->setFocusPolicy(Qt::NoFocus);
    ui->button_parcelManagement->setStyleSheet(button_style);
    ui->button_parcelManagement->setFocusPolicy(Qt::NoFocus);

    //message num
    QPalette   pal;
    pal.setColor(QPalette::ButtonText, QColor(255,255,255));
    ui->pushButton_msgNum->setPalette(pal);
    ui->pushButton_msgNum->setStyleSheet("border-radius:13px;background-color: rgb(255, 0, 0);");
    ui->pushButton_msgNum->setFocusPolicy(Qt::NoFocus);
    ui->pushButton_msgNum->setDisabled(true);
    ui->pushButton_msgNum->hide();
    //ui->button_cameraSet->hide();
    //设置弹出窗口的位置（在屏幕中央）
    QDesktopWidget *deskdop=QApplication::desktop();
    this->move((deskdop->width()-this->width())/2,(deskdop->height()-this->height())/2);

//    ui->pushButton->hide();
//    ui->pushButton_2->hide();
//    ui->pushButton_3->hide();
//    ui->pushButton_4->hide();
//    ui->pushButton_5->hide();
//    ui->pushButton_6 ->hide();
//    ui->lineEdit->hide();
//    ui->button_cameraSet->hide();

}
//JavaScript和Qt对象交互
void MainWindow::addJavaScriptObject()
{
    //将本地的QObject对象暴露给webkit和JavaScript,javascript可以通过对象名***,访问***对象。
    //JavaScript调用Qt对象
    //qDebug()<<"addJavaScriptObject";
    this->ui->webView->page()->mainFrame()->addToJavaScriptWindowObject(QString("myRobot"),this->myRobot);
}
void MainWindow::refreshBaiduMapAll()
{
    qDebug()<<"refreshBaiduMapAll";
    //Qt对象调用JavaScript
    QTime time;
    time.start();

    this->ui->webView->page()->mainFrame()->evaluateJavaScript("refreshDataAll();");
    int time_Diff = time.elapsed();
    qDebug()<<time_Diff;
}
void MainWindow::refreshBaiduMapVehicle()
{
    myRobot->getVehicelCoor();
    this->ui->webView->page()->mainFrame()->evaluateJavaScript("refreshDataVehicle();");
}
void MainWindow::refreshBaiduMapTask()
{
    qDebug()<<"refreshBaiduMapTask";
    this->ui->webView->page()->mainFrame()->evaluateJavaScript("refreshDataTask();");
}
void MainWindow::showTime()
{
    //获取系统时间
    QDateTime time = QDateTime::currentDateTime();//获取系统现在的时间
    QString str = time.toString("yyyy-MM-dd hh:mm:ss ddd"); //设置显示格式
    QPalette fontColor;
    fontColor.setColor(QPalette::WindowText, Qt::white);
    ui->label_time->setPalette(fontColor);
    ui->label_time->setText(str);//在标签上显示时间
}
string MainWindow::changeTimeFormat(string str_time)
{
    size_t pos = str_time.find('-');
    str_time.erase(pos,1);
    pos = str_time.find('-');
    str_time.erase(pos,1);
    pos = str_time.find(' ');
    str_time.erase(pos,1);
    pos = str_time.find(':');
    str_time.erase(pos,1);
    pos = str_time.find(':');
    str_time.erase(pos,1);
    return str_time;
}
//子窗口设置
void MainWindow::on_button_operationExchange_clicked()
{
    teleoperation.show();
    teleoperation.setSysState();

    ui->textBrowser_systemState ->setTextColor(QColor(255,0,0));
    ui->textBrowser_systemState->setText("已切换至手动驾驶...");
    ui->textBrowser_systemState->setTextColor(QColor(0,0,0));
    //send message
    Json::Value root;
    Json::FastWriter fast;
    root["Name"]=("operation_exchange");
    root["Cmd"]=("teleoperation");
    std::string str=fast.write(root) ;
    this->myRobot->tcpIpSever.sendMessage(str);
}
void MainWindow::on_button_cameraSet_clicked()
{
    cameraSetWidget.show();
}

void MainWindow::on_button_sysRestart_clicked()
{
    ui->textBrowser_systemState ->setTextColor(QColor(255,0,0));
    ui->textBrowser_systemState->setText("系统重启...");
    ui->textBrowser_systemState->setTextColor(QColor(0,0,0));

    //send message
    Json::Value root;
    Json::FastWriter fast;
    root["Name"]=("device_control");
    root["Cmd"]=("restart");
    std::string str=fast.write(root) ;
    this->myRobot->tcpIpSever.sendMessage(str);
}
void MainWindow::on_button_monitorStart_clicked()
{
    ui->textBrowser_systemState ->setTextColor(QColor(255,0,0));
    ui->textBrowser_systemState->setText("监控开始...");
    ui->textBrowser_systemState->setTextColor(QColor(0,0,0));

    refreshBaiduMapAll();

    timer_mapRefresh->start(1000);
    timer_InfoRefresh->start(2000);
    timer_dbRefresh->start(5000);
}

void MainWindow::on_button_vehicleStart_clicked()
{
    ui->textBrowser_systemState ->setTextColor(QColor(255,0,0));
    ui->textBrowser_systemState->setText("车辆启动...");
    ui->textBrowser_systemState->setTextColor(QColor(0,0,0));
    //send message
    Json::Value root;
    Json::FastWriter fast;
    root["Name"]=("vehicle_start");
    root["Cmd"]=("start");
    std::string str=fast.write(root) ;
    this->myRobot->tcpIpSever.sendMessage(str);

    //更新数据库小车线路规划表
    updateDB_vehicleRoutePlanTable();
    updateDB_vehicleGeoInfo_currentStopID(0);
    //从配送站出发指令（发给物流）
    string len = "0059";
    string type = "F001";
    string msg_send = generateMsgHead(len , type);

    msg_send.append("1");
    tcpIpSever_Logistic.sendMessage(msg_send);
    qDebug()<<"从配送站出发指令（发给物流） send";
    qDebug()<<QString::fromStdString(msg_send);

    isArriveTaskPoint = false;
}
void MainWindow::on_button_statisticalReport_clicked()
{
    statisticalReportWidget.show();
    statisticalReportWidget.resetDisplayData();
}
void MainWindow::on_button_messageHandle_clicked()
{
    newOrderInfoWidget.show();
    newOrderInfoWidget.getUpdateParcelState();
}

void MainWindow::on_button_parcelManagement_clicked()
{
    parcelManagementWidget.show();
    parcelManagementWidget.resetDisplayData();
}
void MainWindow::on_button_parcelLoading_clicked()
{
    //发送给物流进程socket,更新数据库中排班表格；
    string len = "0059";
    string type = "1001";
    string msg_send = generateMsgHead(len , type);
    //msg body
    msg_send.append("1");
    //send to client
    tcpIpSever_Logistic.sendMessage(msg_send);
    qDebug()<<"排班表格 socket : "<<QString::fromStdString(msg_send);
    parcelLoadingWidget.show();
    parcelLoadingWidget.setUIBeforeGetData();
    //getParcelInfoAfterSchedule();
}
void MainWindow::getParcelInfoAfterSchedule()
{
    //放在下面的程序中执行
    if(1)
    {
        if(parcelLoadingWidget.getAllParcleTobeLoaded() == 1)
        {
            qDebug()<<"%%%%%%%%%%%%%%%";
            parcelLoadingWidget.updateTableWidget();
            parcelLoadingWidget.resetUI();
        }
        else
        {
            parcelLoadingWidget.setText("没有查询到待装车的包裹，\n请检查装车流程或核对数据库 !");
            //QMessageBox::information(NULL, "提示", "没有查询到待装车的包裹，\n请检查装车流程或核对数据库 !\n");
        }
    }
    else
    {
        QMessageBox::information(NULL, "提示", "包裹装车 socket 发送失败 !\n");
    }
}
void MainWindow::on_button_remainingHandle_clicked()
{
    if(remainingParcelWidget.getAllRemainingParcelInfoFromDB() ==1)
    {
        remainingParcelWidget.show();
        remainingParcelWidget.updateTableWidget();
        remainingParcelWidget.resetUI();
    }
    else
        QMessageBox::information(NULL, "提示", "无需要回收的包裹 !\n");
}
void MainWindow::on_button_startDelivery_clicked()
{
    if(startDeliveryWidget.refreshTimes == 0)
    {
        int status = startDeliveryWidget.getAllParcleTobeCancellFromDB();
        startDeliveryWidget.setFirstRefreshUI();
        startDeliveryWidget.show();
        startDeliveryWidget.updateTableWidget();

    }
    else
    {
        int status = startDeliveryWidget.getAllParcleTobeCancellFromDB();
        startDeliveryWidget.setSecondRefreshUI();
        startDeliveryWidget.show();
        startDeliveryWidget.updateTableWidget();
    }
}
void MainWindow::on_button_rejectionCheck_clicked()
{
    //parcelID_pj get from socket
    QString parcelID_pj = "O17081400000122";
    rejectionCheckWidget.getParcelID_vpFromLogistics(parcelID_pj);
    if(rejectionCheckWidget.getAllRejectionParcelInfoFromDB())
    {
        rejectionCheckWidget.show();
        rejectionCheckWidget.updateTableWidget();
    }
}

//不同类对象之间通信
void MainWindow::teleoperationWidget_BoxAskShow()
{
    if(boxInfoWidget.parcelIDClu.size() != 0)
        boxInfoWidget.updateBox();
    boxInfoWidget.show();
}
void MainWindow::teleoperationWidget_VehicleAskShow()
{
    vehicleInfoWidget.show();
}

void MainWindow::teleoperationWidget_VehicleTurnLeft()
{
    Json::Value root;
    Json::FastWriter fast;
    root["Name"]=("vehicle_control");
    root["Cmd"]=("turn_left");
    std::string str=fast.write(root) ;
    this->myRobot->tcpIpSever.sendMessage(str);
}
void MainWindow::teleoperationWidget_VehicleTurnRight()
{
    Json::Value root;
    Json::FastWriter fast;
    root["Name"]=("vehicle_control");
    root["Cmd"]=("turn_right");
    std::string str=fast.write(root) ;
    this->myRobot->tcpIpSever.sendMessage(str);
}
void MainWindow::teleoperationWidget_VehicleForward()
{
    Json::Value root;
    Json::FastWriter fast;
    root["Name"]=("vehicle_control");
    root["Cmd"]=("forward");
    std::string str=fast.write(root) ;
    this->myRobot->tcpIpSever.sendMessage(str);
}
void MainWindow::teleoperationWidget_VehicleBackward()
{
    Json::Value root;
    Json::FastWriter fast;
    root["Name"]=("vehicle_control");
    root["Cmd"]=("backward");
    std::string str=fast.write(root) ;
    this->myRobot->tcpIpSever.sendMessage(str);
}
void MainWindow::teleoperationWidget_VehicleStop()
{
    Json::Value root;
    Json::FastWriter fast;
    root["Name"]=("vehicle_control");
    root["Cmd"]=("stop");
    std::string str=fast.write(root) ;
    this->myRobot->tcpIpSever.sendMessage(str);
}
void MainWindow::teleoperationWidget_VehicleStart()
{
    Json::Value root;
    Json::FastWriter fast;
    root["Name"]=("vehicle_control");
    root["Cmd"]=("start");
    std::string str=fast.write(root) ;
    this->myRobot->tcpIpSever.sendMessage(str);
}
void MainWindow::teleoperationWidget_VehicleHorn()
{
    Json::Value root;
    Json::FastWriter fast;
    root["Name"]=("vehicle_control");
    root["Cmd"]=("horn");
    std::string str=fast.write(root) ;
    this->myRobot->tcpIpSever.sendMessage(str);
}
void MainWindow::teleoperationWidget_VehicleLight()
{
    Json::Value root;
    Json::FastWriter fast;
    root["Name"]=("vehicle_control");
    root["Cmd"]=("light_open");
    std::string str=fast.write(root) ;
    this->myRobot->tcpIpSever.sendMessage(str);
}
void MainWindow::teleoperationWidget_VehicleLightClose()
{
    Json::Value root;
    Json::FastWriter fast;
    root["Name"]=("vehicle_control");
    root["Cmd"]=("light_close");
    std::string str=fast.write(root) ;
    this->myRobot->tcpIpSever.sendMessage(str);
}
void MainWindow::teleoperationWidget_VehicleControlCmd(int vel, int alpha)
{
    qDebug()<<"vel = "<<vel;
    qDebug()<<"alpha = "<<alpha;
    Json::Value root;
    Json::FastWriter fast;
    root["Name"]=("vehicle_control");
    root["Cmd"]=("vel_alpha");
    root["vel"]=(QString::number(vel).toStdString());
    root["alpha"]=(QString::number(alpha).toStdString());
    std::string str=fast.write(root) ;
    this->myRobot->tcpIpSever.sendMessage(str);
}
void MainWindow::teleoperationWidget_OperationExchange()
{
    Json::Value root;
    Json::FastWriter fast;
    root["Name"]=("operation_exchange");
    root["Cmd"]=("auto");
    std::string str=fast.write(root) ;
    this->myRobot->tcpIpSever.sendMessage(str);

    ui->textBrowser_systemState ->setTextColor(QColor(255,0,0));
    ui->textBrowser_systemState->setText("已切换至自动驾驶...");
    ui->textBrowser_systemState->setTextColor(QColor(0,0,0));
    qDebug()<<"已切换至自动驾驶";
}


void MainWindow::boxInfoWidget_openBox(std::vector<int> boxIndex)
{
    Json::Value root;
    Json::Value boxArry;
    Json::FastWriter fast;
    root["Name"]=("device_control");
    for(int i=1; i<21; i++)
    {
        if(std::find(boxIndex.begin(), boxIndex.end(), i) != boxIndex.end())
            boxArry.append("1");
        else
            boxArry.append("0");
    }

    root["Box_Info"]=boxArry;
    string out = root.toStyledString();
    cout<<out<<std::endl;
    std::string str=fast.write(root) ;
    this->myRobot->tcpIpSever.sendMessage(str);
}
void MainWindow::newOrderInfoWidget_updateMsgNum(int num)
{
    if(num == 0)
        ui->pushButton_msgNum->hide();
    else
    {
        ui->pushButton_msgNum->show();
        ui->pushButton_msgNum->setText(QString::number(num));
    }
}
void MainWindow::startDeliveryWidegt_startTaskPlan()
{
    taskPlanWidget.show();
    taskPlanWidget.setPixmapPlanning();
    sleep(100);
    //从数据库 db_vip.transport_sn_scheduling_plan 中读取最新的排班数据
    if(getTaskSeqAndInfoAccordingDB())
    {
        // 把装车的包裹运单号 传给遥操作类
        boxInfoWidget.getParcelIDCluAfterTaskPlan(parcelIDClu);
        boxInfoWidget.updateBox();

        if(taskSeq.size() != 0 && (taskSeq.size() == taskInfoClu.size()))
        {
            this->myRobot->taskSeq.clear();
            this->myRobot->taskSeq = taskSeq;
            this->myRobot->taskPointCluster.clear();
            for(int i =0;i<taskSeq.size();i++)
            {
                int taskID = taskSeq[i];
                taskPoint taskPointTmp;
                taskPointTmp.ID = taskID;
                taskPointTmp.longitude = myRobot->pathPointID2Coordinate[taskID].first;
                taskPointTmp.latitude = myRobot->pathPointID2Coordinate[taskID].second;
                taskPointTmp.taskInfo = taskInfoClu[i];
                myRobot->taskPointCluster.push_back(taskPointTmp);
            }

            result res = myRobot->executeTaskPlan();
            myRobot->sendMessageToVehicle();

            //dispaly
            cout<<"is Valid = "<<res.isValid<<endl;
            cout<<"dis = "<<res.dis<<endl;
            cout<<"node Num = "<<res.path.size()<<endl;
            for(int i=0; i<res.path.size();i++)
            {
                cout<<res.path[i]<<" ";
            }
            cout<<endl;

            taskPlanWidget.setPixmapPlanSuccess();
            taskPlanWidget.TaskPlanInfoShow(res);
        }
        else
            QMessageBox::information(NULL, "提示", "任务规划信息格式不正确 !\n");
    }
    else
    {
        QMessageBox::information(NULL, "提示", "站点序列不正确，存在未定义的站点标号 !\n");
    }

}
bool MainWindow::getTaskSeqAndInfoAccordingDB()
{
    taskSeqTmp.clear();
    parcelIDClu.clear();
    //read from DB
    MyDB mydb;
    if( !mydb.initDB("localhost","root","vip","db_vip"))
    {
        QMessageBox::information(NULL, "提示", "数据库连接失败 !\n");
        return false;
    }
    else
    {
        //从数据库 db_vip.transport_sn_scheduling_plan 中读取最新的排班数据
        std::string query =  "select * from db_vip.transport_sn_scheduling_plan";
        std::vector<std::vector<std::string> > result;
        if( !mydb.exeSQL(query, result))
        {
            QMessageBox::information(NULL, "提示", "查询 db_vip.messages 失败 !\n");
            return false;
        }
        else
        {
            qDebug()<<"query db_vip.transport_sn_scheduling_plan ";
            for(int i = 0; i<result[0].size();i++)
            {
                QString transport_sn = QString::fromStdString(result[0][i]);
                QString time_slot_id  = QString::fromStdString(result[1][i]);
                QString stop_id = QString::fromStdString(result[2][i]);
                taskSeqTmp.insert(stop_id.toInt());
                parcelIDClu.push_back(transport_sn);
                taskClu_withRepeat.push_back(stop_id.toInt());
            }
            qDebug()<<taskSeqTmp.size();
        }
        //db_vip.transport_sns 获取相应运单号包裹的信息
        nameClu.clear();
        phoneClu.clear();
        for(int i =0;i<parcelIDClu.size();i++)
        {
            string query = "select receiver_name,receiver_mobile from db_vip.transport_sns where transport_sn=";
            query += "\'";
            query += parcelIDClu[i].toStdString();
            query += "\'";
            //qDebug()<<QString::fromStdString(query);
            vector<vector<string> > result_transport_sn;
            if( !mydb.exeSQL(query, result_transport_sn))
            {
                qDebug()<<"query ..............";
                QMessageBox::information(NULL, "提示", "查询 transport_sns 失败 !\n");
                return false;
            }
            else
            {
                //qDebug()<<"query transport_sns";
                if(result_transport_sn[0].size() == 0)
                {
                    nameClu.push_back("null");
                    phoneClu.push_back("null");
                }
                else
                {
                    nameClu.push_back(QString::fromStdString(result_transport_sn[0][0]));
                    phoneClu.push_back(QString::fromStdString(result_transport_sn[1][0]));
                }
            }
        }
    }
    //获取初始任务序列，规划之前
    taskSeq.clear();
    set<int>::iterator iter;
    for(iter = taskSeqTmp.begin() ; iter != taskSeqTmp.end() ; ++iter)
    {
        taskSeq.push_back(*iter);
    }

    //    //    //for test
//    taskSeq.clear();

//    taskSeq.push_back(1);
//    taskSeq.push_back(2);
//    taskSeq.push_back(3);
//    taskSeq.push_back(4);
//    taskSeq.push_back(5);
//    taskSeq.push_back(6);
//    taskSeq.push_back(7);
//    taskSeq.push_back(8);
//    taskSeq.push_back(9);
//    taskSeq.push_back(10);
//    taskSeq.push_back(11);
//    taskSeq.push_back(12);
//    taskSeq.push_back(14);
//    taskSeq.push_back(15);
//    taskSeq.push_back(16);
//    taskSeq.push_back(17);
//    taskSeq.push_back(18);
//    taskSeq.push_back(34);
//    taskSeq.push_back(35);


    if(checkTaskSeg())
    {
        taskInfoClu.clear();
        for(int i =0; i<taskSeq.size();i++)
        {
            QString taskInfo;
            QString taskName, taskIDStr;
            QString parcelID, name, phoneNumber;

            taskName = TaskPointMap[taskSeq[i]];
            taskIDStr = QString::number(taskSeq[i]);

            taskInfo.append("任务点名称: ");
            taskInfo.append(taskName);
            taskInfo.append(" ; 任务点编号: ");
            taskInfo.append(taskIDStr);
            taskInfo.append("<br>");
            taskInfo.append("编号  订单号 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 姓名 &nbsp;&nbsp;  手机号 <br>");

            int cnt = std::count(taskClu_withRepeat.begin(),taskClu_withRepeat.end(),taskSeq[i]);
            int index = 0;
            for(int j=0; j<cnt;j++)
            {
                for(int k = index; k<taskClu_withRepeat.size();k++)
                {
                    if(taskClu_withRepeat[k] == taskSeq[i])
                    {
                        index = i;
                        break;
                    }
                }
                taskInfo.append(QString::number(j+1));
                taskInfo.append("&nbsp; ");
                taskInfo.append(parcelIDClu[index]);
                taskInfo.append(" ");
                taskInfo.append(nameClu[index]);
                if(name.size() == 2)
                    taskInfo.append("&nbsp;&nbsp; ");
                else
                    taskInfo.append("&nbsp");
                taskInfo.append(phoneClu[index]);
                taskInfo.append("<br>");

                index ++;
            }
            taskInfoClu.push_back(taskInfo);
        }
        return true;
    }
    else
        return false;
}
bool MainWindow::checkTaskSeg()
{
    std::vector<int> taskSeqTmp;
    taskSeqTmp.push_back(1);
    taskSeqTmp.push_back(2);
    taskSeqTmp.push_back(3);
    taskSeqTmp.push_back(4);
    taskSeqTmp.push_back(5);
    taskSeqTmp.push_back(6);
    taskSeqTmp.push_back(7);
    taskSeqTmp.push_back(8);
    taskSeqTmp.push_back(9);
    taskSeqTmp.push_back(10);
    taskSeqTmp.push_back(11);
    taskSeqTmp.push_back(12);
    taskSeqTmp.push_back(14);
    taskSeqTmp.push_back(15);
    taskSeqTmp.push_back(16);
    taskSeqTmp.push_back(17);
    taskSeqTmp.push_back(18);

    //taskSeqTmp.push_back(19);
    taskSeqTmp.push_back(34);
    taskSeqTmp.push_back(35);

    for(int i=0;i<taskSeq.size();i++)
    {
        if(std::find(taskSeqTmp.begin(),taskSeqTmp.end(),taskSeq[i]) == taskSeqTmp.end())
            return false;
    }
    return true;
}
//mainwidow上的左上和右上显示框内容更新
void MainWindow::showVehicleInfo()
{
    if(myRobot->carInfo.miles_left < 150 && isArriveTaskPoint == false && nextTaskPoint != 0)
    {
        isArriveTaskPoint = true;
        qDebug()<<"arrive task point  10 minutes";
        slot_arriveTaskPointAfterTenMinutes();
    }

    ui->textBrowser_vehicle->setTextColor(TEXT_COLOR);
    QString text;
    text.append("车辆编号 : ");
    text.append( this->myRobot->carInfo.ID );
    text.append("\n");
    text.append("车辆位置 : ");
    text.append( QString::number(this->myRobot->carInfo.longitude) );
    text.append(" , ");
    text.append( QString::number(this->myRobot->carInfo.latitude) );
    text.append("\n");
    text.append("车辆速度 : ");
    text.append( QString::number(this->myRobot->carInfo.vel) );
    text.append("\n");
    text.append("剩余里程 : ");
    text.append( QString::number(this->myRobot->carInfo.miles_left) );
    text.append("\n");
    text.append("电量显示 : ");
    text.append( QString::number(this->myRobot->carInfo.battery) );
    text.append("\n");
    text.append("车辆状态 : ");
    text.append( QString::number(this->myRobot->carInfo.state) );

    ui->textBrowser_vehicle->setText(text);
    vehicleInfoWidget.setVehicleInfo(text);
}
void MainWindow::showRoadInfo()
{
    ui->textBrowser_road->setTextColor(TEXT_COLOR);
    QString text;
    text.append("道路通行状态 : ");
    text.append(QString::number(this->myRobot->roadInfo.passable));
    text.append("\n");

    if(myRobot->roadInfo.ultrasonicObstacleDistance.size() != 12)
    {
        myRobot->roadInfo.ultrasonicObstacleDistance.clear();
        for(int i=0; i<12;i++)
            myRobot->roadInfo.ultrasonicObstacleDistance.push_back(0);
    }
    else
    {
        text.append("超声-1 : ");
        text.append(QString::number(myRobot->roadInfo.ultrasonicObstacleDistance[0]));
        text.append("    |    超声-2 : ");
        text.append(QString::number(myRobot->roadInfo.ultrasonicObstacleDistance[1]));
        text.append("\n");
        text.append("超声-3 : ");
        text.append(QString::number(myRobot->roadInfo.ultrasonicObstacleDistance[2]));
        text.append("    |    超声-4 : ");
        text.append(QString::number(myRobot->roadInfo.ultrasonicObstacleDistance[3]));
        text.append("\n");
        text.append("超声-5 : ");
        text.append(QString::number(myRobot->roadInfo.ultrasonicObstacleDistance[4]));
        text.append("    |    超声-6 : ");
        text.append(QString::number(myRobot->roadInfo.ultrasonicObstacleDistance[5]));
        text.append("\n");
        text.append("超声-7 : ");
        text.append(QString::number(myRobot->roadInfo.ultrasonicObstacleDistance[6]));
        text.append("    |    超声-8 : ");
        text.append(QString::number(myRobot->roadInfo.ultrasonicObstacleDistance[7]));
        text.append("\n");
        text.append("超声-9 : ");
        text.append(QString::number(myRobot->roadInfo.ultrasonicObstacleDistance[8]));
        text.append("    |    超声-10 : ");
        text.append(QString::number(myRobot->roadInfo.ultrasonicObstacleDistance[9]));
        text.append("\n");
        text.append("超声-11 : ");
        text.append(QString::number(myRobot->roadInfo.ultrasonicObstacleDistance[10]));
        text.append("  |    超声-12 : ");
        text.append(QString::number(myRobot->roadInfo.ultrasonicObstacleDistance[11]));
    }
    ui->textBrowser_road->setText(text);
}
void MainWindow::showSysInfo()
{
    ui->textBrowser_system->setTextColor(TEXT_COLOR);
    QString text;
    text.append("通信状态 : ");
    if(this->myRobot->sysInfo.communicationState == 0)
        text.append("断开");
    else
        text.append("良好");
    text.append("\n");
    text.append("激光状态 : ");
    text.append(QString::number(this->myRobot->sysInfo.laserState));
    text.append("\n");
    text.append("雷达状态 : ");
    text.append(QString::number(this->myRobot->sysInfo.radarState));
    text.append("\n");
    text.append("超声状态 : ");
    text.append(QString::number(this->myRobot->sysInfo.ultrasonicState));

    ui->textBrowser_system->setText(text);
}
void MainWindow::showTaskInfo()
{
    ui->textBrowser_task->setTextColor(TEXT_COLOR);
    QString text;
    if(myRobot->taskSeqCompleted.size() == 0)
    {
        text.append("所有任务: ");
        text.append(QString::number(taskSeq_plan.size()));
        text.append("\n");
        text.append("当前任务: ");
        text.append("0");
        text.append("\n");
        text.append("完成任务: ");
        text.append("0");
        text.append("\n");
        text.append("剩余任务: ");
        text.append("0");
        text.append("\n");
        text.append("任务进度: ");
        text.append("0");
        text.append("%");
        text.append("\n");
        text.append("任务序列: ");
        QString taskSeqStr;
        for (int i=0;i<taskSeq_plan.size();i++)
        {
            taskSeqStr.append(QString::number(taskSeq_plan[i]));
            if( i != taskSeq_plan.size() -1)
                taskSeqStr.append(",");
        }
        text.append(taskSeqStr);
    }
    else
    {
        text.append("所有任务: ");
        text.append(QString::number(taskSeq_plan.size()));
        text.append("\n");
        text.append("当前任务: ");
        text.append(QString::number(myRobot->taskSeqCompleted[myRobot->taskSeqCompleted.size()-1]));
        text.append("\n");
        text.append("完成任务: ");
        text.append(QString::number(myRobot->taskSeqCompleted.size()-1));
        text.append("\n");
        text.append("剩余任务: ");
        text.append(QString::number(taskSeq_plan.size() - myRobot->taskSeqCompleted.size() + 1));
        text.append("\n");
        text.append("任务进度: ");
        if(taskSeq_plan.size() != 0)
            text.append(QString::number((myRobot->taskSeqCompleted.size()-1)/taskSeq_plan.size()));
        else
            text.append("error");
        text.append("%");
        text.append("\n");
        text.append("任务序列: ");
        QString taskSeqStr;
        for (int i=0;i<taskSeq_plan.size();i++)
        {
            taskSeqStr.append(QString::number(taskSeq_plan[i]));
            if( i != taskSeq_plan.size() -1)
                taskSeqStr.append(",");
        }
        text.append(taskSeqStr);
    }
    ui->textBrowser_task->setText(text);
}
void MainWindow::showParcelInfo()
{
    ui->textBrowser_parcel->setTextColor(TEXT_COLOR);
    QString text;
    if(myRobot->taskSeqCompleted.size() == 0)
    {
        text.append("当前任务: ");
        text.append("0");
        text.append("\n");
        text.append("包裹数量: ");
        text.append("0");
        text.append("\n");
        text.append("包裹状态: "); //到达，在途
        text.append("无");
        text.append("\n");
        text.append("目的地    : ");
        text.append("无");
    }
    else
    {
        int taskPointID = nextTaskPoint;

        text.append("当前任务: ");
        text.append(QString::number(taskPointID));
        text.append("\n");
        text.append("包裹数量: ");
        text.append(currentTaskPointParcelNum);
        text.append("\n");
        text.append("包裹状态: "); //到达，在途
        text.append(currentTaskPointParcelStatus);
        text.append("\n");
        text.append("目的地    : ");
        text.append(TaskPointMap[taskPointID]);

    }
    ui->textBrowser_parcel->setText(text);
}
void MainWindow::updateTeleoperationRobotInfo()
{
    teleoperation.updateRobotInfo(myRobot);
}
void MainWindow::updateDB_vehicleGeoInfo_currentStopID(int currentTaskPointID)
{
    //update DB
    MyDB mydb;
    if( !mydb.initDB("localhost","root","vip","db_vip"))
    {
        QMessageBox::information(NULL, "提示", "数据库连接失败 !\n");
        return;
    }
    else
    {
        string update = "update db_vip.vehicle_geo_infos set ";
        update += "current_stop_id=";
        update += "\'";
        update += QString::number(currentTaskPointID).toStdString();
        update += "\'";
        update += " where vehicle_id=";
        update += "\'";
        update += myRobot->carInfo.ID.toStdString();
        update += "\'";
        if( !mydb.updateData(update))
        {
            QMessageBox::information(NULL, "提示", "更新当前车辆站点ＩＤ信息失败 !\n");
            return;
        }
        else
        {
            qDebug()<<"update  vehicle current_stop_id success";
            return;
        }
    }
}
void MainWindow::updateDB_vehicleGeoInfo_nextStopID(int nextTaskPointID)
{
    //update DB
    MyDB mydb;
    if( !mydb.initDB("localhost","root","vip","db_vip"))
    {
        QMessageBox::information(NULL, "提示", "数据库连接失败 !\n");
        return;
    }
    else
    {
        string update = "update db_vip.vehicle_geo_infos set ";
        update += "next_stop_id=";
        update += "\'";
        update += QString::number(nextTaskPointID).toStdString();
        update += "\'";
        update += " where vehicle_id=";
        update += "\'";
        update += myRobot->carInfo.ID.toStdString();
        update += "\'";
        if( !mydb.updateData(update))
        {
            QMessageBox::information(NULL, "提示", "更新车辆下一个站点ＩＤ信息失败 !\n");
            return;
        }
        else
        {
            qDebug()<<"update  vehicle next_stop_id success";
            return;
        }
    }
}
void MainWindow::updateDB_vehiclePos()
{
    qDebug()<<QString::number(myRobot->lng_transformed,10,6);
    qDebug()<<QString::number(myRobot->lat_transformed,10,6);
    //update DB
    MyDB mydb;
    if( !mydb.initDB("localhost","root","vip","db_vip"))
    {
        QMessageBox::information(NULL, "提示", "数据库连接失败 !\n");
        return;
    }
    else
    {
        string update = "update db_vip.vehicle_geo_infos set ";
        update += "longitude=";
        update += "\'";
        update += (QString::number(myRobot->lng_transformed,10,6)).toStdString();
        update += "\'";
        update += "\,";
        update += " latitude=";
        update += "\'";
        update +=(QString::number(myRobot->lat_transformed,10,6)).toStdString();;
        update += "\'";
        update += "\,";
        update += " estimated_time=";
        update += "\'";
        update +=(QString::number(myRobot->carInfo.miles_left/2/60)).toStdString();;
        update += "\'";
        update += " where vehicle_id=";
        update += "\'";
        update += myRobot->carInfo.ID.toStdString();
        update += "\'";
        if( !mydb.updateData(update))
        {
            QMessageBox::information(NULL, "提示", "更新车辆位置 和估计时间 信息失败 !\n");
            return;
        }
        else
        {
            qDebug()<<"update  vehicle pos and estimated time success";
            return;
        }
    }
}
void MainWindow::updateDB_vehicleRoutePlanTable()
{
    taskSeq_plan = this->myRobot->taskSeq;
    taskSeq_planTime = this->myRobot->taskSeqPlanTime;

    //    //test
    //    taskSeq_plan.clear();
    //    taskSeq_planTime.clear();

    //insert to DB
    MyDB mydb;
    if( !mydb.initDB("localhost","root","vip","db_vip"))
    {
        QMessageBox::information(NULL, "提示", "数据库连接失败 !\n");
        return;
    }
    else
    {
        //clear DB db_vip.vehicle_routing_plan
        string clearTable = "delete from db_vip.vehicle_routing_plan";
        mydb.deleteData(clearTable);

        //insert task Seq
        int sum_minutes = 0;
        for(int i=0; i<taskSeq_planTime.size(); i++)
        {
            sum_minutes += taskSeq_planTime[i];
            QString planningTime = getPlanningTime(sum_minutes);
            //insert to table of order_retentions
            string insert = "insert into db_vip.vehicle_routing_plan(id,stop_id,stop_sequence_number,planning_time)  values";
            insert += "\(";
            insert += "\'";
            insert +=  myRobot->carInfo.ID.toStdString();
            insert += "\'";
            insert += "\,";
            insert += "\'";
            insert += '0' + taskSeq_plan[i];
            insert += "\'";
            insert += "\,";
            insert += "\'";
            insert += '0' + i + 1;
            insert += "\'";
            insert += "\,";
            insert += "\'";
            insert += planningTime.toStdString();
            insert += "\'";
            insert += "\)";
            qDebug()<<QString::fromStdString(insert);
            if( !mydb.insertData(insert))
            {
                QMessageBox::information(NULL, "提示", "数据库插入小车线路规划表失败 !\n");
                return;
            }
            else
            {
                qDebug()<<"insert VehicleRoutingPlan success";
            }
        }
    }
}
QString MainWindow::getPlanningTime(int minuteOffset)
{
    QString timeOffset = "2017-08-04 11:11:11";
    QDateTime time = QDateTime::currentDateTime();//获取系统现在的时间
    QString str = time.toString("yyyy-MM-dd hh:mm:ss"); //设置显示格式
    //

    return timeOffset;
}
void MainWindow::playAudio(QString audioID)
{
    QUrl audioSelect;
    int index = audioMap[audioID];
    switch (index) {
    case 0:
        audioSelect = QUrl::fromLocalFile("/home/zlp/qt_test/test1/audio/箱门已打开.mp3");
        break;
    case 1:
        audioSelect = QUrl::fromLocalFile("/home/zlp/qt_test/test1/audio/包裹是第一批次.mp3");
        break;
    case 2:
        audioSelect = QUrl::fromLocalFile("/home/zlp/qt_test/test1/audio/包裹是第二批次.mp3");
        break;
    case 3:
        audioSelect = QUrl::fromLocalFile("/home/zlp/qt_test/test1/audio/包裹是第三批次.mp3");
        break;
    case 4:
        audioSelect = QUrl::fromLocalFile("/home/zlp/qt_test/test1/audio/包裹是第四批次.mp3");
        break;
    case 5:
        audioSelect = QUrl::fromLocalFile("/home/zlp/qt_test/test1/audio/单号错误.mp3");
    case 6:
        audioSelect = QUrl::fromLocalFile("/home/zlp/qt_test/test1/audio/回收成功.mp3");
    default:
        audioSelect = QUrl::fromLocalFile("/home/zlp/qt_test/test1/audio/error.mp3");
    }

    audioPlayer->setMedia(audioSelect);
    audioPlayer->setVolume(100);
    audioPlayer->play();
}
void MainWindow::robot_getBoxState(BoxInfo boxInfo)
{
    //0：失败 1：成功 2：不是此消息
    if(boxInfo.boxIsOpen == 1)
    {
        qDebug()<<"boxIsOpen == true";
        playAudio("箱门已打开");
        //socket 通知物流部分
        string len = "0059";
        string type = "3001";
        string msg_send = generateMsgHead(len, type);
        msg_send.append("1");
        tcpIpSever_Logistic.sendMessage(msg_send);
        qDebug()<<"box open";
        qDebug()<<QString::fromStdString(msg_send);
    }
    else if(boxInfo.boxIsOpen == 0)
    {
        QMessageBox::information(NULL, "提示", "无人车体打开箱门失败 !\n");
    }
    if(boxInfo.boxIsClose == 1)
    {
        qDebug()<<"boxIsClose == true";
        //socket 通知物流部分
        slot_boxClose(boxInfo);
    }
    else if(boxInfo.boxIsClose == 0)
    {
        QMessageBox::information(NULL, "提示", "无人车体关闭箱门失败 !\n");
        slot_boxClose(boxInfo);
    }
}
//与物流之间socket通信
string MainWindow::generateMsgHead(string len, string type)
{
    QDateTime time = QDateTime::currentDateTime();//获取系统现在的时间
    string str_time = changeTimeFormat(time.toString("yyyy-MM-dd hh:mm:ss").toStdString()); //设置显示格式
    //msg head len = 58
    string msg;
    msg.append(len);//实际消息长度
    msg.append("0000");//保留字段
    msg.append(str_time); //当前时间
    msg.append("0001"); //平台标识
    msg.append("000000");//流水号
    msg.append(type); //消息类别
    msg.append(str_time);//本消息产生时间
    msg.append("0001");//本消息来源平台标识
    msg.append("0002");//本消息目标平台标识

    return msg;
}
//向物流部分发送统计报表的查询条件
void MainWindow::sendSocketToLogistic(QString condition)
{
    qDebug("send to statictical table");
    int bodg_size = condition.size();
    int msg_size = bodg_size + 58;
    string len = QString::number(msg_size).toStdString();
    if(len.size() == 2)
    {
        len.insert(0,"00");
    }
    if(len.size() == 3)
    {
        len.insert(0,"0");
    }
    //qDebug()<<QString::fromStdString(len);
    string type = "B001";
    string msg_send = generateMsgHead(len , type);
    msg_send.append(condition.toStdString());
    tcpIpSever_Logistic.sendMessage(msg_send);
}
void MainWindow::slot_acceptMsgFromLogistic()
{
    qDebug("slot_acceptMsgFromLogistic()");
    std::string msg;
    msg = tcpIpSever_Logistic.readMessageFromTcpClient();
    //qDebug()<<QString::fromStdString(msg);
    //解析接收数据
    string msgType;
    if(msg.size()>36)
        msgType = msg.substr(32,4);
    else
    {
        msgType = "0000";
        QMessageBox::information(NULL, "提示", "接收指令信息格式不正确 !\n");
    }
    //qDebug()<<QString::fromStdString(msgType);
    //执行排班算法指令响应
    if(string(msgType) == "1002")
    {
        qDebug()<<"执行排班算法指令响应";
        if(string(msg.substr(msg.size()-4,4)) == "0000")
        {
            getParcelInfoAfterSchedule();
        }
        else
            QMessageBox::information(NULL, "提示", "排班失败 !\n");
    }
    //开门指令响应,和接收处理
    if(string(msgType) == "2001" )
    {
        string len = "0062";
        string type = "2002";
        string msg_send = generateMsgHead(len , type);

        msg_send.append("0000");
        tcpIpSever_Logistic.sendMessage(msg_send);

        //接收处理 send socket to vehicle
        qDebug()<<"开门指令";
        qDebug()<<QString::fromStdString(msg);
        if(msg.size()>59)
        {
            string boxIDInfo = msg.substr(59);

            qDebug()<<QString::fromStdString(boxIDInfo);
            boxIndex.clear();
            QString boxIDSeg = QString::fromStdString(boxIDInfo);
            QStringList boxIdList;
            boxIdList =  boxIDSeg.split(',');
            for(int i=0;i<boxIdList.size();i++)
            {
                QString boxID = boxIdList[i];
                qDebug()<<boxID;
                int boxTmp = getBoxIndexAccordingToBoxID(boxID);
                if(boxTmp != 999)
                    boxIndex.push_back(boxTmp);
            }

            if(boxIndex.size() != 0)
                boxInfoWidget_openBox(boxIndex);
            else
                QMessageBox::information(NULL, "提示", "没有得到要开门箱子号 !\n");
        }
        else
        {
           qDebug()<<"开门指令格式不对";
        }
//        sleep(2000);
//        //模拟从车体接收到箱门信息 打开成功
//        string len_ = "0059";
//        string type_ = "3001";
//        string msg_send_ = generateMsgHead(len_ , type_);
//        msg_send_.append("1");
//        tcpIpSever_Logistic.sendMessage(msg_send_);
//        qDebug()<<"box info";
//        qDebug()<<QString::fromStdString(msg_send_);

//        //   //模拟从车体接收到箱门信息 关闭成功
//        sleep(2000);
//        slot_boxClose();
    }
    //开关门信息响应
    if(string(msgType) == "3002" )
    {
        qDebug()<<"开关门信息响应";
    }
    //车辆出发信息响应  和接收处理
    if(string(msgType) == "4001" )
    {
        //response
        string len = "0062";
        string type = "4002";
        string msg_send = generateMsgHead(len , type);

        msg_send.append("0000");
        tcpIpSever_Logistic.sendMessage(msg_send);

        startDeliveryWidegt_startTaskPlan();
        sleep(3000);
        on_button_vehicleStart_clicked();
        sleep(1000);
        on_button_monitorStart_clicked();
    }
    //下站10分钟到达信息响应
    if(string(msgType) == "5002" )
    {
        qDebug()<<"下站10分钟到达信息响应";
    }
    //小车离开站点 响应  和接收处理
    if(string(msgType) == "6001" )
    {
        //response
        string len = "0062";
        string type = "6002";
        string msg_send = generateMsgHead(len , type);

        msg_send.append("0000");
        tcpIpSever_Logistic.sendMessage(msg_send);
        //process
        qDebug()<<"小车离开站点信息发送";
        Json::Value root;
        Json::FastWriter fast;
        root["Name"]=("device_control");
        root["Cmd"]=("leave");
        std::string str=fast.write(root) ;
        this->myRobot->tcpIpSever.sendMessage(str);

        //teleoperationWidget_OperationExchange();

        isArriveTaskPoint = false;
    }
    //消息更新信息 响应  和接收处理
    if(string(msgType) == "7001" )
    {
        //response
        string len = "0062";
        string type = "7002";
        string msg_send = generateMsgHead(len , type);

        msg_send.append("0000");
        tcpIpSever_Logistic.sendMessage(msg_send);
        //process
        qDebug()<<"消息更新信息发送";
    }
    //心跳包发送 响应  和接收处理
    if(string(msgType) == "8001" )
    {
        //response
        string len = "0062";
        string type = "8002";
        string msg_send = generateMsgHead(len , type);

        msg_send.append("0000");
        tcpIpSever_Logistic.sendMessage(msg_send);
        //process
        qDebug()<<"心跳包发送信息发送";
    }
    //拒收申请指令 响应  和接收处理
    if(string(msgType) == "9001" )
    {
        //response
        string len = "0062";
        string type = "9002";
        string msg_send = generateMsgHead(len , type);

        msg_send.append("0000");
        tcpIpSever_Logistic.sendMessage(msg_send);
        //process 品骏订单号
        qDebug()<<"拒收申请指令信息发送";
        qDebug()<<QString::fromStdString(msg);
        if(msg.size()>59)
        {
            string parcelID_pj = msg.substr(59);
            //test
            //parcelID_pj = "o00001";
            qDebug()<<QString::fromStdString(parcelID_pj);
            rejectionCheckWidget.getParcelID_vpFromLogistics(QString::fromStdString(parcelID_pj));
            if(rejectionCheckWidget.getAllRejectionParcelInfoFromDB())
            {
                rejectionCheckWidget.show();
                rejectionCheckWidget.updateTableWidget();
            }
            else
            {
                qDebug()<<"没有查询到该拒收包裹的信息";
            }
        }
        else
        {
            qDebug()<<"拒收指令格式不对";
        }
    }
    if(string(msgType) == "9004" )
    {
        qDebug()<<"同意/不同意拒收指令响应";
    }
    if(string(msgType) == "A002" )
    {
        qDebug()<<"到达站点指令响应";
    }
    if(string(msgType) == "B002" )
    {
        qDebug()<<"执行导出结果指令响应";
    }
    if(string(msgType) == "C002" )
    {
        qDebug()<<"回到配送站响应";
    }
    if(string(msgType) == "D002" )
    {
        qDebug()<<"改为滞留响应";
    }
}

void MainWindow::rejectionWidget_boxIDCluster(std::vector<QString> boxIDCluster)
{
    //发送socket给车体部分，告诉车体打开箱门，把拒收的货物放进去
    boxIndex.clear();
    for(int i=0; i<boxIDCluster.size();i++)
    {
        //QString boxIDSeg = "A1,A2";
        QString boxIDSeg = boxIDCluster[i];
        QStringList boxIdList;
        boxIdList =  boxIDSeg.split(',');
        for(int i=0;i<boxIdList.size();i++)
        {
            QString boxID = boxIdList[i];
            qDebug()<<boxID;
            int boxTmp = getBoxIndexAccordingToBoxID(boxID);
            if(boxTmp != 999)
                boxIndex.push_back(boxTmp);
        }
    }

    if(boxIndex.size() != 0)
        boxInfoWidget_openBox(boxIndex);
    else
        QMessageBox::information(NULL, "提示", "没有得到要开门箱子号 !\n");
}
// TBD
int MainWindow::getBoxIndexAccordingToBoxID(QString boxID)
{
    if(boxID == "A1")
        return 1;
    if(boxID == "A2")
        return 2;
    if(boxID == "A3")
        return 3;
    if(boxID == "A4")
        return 4;
    if(boxID == "A5")
        return 5;
    if(boxID == "A6")
        return 6;
    if(boxID == "A7")
        return 7;
    if(boxID == "A8")
        return 8;
    if(boxID == "B1")
        return 9;
    if(boxID == "B2")
        return 10;
    if(boxID == "B3")
        return 11;
    if(boxID == "B4")
        return 12;
    if(boxID == "B5")
        return 13;
    if(boxID == "B6")
        return 14;
    if(boxID == "B7")
        return 15;
    if(boxID == "B8")
        return 16;
    if(boxID == "C1")
        return 17;
    if(boxID == "C2")
        return 18;
    if(boxID == "C3")
        return 19;
    if(boxID == "C4")
        return 20;
    else
        return 999;
}
void MainWindow::rejectionWidget_agree(QString str)
{
    //发送socket给物流部分，告诉同意拒收"1",不同意“0”
    string len = "0059";
    string type = "9003";
    string msg_send = generateMsgHead(len , type);

    msg_send.append(str.toStdString());
    tcpIpSever_Logistic.sendMessage(msg_send);
    qDebug()<<"agree rejection socket send";
    qDebug()<<QString::fromStdString(msg_send);
}
void MainWindow::rejectionWidget_disagree(QString str)
{
    string len = "0059";
    string type = "9003";
    string msg_send = generateMsgHead(len , type);

    msg_send.append(str.toStdString());
    tcpIpSever_Logistic.sendMessage(msg_send);
    qDebug()<<"disagree rejection socket send";
    qDebug()<<QString::fromStdString(msg_send);
}
void MainWindow::parcelInfoWidget_changeDetention(QString parcelID_pj)
{
    string len = "0090";
    string type = "D001";
    string msg_send = generateMsgHead(len , type);

    msg_send.append(parcelID_pj.toStdString());
    tcpIpSever_Logistic.sendMessage(msg_send);
    qDebug()<<"detention socket send";
    qDebug()<<QString::fromStdString(msg_send);
}
void MainWindow::parcelInfoWidget_changeMan(QString parcelID_pj)
{
    string len = "0090";
    string type = "E001";
    string msg_send = generateMsgHead(len , type);

    msg_send.append(parcelID_pj.toStdString());
    tcpIpSever_Logistic.sendMessage(msg_send);
    qDebug()<<"man socket send";
    qDebug()<<QString::fromStdString(msg_send);
}

void MainWindow::slot_arriveTaskPointAfterTenMinutes()
{
    //车辆下站10分钟到达指令
    string len = "0062";
    string type = "5001";
    string msg_send = generateMsgHead(len , type);

    QString posID = ui->lineEdit->text();
    if(posID.size() !=0)
    {
        if(posID.size() == 1)
        {
            msg_send.append("000");
            msg_send.append(posID.toStdString());
        }
        if(posID.size() == 2)
        {
            msg_send.append("00");
            msg_send.append(posID.toStdString());
        }
    }
    else
    {
        int ID = this->myRobot->taskInfo.taskPoint;
        QString  taskPoint_str = QString::number(ID);
        if(taskPoint_str.size() == 1)
        {
            msg_send.append("000");
            msg_send.append(taskPoint_str.toStdString());
        }
        if(taskPoint_str.size() == 2)
        {
            msg_send.append("00");
            msg_send.append(taskPoint_str.toStdString());
        }
    }
    tcpIpSever_Logistic.sendMessage(msg_send);
    qDebug()<<"车辆下站10分钟到达指令 send";
    qDebug()<<QString::fromStdString(msg_send);
}
void MainWindow::slot_leaveTaskPointt_getTaskPointID(int taskPointID)
{
    qDebug()<<"slot_leaveTaskPointt_getTaskPointID with arg";
    nextTaskPoint = taskPointID;
    updateDB_vehicleGeoInfo_nextStopID(nextTaskPoint);
    if(nextTaskPoint != 0)
    {
        currentTaskPointParcelNum = std::count(taskClu_withRepeat.begin(),taskClu_withRepeat.end(),nextTaskPoint);
        currentTaskPointParcelStatus = "在途";
    }
    else
    {
        currentTaskPointParcelNum = 0;
        currentTaskPointParcelStatus = "null";
    }
}
//just for test
void MainWindow::slot_leaveTaskPointt_getTaskPointID()
{
    qDebug()<<"slot_leaveTaskPointt_getTaskPointID no arg";
    QString posID = ui->lineEdit->text();
    if(posID.size() != 0)
    {
        nextTaskPoint = posID.toInt();
        updateDB_vehicleGeoInfo_nextStopID(nextTaskPoint);
    }
}

void MainWindow::slot_arriveTaskPoint_getTaskPointID(int taskPointID)
{
    //更新数据库 db_vip.vehicle_geo_infos
    currentTaskPoint = taskPointID;
    updateDB_vehicleGeoInfo_currentStopID(currentTaskPoint);
    //
    int ID = taskPointID;

    if(ID != 0)
    {
        currentTaskPointParcelStatus = "到达";
        //到达站点指令
        string len = "0062";
        string type = "A001";
        string msg_send = generateMsgHead(len , type);

        QString  taskPoint_str = QString::number(ID);
        if(taskPoint_str.size() == 1)
        {
            msg_send.append("000");
            msg_send.append(taskPoint_str.toStdString());
        }
        if(taskPoint_str.size() == 2)
        {
            msg_send.append("00");
            msg_send.append(taskPoint_str.toStdString());
        }
        tcpIpSever_Logistic.sendMessage(msg_send);
        qDebug()<<"到达站点指令 send";
        qDebug()<<QString::fromStdString(msg_send);
    }
    else
    {
        currentTaskPointParcelStatus = "null";
        slot_returnStation();
    }
}
void MainWindow::slot_arriveTaskPoint()
{   
    //到达站点指令
    string len = "0062";
    string type = "A001";
    string msg_send = generateMsgHead(len , type);


    QString posID = ui->lineEdit->text();
    if(posID.size() == 1)
    {
        msg_send.append("000");
        msg_send.append(posID.toStdString());
    }
    if(posID.size() == 2)
    {
        msg_send.append("00");
        msg_send.append(posID.toStdString());
    }

    //更新数据库 db_vip.vehicle_geo_infos
    currentTaskPoint = posID.toInt();
    updateDB_vehicleGeoInfo_currentStopID(currentTaskPoint);


    tcpIpSever_Logistic.sendMessage(msg_send);
    qDebug()<<"到达站点指令 send";
    qDebug()<<QString::fromStdString(msg_send);
}
void MainWindow::slot_returnStation()
{
    //.回到配送站指令
    string len = "0059";
    string type = "C001";
    string msg_send = generateMsgHead(len , type);

    msg_send.append("1");
    tcpIpSever_Logistic.sendMessage(msg_send);
    qDebug()<<"回到配送站指令 send";
    qDebug()<<QString::fromStdString(msg_send);
}
void MainWindow::slot_boxClose(BoxInfo boxInfo)
{

    //get box ID
    vector<int> tmp = boxInfo.boxState;
    string boxIDSeq;
    for(int i=0;i<tmp.size();i++)
    {
        //1 not open
        if(tmp[i]==1)
        {
            boxIDSeq.append(boxIDMap[i+1].toStdString());
            if(i != tmp.size()-1)
                boxIDSeq.append(",");
        }
    }
    //箱子 关闭
    string len;
    int len_num = 59+boxIDSeq.size();
    if(len_num>99)
    {
        len = "0";
        len.append(QString::number(len_num).toStdString());
    }
    else
    {
        len = "00";
        len.append(QString::number(len_num).toStdString());
    }
    string type = "3001";
    string msg_send = generateMsgHead(len , type);

    msg_send.append("0");
    msg_send.append(boxIDSeq);
    tcpIpSever_Logistic.sendMessage(msg_send);
    qDebug()<<QString::fromStdString(boxIDSeq);
    qDebug()<<"箱子关闭 send";
    qDebug()<<QString::fromStdString(msg_send);
}

//test
void MainWindow::on_pushButton_5_clicked()
{
    //process
//    qDebug()<<"小车离开站点信息发送";
//    Json::Value root;
//    Json::FastWriter fast;
//    root["Name"]=("device_control");
//    root["Cmd"]=("leave");
//    std::string str=fast.write(root) ;
//    this->myRobot->tcpIpSever.sendMessage(str);
   // 箱子 open
//    string len = "0059";
//    string type = "3001";
//    string msg_send = generateMsgHead(len , type);

//    msg_send.append("1");
//    tcpIpSever_Logistic.sendMessage(msg_send);
//    qDebug()<<"箱子open send";
    //    qDebug()<<QString::fromStdString(msg_send);


    string boxIDInfo = "B1,B2";

    qDebug()<<QString::fromStdString(boxIDInfo);
    boxIndex.clear();
    QString boxIDSeg = QString::fromStdString(boxIDInfo);
    QStringList boxIdList;
    boxIdList =  boxIDSeg.split(',');
    for(int i=0;i<boxIdList.size();i++)
    {
        QString boxID = boxIdList[i];
        qDebug()<<boxID;
        int boxTmp = getBoxIndexAccordingToBoxID(boxID);
        if(boxTmp != 999)
            boxIndex.push_back(boxTmp);
    }

    if(boxIndex.size() != 0)
        boxInfoWidget_openBox(boxIndex);
    else
        QMessageBox::information(NULL, "提示", "没有得到要开门箱子号 !\n");

}
