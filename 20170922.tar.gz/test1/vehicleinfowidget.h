#ifndef VEHICLEINFOWIDGET_H
#define VEHICLEINFOWIDGET_H

#include <QWidget>

namespace Ui {
class VehicleInfoWidget;
}

class VehicleInfoWidget : public QWidget
{
    Q_OBJECT

public:
    explicit VehicleInfoWidget(QWidget *parent = 0);
    ~VehicleInfoWidget();
    void setVehicleInfo(QString);
    QString VehicleInfo;
private:
    void initUi();//初始化界面参数
    void initConnect();//初始化信号和槽连接
private slots:
    void vehicleSelectCombox_clicked(const QString &);
private:
    Ui::VehicleInfoWidget *ui;
};

#endif // VEHICLEINFOWIDGET_H
