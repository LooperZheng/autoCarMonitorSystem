﻿#include <iostream>
#include <stdio.h>
#include "sever_car.h"
#include <string>
#include "io.h"
#include <json/json.h>
#include <json/value.h>
#include <json/writer.h>

SeverCar::SeverCar(QObject *parent):
    QObject(parent)
{

}

SeverCar::~SeverCar()
{

}

void SeverCar::tcpSeverInit(int p)
{
    qDebug("start tcp server ini car");
    tcpSever = new QTcpServer(this);
    tcpClient = new QTcpSocket(this);
    hostIP = getHostIP();
    port = p;
    if(hostIP == 0)
    {
        qDebug("get hostIP fail");
    }
    else
        qDebug()<<hostIP;
    //newConnection()用于当有客户端访问时发出信号，acceptConnection()信号处理函数
    tcpSever->setMaxPendingConnections(1);
    connect(tcpSever, SIGNAL(newConnection()),this, SLOT(acceptConnection()));
}
void SeverCar::tcpSeverReset(int p)
{
    qDebug("start tcp server reset car");
    tcpSever->close();
    tcpClient->abort();
    port = p;

    if(!tcpSever->listen(QHostAddress::Any, port))
    {
        qDebug()<<tcpSever->errorString();
        tcpSever->close();
        return;
    }
    qDebug("start listening reset car ");
}
void SeverCar::tcpListening()
{
    if(!tcpSever->listen(QHostAddress::Any, port))
    {
        qDebug()<<tcpSever->errorString();
        tcpSever->close();
        return;
    }
    qDebug("start listening car");
}

void SeverCar::displayError(QAbstractSocket::SocketError)
{
    qDebug()<<tcpClient->errorString();
    tcpClient->close();
    qDebug("Status: connect error! open client and retry car");
}
void SeverCar::acceptConnection()
{
    qDebug("acceptConnection car");
    //当有客户来访时将tcpSocket接受tcpServer建立的socket
    if( !tcpClient->isOpen())
    {
         qDebug("new acceptConnection car");
        tcpClient = tcpSever->nextPendingConnection();
        qDebug()<<tcpClient->peerAddress().toString();
        //????
        //tcpSever->close();
        //端口数据接收成功时，就会发送readyRead()信号
        connect(tcpClient, SIGNAL(readyRead()), this , SLOT(acceptMsgFromClient()));
        // 当有数据发送成功时，就会发送bytesWritten()信号
        //connect(tcpClient, SIGNAL(bytesWritten(qint64)), this, SLOT(updateClientProgress(qint64)));
        // 绑定错误处理
        connect(tcpClient, SIGNAL(error(QAbstractSocket::SocketError)), this, SLOT(displayError(QAbstractSocket::SocketError)));
        emit signal_startTime();
    }
}

void SeverCar::acceptMsgFromClient()
{
    emit signal_acceptMsgFromClient();
    //qDebug("emit signal_acceptMsgFromClient();");
}
std::string SeverCar::readMessageFromTcpClient()
{
    qDebug("readMessageFromTcpClient car");
    QByteArray qba = tcpClient->readAll();
    QString data = qba.data();
    std::string data_str = data.toStdString();
    qDebug()<<data;
    return data_str;
}
void SeverCar::sendMessage(const std::string str_msg)
{
    qDebug("tcpsever sendMessage car");
    tcpClient->write(str_msg.c_str(),strlen(str_msg.c_str()));
}
QString SeverCar::getHostIP()
{
    QList<QHostAddress> list = QNetworkInterface::allAddresses();
    foreach (QHostAddress address, list)
    {
        //我们使用IPv4地址
       if (address.protocol() == QAbstractSocket::IPv4Protocol)
            return address.toString();
    }
    return 0;
}
