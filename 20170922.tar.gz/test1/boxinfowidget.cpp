#include "boxinfowidget.h"
#include "ui_boxinfowidget.h"
#include <QGridLayout>
#include <QButtonGroup>
#include <QRadioButton>
#include <QDebug>
#include <QString>
#include <QDesktopWidget>
#include <QPainter>
#include <QDesktopWidget>
#include <QMessageBox>
#include "mydb.h"
#include <set>
BoxInfoWidget::BoxInfoWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::BoxInfoWidget)
{
    ui->setupUi(this);
    initUi();//初始化界面参数
    initConnect();//初始化信号和槽连接
}

BoxInfoWidget::~BoxInfoWidget()
{
    delete ui;
}
void BoxInfoWidget::initUi()
{
    // 固定窗口的大小
    this->setFixedSize(this->width(), this->height());

    this->setWindowTitle("货柜信息界面");
    ui->textBrowser->setTextColor(QColor(0,0,0));
    //设置弹出窗口的位置（在屏幕中央）
    QDesktopWidget *deskdop=QApplication::desktop();
    this->move((deskdop->width()-this->width())/2,      (deskdop->height()-this->height())/2);

    ui->pushButton_openBox->setDisabled(true);
    //设置分割线的颜色和每个RadioButton的聚焦点，每个RadioButton的样式在界面设计器中的样式表中设计
    ui->radioButton_1->setFocusPolicy(Qt::NoFocus);
    ui->radioButton_2->setFocusPolicy(Qt::NoFocus);
    ui->radioButton_3->setFocusPolicy(Qt::NoFocus);
    ui->radioButton_4->setFocusPolicy(Qt::NoFocus);
    ui->radioButton_5->setFocusPolicy(Qt::NoFocus);
    ui->radioButton_6->setFocusPolicy(Qt::NoFocus);
    ui->radioButton_7->setFocusPolicy(Qt::NoFocus);
    ui->radioButton_8->setFocusPolicy(Qt::NoFocus);
    ui->radioButton_9->setFocusPolicy(Qt::NoFocus);
    ui->radioButton_10->setFocusPolicy(Qt::NoFocus);
    ui->radioButton_11->setFocusPolicy(Qt::NoFocus);
    ui->radioButton_12->setFocusPolicy(Qt::NoFocus);
    ui->radioButton_13->setFocusPolicy(Qt::NoFocus);
    ui->radioButton_14->setFocusPolicy(Qt::NoFocus);
    ui->radioButton_15->setFocusPolicy(Qt::NoFocus);
    ui->radioButton_16->setFocusPolicy(Qt::NoFocus);
    ui->radioButton_17->setFocusPolicy(Qt::NoFocus);
    ui->radioButton_18->setFocusPolicy(Qt::NoFocus);
    ui->radioButton_19->setFocusPolicy(Qt::NoFocus);
    ui->radioButton_20->setFocusPolicy(Qt::NoFocus);

    m_pButtonGroup = new QButtonGroup(this);
    m_pButtonGroup->addButton(ui->radioButton_1);
    m_pButtonGroup->addButton(ui->radioButton_2);
    m_pButtonGroup->addButton(ui->radioButton_3);
    m_pButtonGroup->addButton(ui->radioButton_4);
    m_pButtonGroup->addButton(ui->radioButton_5);
    m_pButtonGroup->addButton(ui->radioButton_6);
    m_pButtonGroup->addButton(ui->radioButton_7);
    m_pButtonGroup->addButton(ui->radioButton_8);
    m_pButtonGroup->addButton(ui->radioButton_9);
    m_pButtonGroup->addButton(ui->radioButton_10);
    m_pButtonGroup->addButton(ui->radioButton_11);
    m_pButtonGroup->addButton(ui->radioButton_12);
    m_pButtonGroup->addButton(ui->radioButton_13);
    m_pButtonGroup->addButton(ui->radioButton_14);
    m_pButtonGroup->addButton(ui->radioButton_15);
    m_pButtonGroup->addButton(ui->radioButton_16);
    m_pButtonGroup->addButton(ui->radioButton_17);
    m_pButtonGroup->addButton(ui->radioButton_18);
    m_pButtonGroup->addButton(ui->radioButton_19);
    m_pButtonGroup->addButton(ui->radioButton_20);

    boxID2NumMap.insert(std::pair<QString,int>("A1",15));
    boxID2NumMap.insert(std::pair<QString,int>("A2",14));
    boxID2NumMap.insert(std::pair<QString,int>("A3",19));
    boxID2NumMap.insert(std::pair<QString,int>("A4",18));
    boxID2NumMap.insert(std::pair<QString,int>("A5",13));
    boxID2NumMap.insert(std::pair<QString,int>("A6",12));
    boxID2NumMap.insert(std::pair<QString,int>("A7",17));
    boxID2NumMap.insert(std::pair<QString,int>("A8",16));
    boxID2NumMap.insert(std::pair<QString,int>("B1",7));
    boxID2NumMap.insert(std::pair<QString,int>("B2",6));
    boxID2NumMap.insert(std::pair<QString,int>("B3",3));
    boxID2NumMap.insert(std::pair<QString,int>("B4",2));
    boxID2NumMap.insert(std::pair<QString,int>("B5",5));
    boxID2NumMap.insert(std::pair<QString,int>("B6",4));
    boxID2NumMap.insert(std::pair<QString,int>("B7",1));
    boxID2NumMap.insert(std::pair<QString,int>("B8",0));
    boxID2NumMap.insert(std::pair<QString,int>("C1",10));
    boxID2NumMap.insert(std::pair<QString,int>("C2",8));
    boxID2NumMap.insert(std::pair<QString,int>("C3",11));
    boxID2NumMap.insert(std::pair<QString,int>("C4",9));
}

void BoxInfoWidget::initConnect()
{
    connect(m_pButtonGroup, SIGNAL(buttonClicked(QAbstractButton*)), this, SLOT(boxButtonGroup_clicked(QAbstractButton*)));

}
void BoxInfoWidget::boxButtonGroup_clicked(QAbstractButton *button)
{
    // 当前点击的按钮
    boxNum = button->text();
    if(std::find(boxIDCluAvailable.begin(),boxIDCluAvailable.end(),boxNum) != boxIDCluAvailable.end())
    {
        ui->pushButton_openBox->setDisabled(false);
        QString parcelID_pj;
        QString receiver_name;
        QString receiver_mobile;
        QString receiver_address;
        QString stop;
        QString status;

        QString parcelID = boxID2parcelIDMap[boxNum];
        QString boxIDSeg =  parcelID2boxIDMap[parcelID];
        QStringList boxIdList;
        boxIdList =  boxIDSeg.split(',');
        //query from DB
        MyDB mydb;
        if( !mydb.initDB("localhost","root","vip","db_vip"))
        {
            QMessageBox::information(NULL, "提示", "数据库连接失败 !\n");
            return;
        }
        else
        {
            //query table of transport_sn_scheduling_plan
            string query = "select pj_order_sn,receiver_name,receiver_mobile,receiver_address,stop,status from db_vip.transport_sns where transport_sn=";
            query += "\'";
            query += parcelID.toStdString();
            query += "\'";
            vector<vector<string> > result_transport_sn;
            if( !mydb.exeSQL(query, result_transport_sn))
            {
                QMessageBox::information(NULL, "提示", "查询数据失败 !\n");
                return;
            }
            else
            {
                if(result_transport_sn[0].size() == 0)
                {
                    parcelID_pj = "null";
                    receiver_name = "null";
                    receiver_mobile = "null";
                    receiver_address = "null";
                    stop = "null";
                    status = "null";
                }
                else
                {
                    parcelID_pj = QString::fromStdString(result_transport_sn[0][0]);
                    receiver_name = QString::fromStdString(result_transport_sn[1][0]);
                    receiver_mobile = QString::fromStdString(result_transport_sn[2][0]);
                    receiver_address = QString::fromStdString(result_transport_sn[3][0]);
                    stop = QString::fromStdString(result_transport_sn[4][0]);
                    status = QString::fromStdString(result_transport_sn[5][0]);
                }
            }
        }

        QString boxInfo = QString("货柜编号：%1").arg(button->text());
        boxInfo.append("\n");
        boxInfo.append("组合货柜 : ");
        if(boxIdList.size() == 1)
            boxInfo.append("否");
        else
            boxInfo.append(boxIDSeg);
        boxInfo.append("\n");
        boxInfo.append("包裹单号 : ");
        boxInfo.append(parcelID);
        boxInfo.append("\n");
        boxInfo.append("品骏单号 : ");
        boxInfo.append(parcelID_pj);
        boxInfo.append("\n");
        boxInfo.append("包裹状态 : ");
        boxInfo.append(status);
        boxInfo.append("\n");
        boxInfo.append("联系人 : ");
        boxInfo.append(receiver_name);
        boxInfo.append("\n");
        boxInfo.append("联系方式 : ");
        boxInfo.append(receiver_mobile);
        boxInfo.append("\n");
        boxInfo.append("收货地址 : ");
        boxInfo.append(receiver_address);
        boxInfo.append("\n");
        boxInfo.append("停靠站点 : ");
        boxInfo.append(stop);
        ui->textBrowser->setText(boxInfo);

        //get boxIndex
        boxIndex.clear();
        for(int j=0;j<boxIdList.size();j++)
        {
            int tmp = getBoxIndexAccordingToBoxID(boxIdList[j]);
            boxIndex.push_back(tmp);
        }
    }
    else
    {
        ui->pushButton_openBox->setDisabled(true);
        QString boxInfo = QString("货柜编号：%1").arg(button->text());
        boxInfo.append("\n");
        boxInfo.append("此货柜没有装载包裹!");
        ui->textBrowser->setText(boxInfo);
    }

}
// TBD
int BoxInfoWidget::getBoxIndexAccordingToBoxID(QString boxID)
{
    if(boxID == "A1")
        return 1;
    if(boxID == "A2")
        return 2;
    if(boxID == "A3")
        return 3;
    if(boxID == "A4")
        return 4;
    if(boxID == "A5")
        return 5;
    if(boxID == "A6")
        return 6;
    if(boxID == "A7")
        return 7;
    if(boxID == "A8")
        return 8;
    if(boxID == "B1")
        return 9;
    if(boxID == "B2")
        return 10;
    if(boxID == "B3")
        return 11;
    if(boxID == "B4")
        return 12;
    if(boxID == "B5")
        return 13;
    if(boxID == "B6")
        return 14;
    if(boxID == "B7")
        return 15;
    if(boxID == "B8")
        return 16;
    if(boxID == "C1")
        return 17;
    if(boxID == "C2")
        return 18;
    if(boxID == "C3")
        return 19;
    if(boxID == "C4")
        return 20;
    else
        return 999;
}
void BoxInfoWidget::setCombineBoxIndex()
{

}
void BoxInfoWidget::on_pushButton_openBox_clicked()
{
    emit signal_openBox(boxIndex);
}
void BoxInfoWidget::getParcelIDCluAfterTaskPlan(std::vector<QString> tmp)
{
    parcelIDClu = tmp;
}
void BoxInfoWidget::updateBox()
{
    rec_2v_index.clear();
    rec_2h_index.clear();
    rec_4_index.clear();
    for(int i=0;i<20;i++)
        boxIndexCluster[i].clear();

    //query table of transport_sn_box_assignment
    MyDB mydb;
    if( !mydb.initDB("localhost","root","vip","db_vip"))
    {
        QMessageBox::information(NULL, "提示", "数据库连接失败 !\n");
        return;
    }
    else
    {
        int index = 0;
        parcelID2boxIDMap.clear();
        boxID2parcelIDMap.clear();
        boxIDCluAvailable.clear();
        for(int i=0;i<parcelIDClu.size();i++)
        {
            string query_box =  "select box_id from db_vip.transport_sn_box_assignment where transport_sn=";
            query_box += "\'";
            query_box += parcelIDClu[i].toStdString();
            query_box += "\'";
            vector<vector<string> > result_box;
            if( !mydb.exeSQL(query_box, result_box))
            {
                QMessageBox::information(NULL, "提示", "查询数据失败 !\n");
                return;
            }
            else
            {
                qDebug()<<"query transport_sn_box_assignment ";
                if(result_box[0].size()!=0)
                {
                    QString  boxIDSeg = QString::fromStdString(result_box[0][0]);
                    parcelID2boxIDMap.insert(std::pair<QString,QString>(parcelIDClu[i], boxIDSeg));
                    QStringList boxIdList;
                    boxIdList =  boxIDSeg.split(',');
                    if(boxIdList.size()>1)
                    {
                        std::set<int> tmp;
                        for(int j=0;j<boxIdList.size();j++)
                        {
                            tmp.insert(boxID2NumMap[boxIdList[j]]);
                            boxID2parcelIDMap.insert(std::pair<QString,QString>(boxIdList[j],parcelIDClu[i]));
                            boxIDCluAvailable.push_back(boxIdList[j]);
                        }
                        for(std::set<int>::iterator it=tmp.begin(); it != tmp.end(); it++)
                        {
                            boxIndexCluster[index].push_back(*it);
                        }
                        index ++;
                    }
                    else
                    {
                        boxID2parcelIDMap.insert(std::pair<QString,QString>(boxIDSeg,parcelIDClu[i]));
                        boxIDCluAvailable.push_back(boxIDSeg);
                    }
                }
            }
        }
    }
    //test for get boxIndexCluster
//        boxIndexCluster[0].push_back(0);
//        boxIndexCluster[0].push_back(4);
    //    boxIndexCluster[1].push_back(1);
    //    boxIndexCluster[1].push_back(5);
    //    boxIndexCluster[2].push_back(2);
    //    boxIndexCluster[2].push_back(6);
    //    boxIndexCluster[3].push_back(3);
    //    boxIndexCluster[3].push_back(7);
    //    boxIndexCluster[4].push_back(8);
    //    boxIndexCluster[4].push_back(10);
    //    boxIndexCluster[5].push_back(9);
    //    boxIndexCluster[5].push_back(11);
    //    boxIndexCluster[6].push_back(12);
    //    boxIndexCluster[6].push_back(16);
    //    boxIndexCluster[7].push_back(13);
    //    boxIndexCluster[7].push_back(17);
    //    boxIndexCluster[8].push_back(14);
    //    boxIndexCluster[8].push_back(18);
    //    boxIndexCluster[9].push_back(15);
    //    boxIndexCluster[9].push_back(19);

    //    boxIndexCluster[0].push_back(0);
    //    boxIndexCluster[0].push_back(1);
    //    boxIndexCluster[1].push_back(4);
    //    boxIndexCluster[1].push_back(5);
    //    boxIndexCluster[2].push_back(2);
    //    boxIndexCluster[2].push_back(3);
    //    boxIndexCluster[3].push_back(6);
    //    boxIndexCluster[3].push_back(7);
    //    boxIndexCluster[4].push_back(8);
    //    boxIndexCluster[4].push_back(9);
    //    boxIndexCluster[5].push_back(10);
    //    boxIndexCluster[5].push_back(11);
    //    boxIndexCluster[6].push_back(12);
    //    boxIndexCluster[6].push_back(13);
    //    boxIndexCluster[7].push_back(16);
    //    boxIndexCluster[7].push_back(17);
    //    boxIndexCluster[8].push_back(14);
    //    boxIndexCluster[8].push_back(15);
    //    boxIndexCluster[9].push_back(18);
    //    boxIndexCluster[9].push_back(19);

//    boxIndexCluster[0].push_back(0);
//    boxIndexCluster[0].push_back(1);
//    boxIndexCluster[0].push_back(4);
//    boxIndexCluster[0].push_back(5);

//    boxIndexCluster[1].push_back(2);
//    boxIndexCluster[1].push_back(3);
//    boxIndexCluster[1].push_back(6);
//    boxIndexCluster[1].push_back(7);

    //    boxIndexCluster[4].push_back(8);
    //    boxIndexCluster[4].push_back(9);
    //    boxIndexCluster[4].push_back(10);
    //    boxIndexCluster[4].push_back(11);


    //    boxIndexCluster[2].push_back(12);
    //    boxIndexCluster[2].push_back(13);
    //    boxIndexCluster[2].push_back(16);
    //    boxIndexCluster[2].push_back(17);

    //    boxIndexCluster[3].push_back(14);
    //    boxIndexCluster[3].push_back(15);
    //    boxIndexCluster[3].push_back(18);
    //    boxIndexCluster[3].push_back(19);

    //    boxIndexCluster[2].push_back(0);
    //    boxIndexCluster[2].push_back(4);

    //    boxIndexCluster[3].push_back(18);
    //    boxIndexCluster[4].push_back(19);

    getCombineBox(boxIndexCluster, rec_2v_index, rec_2h_index,rec_4_index);

    //combine box
    int rec_width = 98;
    int rec_height = 88;

    rec_2h.setWidth(rec_width*2+10);
    rec_2h.setHeight(rec_height);


    rec_2v.setWidth(rec_width);
    rec_2v.setHeight(rec_height*2+14);

    rec_4.setWidth(rec_width*2+10);
    rec_4.setHeight(rec_height*2+14);

    scene = new QGraphicsScene;
    scene->setSceneRect(-325,-195,325*2,195*2);

    QPen pen;
    pen.setWidth(3);
    pen.setColor(QColor(105,212,103));


    for(int i =0; i<rec_2v_index.size();i++)
    {
        QGraphicsRectItem *item = new QGraphicsRectItem(rec_2v);
        item->setPen(pen);
        item->setBrush(QColor(210,210,210));

        int index = rec_2v_index[i];

        if(index ==0 )
        {
            scene->addItem(item);
            item->setPos(110*(-3)+3, 100*(-2)+3);
        }
        if(index ==1 )
        {
            scene->addItem(item);
            item->setPos(110*(-3)+3, 100*(-0)+3);
        }
        if(index ==2 )
        {
            scene->addItem(item);
            item->setPos(110*(-2)+3, 100*(-2)+3);
        }
        if(index ==3 )
        {
            scene->addItem(item);
            item->setPos(110*(-2)+3, 100*(-0)+3);
        }
        if(index ==4 )
        {
            scene->addItem(item);
            item->setPos(110*(-1)+3, 100*(-1)+3);
        }
        if(index ==5 )
        {
            scene->addItem(item);
            item->setPos(110*(0)+3, 100*(-1)+3);
        }
        if(index ==6 )
        {
            scene->addItem(item);
            item->setPos(110*(1)+3, 100*(-2)+3);
        }
        if(index ==7 )
        {
            scene->addItem(item);
            item->setPos(110*(1)+3, 100*(-0)+3);
        }
        if(index ==8 )
        {
            scene->addItem(item);
            item->setPos(110*(2)+3, 100*(-2)+3);
        }
        if(index ==9 )
        {
            scene->addItem(item);
            item->setPos(110*(2)+3, 100*(-0)+3);
        }
    }

    for(int i =0; i<rec_2h_index.size();i++)
    {
        QGraphicsRectItem *item = new QGraphicsRectItem(rec_2h);
        item->setPen(pen);
        item->setBrush(QColor(210,210,210));

        int index = rec_2h_index[i];
        if(index ==0 )
        {
            scene->addItem(item);
            item->setPos(110*(-3)+4, 100*(-2)+4);
        }
        if(index ==1 )
        {
            scene->addItem(item);
            item->setPos(110*(-3)+4, 100*(-1)+4);
        }
        if(index ==2 )
        {
            scene->addItem(item);
            item->setPos(110*(-3)+4, 100*(0)+4);
        }
        if(index ==3 )
        {
            scene->addItem(item);
            item->setPos(110*(-3)+4, 100*(1)+4);
        }
        if(index ==4 )
        {
            scene->addItem(item);
            item->setPos(110*(-1)+4, 100*(-1)+4);
        }
        if(index ==5 )
        {
            scene->addItem(item);
            item->setPos(110*(-1)+4, 100*(0)+4);
        }
        if(index ==6 )
        {
            scene->addItem(item);
            item->setPos(110*(1)+4, 100*(-2)+4);
        }
        if(index ==7 )
        {
            scene->addItem(item);
            item->setPos(110*(1)+4, 100*(-1)+4);
        }
        if(index ==8 )
        {
            scene->addItem(item);
            item->setPos(110*(1)+4, 100*(0)+4);
        }
        if(index ==9 )
        {
            scene->addItem(item);
            item->setPos(110*(1)+4, 100*(1)+4);
        }
    }
    for(int i =0; i<rec_4_index.size();i++)
        qDebug()<<rec_4_index[i];
    for(int i =0; i<rec_4_index.size();i++)
    {
        QGraphicsRectItem *item = new QGraphicsRectItem(rec_4);
        item->setPen(pen);
        item->setBrush(QColor(210,210,210));

        int index = rec_4_index[i];
        if(index ==0 )
        {
            scene->addItem(item);
            item->setPos(110*(-3)+4, 100*(-2)+3);
        }
        if(index ==1 )
        {
            scene->addItem(item);
            item->setPos(110*(-3)+4, 100*(0)+3);
        }
        if(index ==2 )
        {
            scene->addItem(item);
            item->setPos(110*(-1)+4, 100*(-1)+3);
        }
        if(index ==3 )
        {
            scene->addItem(item);
            item->setPos(110*(1)+4, 100*(-2)+3);
        }
        if(index ==4 )
        {
            scene->addItem(item);
            item->setPos(110*(1)+4, 100*(0)+3);
        }
    }

    ui->graphicsView->setScene(scene);
    ui->graphicsView->show();
}
void BoxInfoWidget::getCombineBox(const std::vector<int>boxIndexCluster[], std::vector<int> &rec_2v_index , std::vector<int> &rec_2h_index, std::vector<int> &rec_4_index)
{
    for(int i=0; i<20;i++)
    {
        int size = boxIndexCluster[i].size();
        std::vector<int> indexTemp = boxIndexCluster[i];
        if(size == 2)
        {
            //v
            if(indexTemp[0] == 0 && indexTemp[1] == 1)
                rec_2v_index.push_back(0);
            if(indexTemp[0] == 2 && indexTemp[1] == 3)
                rec_2v_index.push_back(1);
            if(indexTemp[0] == 4 && indexTemp[1] == 5)
                rec_2v_index.push_back(2);
            if(indexTemp[0] == 6 && indexTemp[1] == 7)
                rec_2v_index.push_back(3);
            if(indexTemp[0] == 8 && indexTemp[1] == 9)
                rec_2v_index.push_back(4);
            if(indexTemp[0] == 10 && indexTemp[1] == 11)
                rec_2v_index.push_back(5);
            if(indexTemp[0] == 12 && indexTemp[1] == 13)
                rec_2v_index.push_back(6);
            if(indexTemp[0] == 14 && indexTemp[1] == 15)
                rec_2v_index.push_back(7);
            if(indexTemp[0] == 16 && indexTemp[1] == 17)
                rec_2v_index.push_back(8);
            if(indexTemp[0] == 18 && indexTemp[1] == 19)
                rec_2v_index.push_back(9);

            //h
            if(indexTemp[0] == 0 && indexTemp[1] == 4)
                rec_2h_index.push_back(0);
            if(indexTemp[0] == 1 && indexTemp[1] == 5)
                rec_2h_index.push_back(1);
            if(indexTemp[0] == 2 && indexTemp[1] == 6)
                rec_2h_index.push_back(2);
            if(indexTemp[0] == 3 && indexTemp[1] == 7)
                rec_2h_index.push_back(3);
            if(indexTemp[0] == 8 && indexTemp[1] == 10)
                rec_2h_index.push_back(4);
            if(indexTemp[0] == 9 && indexTemp[1] == 11)
                rec_2h_index.push_back(5);
            if(indexTemp[0] == 12 && indexTemp[1] == 16)
                rec_2h_index.push_back(6);
            if(indexTemp[0] ==13 && indexTemp[1] == 17)
                rec_2h_index.push_back(7);
            if(indexTemp[0] == 14 && indexTemp[1] == 18)
                rec_2h_index.push_back(8);
            if(indexTemp[0] == 15 && indexTemp[1] == 19)
                rec_2h_index.push_back(9);
        }
        else if (size == 4)
        {
            //4
            if(indexTemp[0] == 0 && indexTemp[1] == 1 && indexTemp[2] == 4 && indexTemp[3] == 5)
                rec_4_index.push_back(0);
            if(indexTemp[0] == 2 && indexTemp[1] == 3 && indexTemp[2] == 6 && indexTemp[3] == 7)
                rec_4_index.push_back(1);
            if(indexTemp[0] == 8 && indexTemp[1] == 9 && indexTemp[2] == 10 && indexTemp[3] == 11)
                rec_4_index.push_back(2);
            if(indexTemp[0] == 12 && indexTemp[1] == 13 && indexTemp[2] == 16 && indexTemp[3] == 17)
                rec_4_index.push_back(3);
            if(indexTemp[0] == 14 && indexTemp[1] == 15 && indexTemp[2] == 18 && indexTemp[3] == 19)
                rec_4_index.push_back(4);
        }
        else
        {

        }
    }
}
