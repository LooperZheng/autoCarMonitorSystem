#include "parcelloadingwidget.h"
#include "ui_parcelloadingwidget.h"
#include <QDesktopWidget>
#include <QDebug>
#include <QMessageBox>
#include <iostream>
#include <QTime>
#define TEXT_COLOR  QColor(255,12,12)
#define TEXT_COLOR_CUR  QColor(252,175,62)
ParcelLoadingWidget::ParcelLoadingWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ParcelLoadingWidget)
{
    ui->setupUi(this);
    initUi();//初始化界面参数
    initConnect();//初始化信号和槽连接
}

ParcelLoadingWidget::~ParcelLoadingWidget()
{
    delete ui;
}
void ParcelLoadingWidget::initUi()
{
    // 固定窗口的大小
    this->setFixedSize(this->width(), this->height());
    this->setWindowTitle("包裹装车");
    //设置弹出窗口的位置（在屏幕中央）
    QDesktopWidget *deskdop=QApplication::desktop();
    this->move((deskdop->width()-this->width())/2,      (deskdop->height()-this->height())/2);

    ui->textBrowser_parcelInfo->clear();
    isTextbrowserHaveContext = false;
    //设置光标焦点在该控件上
    ui->lineEdit_parcelID->setFocus();

    ui->radioButton_scanner->setChecked(true);
    ui->pushButton_query->setDisabled(true);

    m_pButtonGroup = new QButtonGroup(this);
    m_pButtonGroup->addButton(ui->radioButton_handleInput);
    m_pButtonGroup->addButton(ui->radioButton_scanner);

    //table Widget
    ui->tableWidget->setColumnCount(4);
    ui->tableWidget->setRowCount(5);
    ui->tableWidget->setHorizontalHeaderLabels(QStringList() <<"运单号"<< "收货人" << "手机后四位"<<"箱格位置");

    ui->tableWidget->setColumnWidth(0, 150);
}
void  ParcelLoadingWidget::initConnect()
{
    //connect(ui->lineEdit_parcelID, SIGNAL(editingFinished()), this, SLOT(getParcelIDFromScanner()));
     connect(ui->lineEdit_parcelID, SIGNAL( returnPressed()), this, SLOT(getParcelIDFromScanner()));
     connect(ui->pushButton_query, SIGNAL(clicked()), this, SLOT(getParcelInfo()));
     connect(m_pButtonGroup, SIGNAL(buttonClicked(QAbstractButton *)),this, SLOT(onButtonClicked(QAbstractButton*)));
}
void ParcelLoadingWidget::resetUI()
{
    ui->textBrowser_parcelInfo->clear();
    ui->lineEdit_parcelID->clear();
    //设置光标焦点在该控件上
    ui->lineEdit_parcelID->setFocus();

    ui->radioButton_scanner->setChecked(true);
    ui->pushButton_query->setDisabled(true);
}
int ParcelLoadingWidget::getAllParcleTobeLoaded()
{
    parcelIDClusters_load.clear();
    nameClusters_load.clear();
    phoneNumClusters_load.clear();
    boxPosClusters_load.clear();
    //query from DB
    MyDB mydb;
    if( !mydb.initDB("localhost","root","vip","db_vip"))
    {
        QMessageBox::information(NULL, "提示", "数据库连接失败 !\n");
        return 2;
    }
    else
    {
        //get time_slot_id
        string time_slot_id;
        QDateTime time = QDateTime::currentDateTime();//获取系统现在的时间
        QString str = time.toString("yyyy-MM-dd hh:mm:ss"); //设置显示格式
        string hour = str.toStdString().substr(11,2);
        string minute = str.toStdString().substr(14,2);
        int hour_int = atoi(hour.c_str());
        int minute_int = atoi(minute.c_str());
        qDebug()<<str;
        qDebug()<<hour_int;
        qDebug()<<minute_int;
        if (hour_int*60+minute_int < 10*60+30)
            time_slot_id = "1";
        if ((hour_int*60+minute_int > 10*60+31) && (hour_int*60+minute_int < 13*60+0))
            time_slot_id = "2";
        if ((hour_int*60+minute_int > 13*60+1) && (hour_int*60+minute_int < 15*60+30))
            time_slot_id = "3";
        if (hour_int*60+minute_int > 15*60+31 && (hour_int*60+minute_int < 18*60+00))
            time_slot_id = "4";
        // test
        if (hour_int*60+minute_int > 18*60+1 && (hour_int*60+minute_int < 22*60+40))
            time_slot_id = "5";
        if (hour_int*60+minute_int > 22*60+41 && (hour_int*60+minute_int < 24*60+00))
            time_slot_id = "6";
        //query table of transport_sn_scheduling_plan
        string query = "select transport_sn from db_vip.transport_sn_scheduling_plan where time_slot_id=";
        query +="\'";
        query +=time_slot_id;
        query +="\'";

        vector<vector<string> > result_transport_sn_scheduling_plan;
        if( !mydb.exeSQL(query, result_transport_sn_scheduling_plan ))
        {
            QMessageBox::information(NULL, "提示", "查询数据失败 !\n");
            return 2;
        }
        else
        {
            parcelIDClusters.clear();
            for(int i=0; i<result_transport_sn_scheduling_plan[0].size();i++)
                parcelIDClusters.push_back(QString::fromStdString(result_transport_sn_scheduling_plan[0][i]) );
        }

         //query table of transport_sn
        parcelIDClusters_new.clear();
        phoneNumClusters.clear();
        nameClusters.clear();
        for(int i = 0; i<parcelNum; i++)
        {
            string query = "select receiver_name,receiver_mobile from db_vip.transport_sns where transport_sn=";
            vector<vector<string> > result_transport_sn;
            QString condition = parcelIDClusters[i];
            query += "\'";
            query += condition.toStdString();
            query += "\'";
            query +=" and status='000' ";
            if( !mydb.exeSQL(query, result_transport_sn ))
            {
                QMessageBox::information(NULL, "提示", "查询数据失败 !\n");
                return 2;
            }
            else
            {
                if(result_transport_sn[0].size() != 0)
                {
                    parcelIDClusters_new.push_back(parcelIDClusters[i]);
                    nameClusters.push_back(QString::fromStdString(result_transport_sn[0][0]));
                    phoneNumClusters.push_back(QString::fromStdString(result_transport_sn[1][0]));
                }
            }
        }

        //query table of transport_sn_box_assignment
        parcelNum = parcelIDClusters_new.size();
        boxPosClusters.clear();
        for(int i = 0; i<parcelIDClusters_new.size(); i++)
        {
            string query = "select box_id from db_vip.transport_sn_box_assignment where transport_sn=";
            vector<vector<string> > result_transport_sn_box_assignment;
            QString condition = parcelIDClusters_new[i];
            query += "\'";
            query += condition.toStdString();
            query += "\'";
            if( !mydb.exeSQL(query, result_transport_sn_box_assignment ))
            {
                QMessageBox::information(NULL, "提示", "查询数据失败 !\n");
                return 2;
            }
            else
            {
                if(result_transport_sn_box_assignment[0].size() != 0)
                    boxPosClusters.push_back(QString::fromStdString(result_transport_sn_box_assignment[0][0]));
                else
                    boxPosClusters.push_back(QString("未查询到"));
            }
        }
    }

    if(parcelIDClusters_new.size() == 0)
        return  -1;
    else
        return 1;
}
void ParcelLoadingWidget::updateTableWidget()
{
    ui->tableWidget->clear();
    ui->tableWidget->setColumnCount(4);
    ui->tableWidget->setRowCount(parcelNum);
    ui->tableWidget->setHorizontalHeaderLabels(QStringList() <<"运单号"<< "收货人" << "手机号"<<"箱格位置");

    bool isCur = false;
    //loading
    if(parcelIDClusters_load.size() != 0 && nameClusters_load.size() !=0 && phoneNumClusters_load.size() != 0 && boxPosClusters_load.size() != 0)
    {
        isCur   = true;
        qDebug()<<"loading info";
        parcelID_cur = parcelID;
        name_cur = name;
        phone_cur = phone;
        boxPos_cur = boxPos;

        if(isGiveUpLoading == false)
        {
            qDebug()<<"ddd";
            QTableWidgetItem *item = new QTableWidgetItem();
            ui->tableWidget->setItem(0, 0, item);
            item->setFlags(item->flags() & (~Qt::ItemIsEditable));
            item->setBackgroundColor(TEXT_COLOR_CUR);
            ui->tableWidget->item(0,0)->setText(parcelID_cur);

            QTableWidgetItem *item1 = new QTableWidgetItem();
            ui->tableWidget->setItem(0, 1, item1);
            item1->setFlags(item1->flags() & (~Qt::ItemIsEditable));
            item1->setBackgroundColor(TEXT_COLOR_CUR);
            ui->tableWidget->item(0,1)->setText(name_cur);

            QTableWidgetItem *item2 = new QTableWidgetItem();
            ui->tableWidget->setItem(0, 2, item2);
            item2->setFlags(item2->flags() & (~Qt::ItemIsEditable));
            item2->setBackgroundColor(TEXT_COLOR_CUR);
            ui->tableWidget->item(0,2)->setText(phone_cur);

            QTableWidgetItem *item3 = new QTableWidgetItem();
            ui->tableWidget->setItem(0, 3, item3);
            item3->setFlags(item3->flags() & (~Qt::ItemIsEditable));
            item3->setBackgroundColor(TEXT_COLOR_CUR);
            ui->tableWidget->item(0,3)->setText(boxPos_cur);
        }
        else
            isGiveUpLoading = false;
    }
    //have loaded
    if(isCur == true)
    {
        for(int i =0; i<parcelIDClusters_load.size()-1; i++)
        {
            int index = i+1;

            QTableWidgetItem *item = new QTableWidgetItem();
            ui->tableWidget->setItem(index, 0, item);
            item->setFlags(item->flags() & (~Qt::ItemIsEditable));
            item->setTextColor(TEXT_COLOR);
            ui->tableWidget->item(index,0)->setText(parcelIDClusters_load[i]);

            QTableWidgetItem *item1 = new QTableWidgetItem();
            ui->tableWidget->setItem(index, 1, item1);
            item1->setFlags(item1->flags() & (~Qt::ItemIsEditable));
            item1->setTextColor(TEXT_COLOR);
            ui->tableWidget->item(index,1)->setText(nameClusters_load[i]);

            QTableWidgetItem *item2 = new QTableWidgetItem();
            ui->tableWidget->setItem(index, 2, item2);
            item2->setFlags(item2->flags() & (~Qt::ItemIsEditable));
            item2->setTextColor(TEXT_COLOR);
            ui->tableWidget->item(index,2)->setText(phoneNumClusters_load[i]);

            QTableWidgetItem *item3 = new QTableWidgetItem();
            ui->tableWidget->setItem(index, 3, item3);
            item3->setFlags(item3->flags() & (~Qt::ItemIsEditable));
            item3->setTextColor(TEXT_COLOR);
            ui->tableWidget->item(index,3)->setText(boxPosClusters_load[i]);
            qDebug()<<"ss";
        }
    }

    //to be loaded
    for(int i =0; i<parcelIDClusters_new.size(); i++)
    {

        int index =parcelIDClusters_load.size()+i;

        QTableWidgetItem *item = new QTableWidgetItem();
        ui->tableWidget->setItem(index, 0, item);
        item->setFlags(item->flags() & (~Qt::ItemIsEditable));
        ui->tableWidget->item(index,0)->setText(parcelIDClusters_new[i]);

        QTableWidgetItem *item1 = new QTableWidgetItem();
        ui->tableWidget->setItem(index, 1, item1);
        item1->setFlags(item1->flags() & (~Qt::ItemIsEditable));
        ui->tableWidget->item(index,1)->setText(nameClusters[i]);

        QTableWidgetItem *item2 = new QTableWidgetItem();
        ui->tableWidget->setItem(index, 2, item2);
        item2->setFlags(item2->flags() & (~Qt::ItemIsEditable));
        ui->tableWidget->item(index,2)->setText(phoneNumClusters[i]);

        QTableWidgetItem *item3 = new QTableWidgetItem();
        ui->tableWidget->setItem(index, 3, item3);
        item3->setFlags(item3->flags() & (~Qt::ItemIsEditable));
        ui->tableWidget->item(index,3)->setText(boxPosClusters[i]);
    }
}

void ParcelLoadingWidget::on_pushButton_giveUp_clicked()
{
    if(isTextbrowserHaveContext == false)
        QMessageBox::information(NULL, "提示", "请选择要操作的包裹 !\n");
    else
    {
        QMessageBox::StandardButton rb=QMessageBox::information(NULL, "提示", "  您放弃装载该包裹", QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes);
        if(rb == QMessageBox::Yes)
        {
             qDebug()<<"yes";
             updateParcelStateInDB_giveUpLoad();
             //do not display
             isGiveUpLoading = true;
             updateTableWidget();
             parcelNum --;
             parcelIDClusters_load.pop_back();
             nameClusters_load.pop_back();
             boxPosClusters_load.pop_back();
             phoneNumClusters_load.pop_back();

        }
        else
            qDebug()<<"no";
    }
}
void ParcelLoadingWidget::on_pushButton_haveLoad_clicked()
{
    if(isTextbrowserHaveContext == false)
        QMessageBox::information(NULL, "提示", "请选择要操作的包裹 !\n");
    else
    {
        updateParcelStateInDB_load();
    }
}
void ParcelLoadingWidget::getParcelIDFromScanner()
{
    qDebug()<<"get parcel ID from scanner";
    if(ui->radioButton_handleInput->isChecked() == true)
    {
        ui->lineEdit_parcelID->clear();
        QMessageBox::information(NULL, "提示", "请选择正确的查询方式 !\n");
    }
    else
    {
        parcelID_scanner = ui->lineEdit_parcelID->text();
        ui->lineEdit_parcelID->clear();
        getParcelInfo();
    }
}
bool ParcelLoadingWidget::checkParcelID(QString parcelID)
{
    qDebug()<<parcelID;
    if(parcelID.length() == 0)
        return false;
    else
    {
        if(parcelID.length()!= 10)
            return false;
        else
        {
            for(int i=0; i<parcelID.length(); i++)
            {
                if(parcelID[i]>='0' && parcelID[i]<='9');
                else
                    return false;
            }
        }
        return true;
    }
}
void ParcelLoadingWidget::getParcelInfo()
{
    if(ui->radioButton_handleInput->isChecked() == true)
        parcelID = ui->lineEdit_parcelID->text();
    else
        parcelID = parcelID_scanner;

    qDebug()<<"get Parcel Info of laoding";
    if(parcelID.size() ==0)
    {
        QMessageBox::information(NULL, "提示", "包裹单号为空 !\n");
    }
    else
    {
        //if( !checkParcelID(parcelID))
        if( 0 )
            QMessageBox::information(NULL, "提示", "包裹单号格式不正确 !\n");
        else
        {
            if(std::find(parcelIDClusters_new.begin(),parcelIDClusters_new.end(), parcelID) == parcelIDClusters_new.end()
                    && std::find(parcelIDClusters_load.begin(),parcelIDClusters_load.end(), parcelID) == parcelIDClusters_load.end() )
            {
                QMessageBox::information(NULL, "提示", "该运单不是待装包裹 !\n");
            }
            else
            {
                //query from DB
                MyDB mydb;
                if( !mydb.initDB("localhost","root","vip","db_vip"))
                {
                    QMessageBox::information(NULL, "提示", "数据库连接失败 !\n");
                    return;
                }
                else
                {
                    parcelInfo.clear();

                    //query table of transport_sn_scheduling_plan
                    string query = "select transport_sn,vp_order_sn,receiver_name,receiver_mobile,receiver_address,stop,status,box_type from db_vip.transport_sns where transport_sn=";
                    query += "\'";
                    query += parcelID.toStdString();
                    query += "\'";
                    vector<vector<string> > result_transport_sn;
                    if( !mydb.exeSQL(query, result_transport_sn))
                    {
                        QMessageBox::information(NULL, "提示", "查询数据失败 !\n");
                        return;
                    }
                    else
                    {
                        qDebug()<<"query transport_sns ";
                        cout<<result_transport_sn.size();
                        cout<<endl<<result_transport_sn[0][0]<<endl;
                        //display
                        parcelInfo.append("运单号         : ");
                        parcelInfo.append(QString::fromStdString(result_transport_sn[0][0]));
                        parcelInfo.append("\n");
                        parcelID = QString::fromStdString(result_transport_sn[0][0]);

                        parcelInfo.append("订单号         : ");
                        parcelInfo.append(QString::fromStdString(result_transport_sn[1][0]));
                        parcelInfo.append("\n");

                        parcelInfo.append("用户名         : ");
                        parcelInfo.append(QString::fromStdString(result_transport_sn[2][0]));
                        parcelInfo.append("\n");
                        name = QString::fromStdString(result_transport_sn[2][0]);

                        parcelInfo.append("用户电话     : ");
                        parcelInfo.append(QString::fromStdString(result_transport_sn[3][0]));
                        parcelInfo.append("\n");
                        phone = QString::fromStdString(result_transport_sn[3][0]);

                        parcelInfo.append("收货地址     : ");
                        parcelInfo.append(QString::fromStdString(result_transport_sn[4][0]));
                        parcelInfo.append("\n");
                        parcelInfo.append("所属停靠点 : ");
                        parcelInfo.append(QString::fromStdString(result_transport_sn[5][0]));
                        parcelInfo.append("\n");
                        parcelInfo.append("运单状态     : ");
                        parcelInfo.append(QString::fromStdString(result_transport_sn[6][0]));
                        parcelInfo.append("\n");
                        parcelInfo.append("运单箱型     : ");
                        parcelInfo.append(QString::fromStdString(result_transport_sn[7][0]));
                        parcelInfo.append("\n");
                    }

                    //query table of transport_sn_box_assignment
                    string query_box =  "select box_id from db_vip.transport_sn_box_assignment where transport_sn=";
                    query_box += "\'";
                    query_box += parcelID.toStdString();
                    query_box += "\'";
                    vector<vector<string> > result_box;
                    if( !mydb.exeSQL(query_box, result_box))
                    {
                        QMessageBox::information(NULL, "提示", "查询数据失败 !\n");
                        return;
                    }
                    else
                    {
                        qDebug()<<"query transport_sn_box_assignment ";
                        //display
                        parcelInfo.append("箱格位置     : ");
                        //cout<<result_box[0].size()<<endl;
                        if(result_box[0].size()==0)
                        {
                            parcelInfo.append("未查询到位置");
                            boxPos = "未查询到位置";
                        }
                        else
                        {
                            parcelInfo.append(QString::fromStdString(result_box[0][0]));
                            boxPos = QString::fromStdString(result_box[0][0]);
                        }
                    }

                    //display on textbrower
                    ui->textBrowser_parcelInfo->setText(parcelInfo);
                    isTextbrowserHaveContext = true;
                    //update table
                    int index =0;
                    for(int i = 0; i<parcelIDClusters_new.size(); i++)
                    {
                        if(parcelID == parcelIDClusters_new[i])
                        {
                            index = i;
                            break;
                        }
                    }
                    qDebug()<<"index = "<<index;
                    if(std::find(parcelIDClusters_new.begin(),parcelIDClusters_new.end(), parcelID) != parcelIDClusters_new.end())
                    {
                        qDebug()<<parcelIDClusters_new[index];
                        parcelIDClusters_load.push_back(parcelIDClusters_new[index]);
                        parcelIDClusters_load.erase(parcelIDClusters_new.begin()+index);

                        nameClusters_load.push_back(nameClusters[index]);
                        nameClusters.erase(nameClusters.begin()+index);

                        phoneNumClusters_load.push_back(phoneNumClusters[index]);
                        phoneNumClusters.erase(phoneNumClusters.begin()+index);

                        boxPosClusters_load.push_back(boxPosClusters[index]);
                        boxPosClusters.erase(boxPosClusters.begin()+index);

                        //open box
                        if(getBoxIndex(boxPos))
                            emit signal_openBox_parcelLoading(boxIndex);
                        updateTableWidget();
                        updateParcelStateInDB_load();
                    }
                    else
                    {
                        if(std::find(parcelIDClusters_load.begin(),parcelIDClusters_load.end(), parcelID) != parcelIDClusters_load.end())
                            QMessageBox::information(NULL, "提示", "该包裹已装车 !");
                        else
                            QMessageBox::information(NULL, "提示", "该包裹不是待装车的包裹 !");
                    }
                }
            }
        }
    }
}
bool ParcelLoadingWidget::getBoxIndex(QString boxInfo)
{
    boxIndex.clear();

    QString boxIDSeg = boxInfo;
    QStringList boxIdList;
    boxIdList =  boxIDSeg.split(',');
    for(int i=0;i<boxIdList.size();i++)
    {
        QString boxID = boxIdList[i];
        qDebug()<<boxID;
        int boxTmp = getBoxIndexAccordingToBoxID(boxID);
        if(boxTmp != 999)
            boxIndex.push_back(boxTmp);
    }
    return true;
}
// TBD
int ParcelLoadingWidget::getBoxIndexAccordingToBoxID(QString boxID)
{
    if(boxID == "A1")
        return 1;
    if(boxID == "A2")
        return 2;
    if(boxID == "A3")
        return 3;
    if(boxID == "A4")
        return 4;
    if(boxID == "A5")
        return 5;
    if(boxID == "A6")
        return 6;
    if(boxID == "A7")
        return 7;
    if(boxID == "A8")
        return 8;
    if(boxID == "B1")
        return 9;
    if(boxID == "B2")
        return 10;
    if(boxID == "B3")
        return 11;
    if(boxID == "B4")
        return 12;
    if(boxID == "B5")
        return 13;
    if(boxID == "B6")
        return 14;
    if(boxID == "B7")
        return 15;
    if(boxID == "B8")
        return 16;
    if(boxID == "C1")
        return 17;
    if(boxID == "C2")
        return 18;
    if(boxID == "C3")
        return 19;
    if(boxID == "C4")
        return 20;
    else
        return 999;
}
void ParcelLoadingWidget::onButtonClicked(QAbstractButton *)
{
    if(ui->radioButton_handleInput->isChecked() == true)
    {
        ui->pushButton_query->setDisabled(false);
        ui->lineEdit_parcelID->clear();
        ui->lineEdit_parcelID->setFocus();
        ui->textBrowser_parcelInfo->clear();
        isTextbrowserHaveContext = false;
    }
    if(ui->radioButton_scanner->isChecked() == true)
    {
        ui->pushButton_query->setDisabled(true);
        ui->lineEdit_parcelID->clear();
        ui->lineEdit_parcelID->setFocus();
        ui->textBrowser_parcelInfo->clear();
        isTextbrowserHaveContext = false;
    }
}
//修改数据库中包裹的状态
void ParcelLoadingWidget::updateParcelStateInDB_load()
{
    //update DB
    MyDB mydb;
    if( !mydb.initDB("localhost","root","vip","db_vip"))
    {
        QMessageBox::information(NULL, "提示", "数据库连接失败 !\n");
        return;
    }
    else
    {
        //已装车[100]
        string update = "update db_vip.transport_sns set status='100' where transport_sn=";
        update += "\'";
        update += parcelID.toStdString();
        update += "\'";
        if( !mydb.updateData(update))
        {
            QMessageBox::information(NULL, "提示", "查询数据失败 !\n");
            return;
        }
        else
        {
            qDebug()<<"update  parcel status= 100 ";
            return;
        }
    }
}
void ParcelLoadingWidget::updateParcelStateInDB_giveUpLoad()
{
    //update DB
    MyDB mydb;
    if( !mydb.initDB("localhost","root","vip","db_vip"))
    {
        QMessageBox::information(NULL, "提示", "数据库连接失败 !\n");
        return;
    }
    else
    {
        //未装车[000]
        string update = "update db_vip.transport_sns set status='000' where transport_sn=";
        update += "\'";
        update += parcelID.toStdString();
        update += "\'";
        if( !mydb.updateData(update))
        {
            QMessageBox::information(NULL, "提示", "查询数据失败 !\n");
            return;
        }
        else
        {
            qDebug()<<"update  parcel status = 000";
            return;
        }
    }
}
