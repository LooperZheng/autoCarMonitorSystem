#include "mydb.h"
#include<iostream>
#include<cstdlib>
#include <vector>
MyDB::MyDB()
{
    connection = mysql_init(NULL); // 初始化数据库连接变量
    if(connection == NULL)
    {
        cout << "Error:" << mysql_error(connection);
        exit(1);
    }
}
MyDB::~MyDB()
{
    if(connection != NULL)  // 关闭数据库连接
    {
        mysql_close(connection);
    }
}
bool MyDB::initDB(string host, string user, string pwd, string db_name)
{
    // 函数mysql_real_connect建立一个数据库连接
    // 成功返回MYSQL*连接句柄，失败返回NULL
    connection = mysql_real_connect(connection, host.c_str(),user.c_str(), pwd.c_str(), db_name.c_str(), 0, NULL, 0);
    if(connection == NULL)
    {
        cout << "Error:" << mysql_error(connection);
        return false;
    }
    return true;
}
bool MyDB::exeSQL(string sql , std::vector<std::vector<string> > &query_result)
{
    // mysql_query()执行成功返回0，失败返回非0值。与PHP中不一样
    mysql_query(connection, "set names utf8"); // 中文乱码解决办
    if(mysql_query(connection, sql.c_str()))
    {
        cout << "Query Error:" << mysql_error(connection);
        return false;
    }
    else
    {
        result=mysql_store_result(connection);//保存查询到的数据到result
        int column = mysql_field_count(connection); //返回connect查询的列数
        query_result.resize(column);

        MYSQL_FIELD *fd;
        for(int i=0;fd=mysql_fetch_field(result);i++)//获取列名
        {
            cout<<" "<<fd->name<<" ";
            //query_result[i].push_back(fd->name);
        }
        cout<<endl;

        // mysql_num_rows()返回result查询的行数
        for(int i=0; i <(unsigned long)mysql_num_rows(result); ++i)
        {
            // 获取下一行
            row = mysql_fetch_row(result);
            if(row <= 0)
            {
                break;
            }

            unsigned long *lengths;
            lengths = mysql_fetch_lengths(result);
            // mysql_num_fields()返回结果集中的字段数
            for(int j=0; j < mysql_num_fields(result); ++j)
            {
                if((int)lengths[j] ==0)
                {
                    cout<<"null";
                    query_result[j].push_back("null");
                }
                else
                {
                    cout << row[j] << " ";
                    query_result[j].push_back(row[j]);
                }
            }
            cout << endl;
        }
        // 释放结果集的内存
        mysql_free_result(result);
    }
    return true;

}
bool MyDB::deleteData(string sql)
{
     mysql_query(connection, "set names utf8"); // 中文乱码解决办
    if(mysql_query(connection, sql.c_str()))        //执行SQL语句
    {
        cout << "Query Error:" << mysql_error(connection);
        return false;
    }
    else
    {
        cout<<"Delete Success"<<endl;
        return true;
    }
}
bool MyDB::updateData(string sql)
{
     mysql_query(connection, "set names utf8"); // 中文乱码解决办
    if(mysql_query(connection, sql.c_str()))        //执行SQL语句
    {
        cout << "Query Error:" << mysql_error(connection);
        return false;
    }
    else
    {
        cout<<"Update Success"<<endl;
        return true;
    }
}
bool MyDB::insertData(string sql)
{
    mysql_query(connection, "set names utf8"); // 中文乱码解决办
    mysql_query(connection, "set names utf8"); // 中文乱码解决办
    if(mysql_query(connection, sql.c_str()))        //执行SQL语句
    {
        cout << "Query Error:" << mysql_error(connection);
        return false;
    }
    else
    {
        cout<<"Insert Success"<<endl;
        return true;
    }
}
