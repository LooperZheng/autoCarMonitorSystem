#include "rejectioncheckwidget.h"
#include "ui_rejectioncheckwidget.h"
#include <QDesktopWidget>
#include <QMessageBox>
#include <QDebug>
#include "mydb.h"
RejectionCheckWidget::RejectionCheckWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::RejectionCheckWidget)
{
    ui->setupUi(this);
    initUi();//初始化界面参数
    initConnect();//初始化信号和槽连接
}

RejectionCheckWidget::~RejectionCheckWidget()
{
    delete ui;
}
void RejectionCheckWidget::initUi()
{
    // 固定窗口的大小
    this->setFixedSize(this->width(), this->height());
    this->setWindowTitle("拒收审核");
    //设置弹出窗口的位置（在屏幕中央）
    QDesktopWidget *deskdop=QApplication::desktop();
    this->move((deskdop->width()-this->width())/2,      (deskdop->height()-this->height())/2);

    ui->radioButton_no->setFocusPolicy(Qt::NoFocus);
    ui->radioButton_ok->setFocusPolicy(Qt::NoFocus);
    m_pButtonGroup = new QButtonGroup(this);
    m_pButtonGroup->addButton(ui->radioButton_ok);
    m_pButtonGroup->addButton(ui->radioButton_no);

    //table Widget
    ui->tableWidget->setColumnCount(4);
    ui->tableWidget->setRowCount(1);
    ui->tableWidget->setHorizontalHeaderLabels(QStringList() << "运单号" << "订单号" << "收货人" << "电话");

    ui->tableWidget->setColumnWidth(0, 150);
    ui->tableWidget->setColumnWidth(1, 150);
    ui->tableWidget->setColumnWidth(3, 110);

}
void RejectionCheckWidget::initConnect()
{

}

//从物流部分的socket获得 品骏订单号
void RejectionCheckWidget::getParcelID_vpFromLogistics(QString ID)
{
    parcelID_pj = ID;
}
//一个订单对应多个包裹时要全部显示
bool RejectionCheckWidget::getAllRejectionParcelInfoFromDB()
{
    parcelIDClusters.clear();
    parcelID_vpClusters.clear();
    nameClusters.clear();
    phoneClusters.clear();
    BoxIDClusters.clear();
    //query from DB
    MyDB mydb;
    if( !mydb.initDB("localhost","root","vip","db_vip"))
    {
        QMessageBox::information(NULL, "提示", "数据库连接失败 !\n");
        return false;
    }
    else
    {
        //query info
        string query = "select transport_sn,vp_order_sn,receiver_name,receiver_mobile from db_vip.transport_sns where pj_order_sn=";
        query += "\'";
        query += parcelID_pj.toStdString();
        query += "\'";
        vector<vector<string> > result_transport_sn;
        if( !mydb.exeSQL(query, result_transport_sn))
        {
            QMessageBox::information(NULL, "提示", "查询数据失败 !\n");
            return false;
        }
        else
        {
            parcelNum = result_transport_sn[0].size();
            qDebug()<<"query transport_sns";
            if(parcelNum ==0 )
            {
                QMessageBox::information(NULL, "提示", "没有查询到该数据 !\n");
                return false;
            }
            for(int i=0; i<parcelNum;i++)
            {
                parcelIDClusters.push_back(QString::fromStdString(result_transport_sn[0][i]));
                parcelID_vpClusters.push_back(QString::fromStdString(result_transport_sn[1][i]));
                nameClusters.push_back(QString::fromStdString(result_transport_sn[2][i]));
                phoneClusters.push_back(QString::fromStdString(result_transport_sn[3][i]));
            }
        }
        //query boxID
        for(int j=0;j<parcelNum;j++ )
        {
            string query = "select box_id from db_vip.transport_sn_box_assignment where transport_sn=";
            query += "\'";
            query += parcelIDClusters[j].toStdString();
            //query += "6100000025";
            query += "\'";
            qDebug()<<QString::fromStdString(query);
            vector<vector<string> > result_transport_sn_box;
            if( !mydb.exeSQL(query, result_transport_sn_box))
            {
                QMessageBox::information(NULL, "提示", "查询数据失败 !\n");
                return false;
            }
            else
            {
                if(result_transport_sn_box[0].size() == 0)
                {
                      QMessageBox::information(NULL, "提示", "数据库中没有对应单号中boxID !\n");
                      return false;
                }
                else
                {
                    BoxIDClusters.push_back(QString::fromStdString(result_transport_sn_box[0][0]));
                }
            }
        }
        return true;
    }
}
void RejectionCheckWidget::updateTableWidget()
{
    // 品骏运单号+唯品会订单号
    ui->tableWidget->clear();
    ui->tableWidget->setColumnCount(4);
    ui->tableWidget->setRowCount(parcelNum);
    ui->tableWidget->setHorizontalHeaderLabels(QStringList() << "运单号" << "唯品会订单号" << "收货人" << "电话");


    for(int i =0; i<parcelNum; i++)
    {
        QTableWidgetItem *item = new QTableWidgetItem();
        ui->tableWidget->setItem(i, 0, item);
        item->setFlags(item->flags() & (~Qt::ItemIsEditable));
        ui->tableWidget->item(i,0)->setText(parcelIDClusters[i]);

        QTableWidgetItem *item1 = new QTableWidgetItem();
        ui->tableWidget->setItem(i, 1, item1);
        item1->setFlags(item1->flags() & (~Qt::ItemIsEditable));
        ui->tableWidget->item(i,1)->setText(parcelID_vpClusters[i]);

        QTableWidgetItem *item2 = new QTableWidgetItem();
        ui->tableWidget->setItem(i, 2, item2);
        item2->setFlags(item2->flags() & (~Qt::ItemIsEditable));
        ui->tableWidget->item(i,2)->setText(nameClusters[i]);

        QTableWidgetItem *item3 = new QTableWidgetItem();
        ui->tableWidget->setItem(i, 3, item3);
        item3->setFlags(item3->flags() & (~Qt::ItemIsEditable));
        ui->tableWidget->item(i,3)->setText(phoneClusters[i]);
    }

}
void RejectionCheckWidget::on_pushButton_clicked()
{
    if(ui->radioButton_no->isChecked() || ui->radioButton_ok->isChecked())
    {
        if(ui->radioButton_ok->isChecked() == true)
        {
            emit signal_agree_rejection("1");
            emit signal_boxIDCluster_rejection(BoxIDClusters);
            agreeRejection.show();
            agreeRejection.getParcelIDandPjID(parcelIDClusters,parcelID_pj);
        }
        else
        {
            emit signal_disagree_rejection("0");
            disagreeRejection.show();
            disagreeRejection.getParcelIDandPjID(parcelIDClusters, parcelID_pj);
        }
    }
    else
    {
       QMessageBox::information(NULL, "提示", "请首先选择是否同意拒收!\n");
    }
}
