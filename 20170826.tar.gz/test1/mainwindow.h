#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QFileDialog>
#include <QStackedWidget>
#include <QListWidget>
#include <QWebView>
#include <QWebFrame>
#include <QHBoxLayout>
#include <QPalette>
#include <QTimer>
#include <QTime>
#include <QDebug>
#include <QMessageBox>
#include <QtMultimedia>
#include "teleoperation.h"
#include "camerasetwidget.h"
#include "remainingparcelwidget.h"
#include "startdeliverywidget.h"
#include "statisticalreportwidget.h"
#include "parcelloadingwidget.h"
#include "parcelmanagementwidget.h"
#include "rejectioncheckwidget.h"
#include "neworderinfowidget.h"
#include "parcelinfowidget.h"
#include "detentionreasonwidget.h"
#include "taskplanwidget.h"
#include "robot.h"
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    //普通构造函数能够被隐式调用,explicit构造函数只能被显式调用。
    explicit MainWindow(QWidget *parent = 0);
    void initConnect();
    void initUi();
    void initData();
    ~MainWindow();

    void sleep(unsigned int msec)
    {
        QTime dieTime = QTime::currentTime().addMSecs(msec);
        while( QTime::currentTime() < dieTime )
            QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
    }

    void getTaskSeqAndInfoAccordingDB();
    QString getPlanningTime(int);
    string  generateMsgHead(string len, string type);
    void playAudio(QString audioID);
    int getBoxIndexAccordingToBoxID(QString);

    std::vector<int> boxIndex;
    QMediaPlayer *audioPlayer;
    std::map<QString,int> audioMap;
    std::map<int,QString> TaskPointMap;
    bool isArriveTaskPoint;
private:
    std::set<int> taskSeqTmp;
    std::vector<int> taskSeq;
    std::vector<QString> taskInfoClu;

    std::vector<int> taskSeq_plan;
    std::vector<int> taskSeq_planTime;
    QString parcelID_vp;

    int nextTaskPoint;
    int currentTaskPoint;
public slots:

    void addJavaScriptObject();
    void refreshBaiduMapAll();
    void refreshBaiduMapVehicle();
    void refreshBaiduMapTask();

    void on_button_cameraSet_clicked();
    void on_button_sysRestart_clicked();
    void on_button_operationExchange_clicked();
    void on_button_monitorStart_clicked();
    void on_button_vehicleStart_clicked();

    void on_button_statisticalReport_clicked();
    void on_button_remainingHandle_clicked();
    void on_button_messageHandle_clicked();
    void on_button_parcelLoading_clicked();
    void on_button_startDelivery_clicked();
    void on_button_rejectionCheck_clicked();
    void on_button_parcelManagement_clicked();

    //test
    void on_pushButton_5_clicked();

    void slot_arriveTaskPointAfterTenMinutes();
    void slot_arriveTaskPoint();
    void slot_returnStation();
    void slot_boxClose();
    void slot_arriveTaskPoint_getTaskPointID(int);
    void slot_leaveTaskPointt_getTaskPointID(int);
    //mainwidow上的左上和右上显示框内容更新
    void showVehicleInfo();
    void showRoadInfo();
    void showSysInfo();
    void showTaskInfo();
    void showParcelInfo();

    void updateTeleoperationRobotInfo();

    void showTime();
    string changeTimeFormat(string time);
     //不同类对象之间通信
    void teleoperationWidget_BoxAskShow();
    void teleoperationWidget_VehicleAskShow();

    void teleoperationWidget_VehicleControlCmd(int, int);
    void teleoperationWidget_VehicleTurnLeft();
    void teleoperationWidget_VehicleTurnRight();
    void teleoperationWidget_VehicleForward();
    void teleoperationWidget_VehicleBackward();
    void teleoperationWidget_VehicleStop();
    void teleoperationWidget_VehicleStart();
    void teleoperationWidget_VehicleHorn();
    void teleoperationWidget_VehicleLight();
    void teleoperationWidget_VehicleLightClose();
    void teleoperationWidget_OperationExchange();

    void boxInfoWidget_openBox(std::vector<int>);

    void newOrderInfoWidget_updateMsgNum(int);

    void startDeliveryWidegt_startTaskPlan();

    void rejectionWidget_agree(QString);
    void rejectionWidget_disagree(QString);
    void rejectionWidget_boxIDCluster(std::vector<QString>);

    void parcelInfoWidget_changeDetention(QString);
    void parcelInfoWidget_changeMan(QString);

    void updateDB_vehiclePos();
    void updateDB_vehicleRoutePlanTable();
    void updateDB_vehicleGeoInfo_nextStopID(int);
    void updateDB_vehicleGeoInfo_currentStopID(int);

    void sendSocketToLogistic(QString);
    void slot_acceptMsgFromLogistic();

    void robot_getBoxState(BoxInfo);
private:
    Ui::MainWindow *ui;
    Robot *myRobot;
    QTimer *timer;
    QTimer *timer_mapRefresh;
    QTimer *timer_InfoRefresh;
    QTimer *timer_dbRefresh;

    Teleoperation teleoperation;
    VehicleInfoWidget vehicleInfoWidget;

    CameraSetWidget cameraSetWidget;

    BoxInfoWidget boxInfoWidget;

    RemainingParcelWidget remainingParcelWidget;

    StatisticalReportWidget statisticalReportWidget;
    ParcelManagementWidget parcelManagementWidget;
    ParcelLoadingWidget parcelLoadingWidget;
    StartDeliveryWidget startDeliveryWidget;
    RejectionCheckWidget rejectionCheckWidget;
    NewOrderInfoWidget newOrderInfoWidget;
    TaskPlanWidget taskPlanWidget;

    Sever tcpIpSever_Logistic;
    string LogisticSocketReturnCode;
};

#endif // MAINWINDOW_H
