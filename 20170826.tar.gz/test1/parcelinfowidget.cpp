﻿#include "parcelinfowidget.h"
#include "ui_parcelinfowidget.h"
#include <QDesktopWidget>
#include <QDebug>
#include <QMessageBox>
#include "mydb.h"
ParcelInfoWidget::ParcelInfoWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ParcelInfoWidget)
{
    ui->setupUi(this);
    initUi();//初始化界面参数
    initConnect();//初始化信号和槽连接
}

ParcelInfoWidget::~ParcelInfoWidget()
{
    delete ui;
}
void ParcelInfoWidget::initUi()
{
    // 固定窗口的大小
    this->setFixedSize(this->width(), this->height());
    this->setWindowTitle("包裹信息");
    //设置弹出窗口的位置（在屏幕中央）
    QDesktopWidget *deskdop=QApplication::desktop();
    this->move((deskdop->width()-this->width())/2,      (deskdop->height()-this->height())/2);
    //ui->textBrowser->setText("dd");


}
void ParcelInfoWidget::initConnect()
{

}
void ParcelInfoWidget::getParcelID(QString str)
{
    parcelID = str;
}
QString ParcelInfoWidget::parcelStatusMap_inv(QString parcelStatusTmp)
{
    QString parcelState;
    if(parcelStatusTmp == "000")
        parcelState = "未装车";
    if(parcelStatusTmp == "100")
        parcelState = "已装车";
    if(parcelStatusTmp == "200")
        parcelState = "已出发";
    if(parcelStatusTmp == "500")
        parcelState = "滞留";
    if(parcelStatusTmp == "400")
        parcelState = "拒收";
    if(parcelStatusTmp == "301")
        parcelState = "本人签收";
    if(parcelStatusTmp == "302")
        parcelState = "他人签收";
    if(parcelStatusTmp == "600")
        parcelState = "人工配送";
    return parcelState;
}
bool ParcelInfoWidget::queryParcelnfo()
{
    bookID = "Nan";
    name = "Nan";
    phone = "Nan";
    bookPlace = "Nan";
    deliveryPlace = "Nan";
    boxType = "Nan";
    parcelState = "Nan";
    parcelPosition = "Nan";
    receiverAddress = "Nan";
    // find the data
    MyDB mydb;
    if( !mydb.initDB("localhost","root","vip","db_vip"))
    {
        QMessageBox::information(NULL, "提示", "数据库连接失败 !\n");
        return false;
    }
    else
    {
        //query info
        string query = "select pj_order_sn,vp_order_sn,receiver_name,receiver_mobile,receiver_address,box_type,status,time_slot_id,stop_id,abreason from db_vip.transport_sns where transport_sn=";
        query += "\'";
        query += parcelID.toStdString();
        query += "\'";
        qDebug()<<QString::fromStdString(query);
        vector<vector<string> > result_transport_sn;
        if( !mydb.exeSQL(query, result_transport_sn))
        {
             qDebug()<<"query ..............";
            QMessageBox::information(NULL, "提示", "查询 transport_sns 失败 !\n");
            return false;
        }
        else
        {
            qDebug()<<"query transport_sns";
            if(result_transport_sn[0].size() == 0)
            {
                bookID = "未查询到信息";
                name = "未查询到信息";
                phone = "未查询到信息";
                receiverAddress = "未查询到信息";
                boxType = "未查询到信息";
                parcelState = "未查询到信息";
                deliveryTime = "未查询到时间";
                deliverySchedule = "未查询到班次";
                deliveryPlace = "未查询到停靠点";
            }
            else
            {
                parcelID_pj = QString::fromStdString(result_transport_sn[0][0]);
                bookID = QString::fromStdString(result_transport_sn[1][0]);
                name = QString::fromStdString(result_transport_sn[2][0]);
                phone = QString::fromStdString(result_transport_sn[3][0]);
                receiverAddress = QString::fromStdString(result_transport_sn[4][0]);
                boxType = QString::fromStdString(result_transport_sn[5][0]);
                parcelState = QString::fromStdString(result_transport_sn[6][0]);
                deliverySchedule = QString::fromStdString(result_transport_sn[7][0]);
                deliveryTime = QString::fromStdString(result_transport_sn[7][0]);
                deliveryPlace = QString::fromStdString(result_transport_sn[8][0]);
                abortReason = QString::fromStdString(result_transport_sn[9][0]);
            }
        }
        //query table of transport_sn_box_assignment
        string query_box =  "select box_id from db_vip.transport_sn_box_assignment where transport_sn=";
        query_box += "\'";
        query_box += parcelID.toStdString();
        query_box += "\'";
        vector<vector<string> > result_box;
        if( !mydb.exeSQL(query_box, result_box))
        {
            QMessageBox::information(NULL, "提示", "查询 transport_sn_box_assignment 失败 !\n");
            return false;
        }
        else
        {
            qDebug()<<"query transport_sn_box_assignment ";
            if(result_box[0].size()==0)
            {
                parcelPosition = "未查询到位置";
            }
            else
            {
                parcelPosition = QString::fromStdString(result_box[0][0]);
            }
        }
        //query table of Reservations
        string query_reservation =  "select time_slot_id,stop_id from db_vip.reservations where transport_sn=";
        query_reservation += "\'";
        query_reservation += parcelID.toStdString();
        query_reservation += "\'";
        vector<vector<string> > result_reservation;
        if( !mydb.exeSQL(query_reservation, result_reservation))
        {
            QMessageBox::information(NULL, "提示", "查询 reservations 失败 !\n");
            return false;
        }
        else
        {
            qDebug()<<"query db_vip.reservations ";
            if(result_reservation[0].size()==0)
            {
                bookTime = "未查询到预约时间";
                bookPlace = "未查询到预约停靠点";
            }
            else
            {
                bookTime = QString::fromStdString(result_reservation[0][0]);
                bookPlace = QString::fromStdString(result_reservation[1][0]);
            }
        }
        //need continue to query for time_id and place_id map

        //show  parcel info
        QString msg;
        msg.append("运单号          : ");
        msg.append(parcelID);
        msg.append("\n");
        msg.append("订单号          : ");
        msg.append(bookID);
        msg.append("\n");
        msg.append("包裹状态      : ");
        msg.append(parcelStatusMap_inv(parcelState));
        msg.append("\n");
        msg.append("收货人          : ");
        msg.append(name);
        msg.append("\n");
        msg.append("收货人地址      : ");
        msg.append(receiverAddress);
        msg.append("\n");
        msg.append("箱格类型      : ");
        msg.append(boxType);
        msg.append("\n");
        msg.append("箱格位置      : ");
        msg.append(parcelPosition);
        msg.append("\n");
        msg.append("预约时间      : ");
        msg.append(bookTime);
        msg.append("\n");
        msg.append("预约停靠点  : ");
        msg.append(bookPlace);
        msg.append("\n");
        msg.append("送货时间      : ");
        msg.append(deliveryTime);
        msg.append("\n");
        msg.append("送货班次      : ");
        msg.append(deliverySchedule);
        msg.append("\n");
        msg.append("送货停靠点  : ");
        msg.append(deliveryPlace);
        msg.append("\n");
        msg.append("异常               : ");
        msg.append(abortReason);
        //qDebug()<<msg;
        ui->textBrowser->setText(msg);

        //签收(301 302)、拒收(400)、滞留(500)、人工配送(600)状态的订单，改为滞留、改为人工配送按钮变灰
        if(parcelState == "301" | parcelState == "302" | parcelState == "500" | parcelState == "600")
        {
            ui->pushButton_detention->setDisabled(true);
            ui->pushButton_man->setDisabled(true);
        }
        else
        {
            ui->pushButton_detention->setDisabled(false);
            ui->pushButton_man->setDisabled(false);
        }
        return true;
    }
}
void ParcelInfoWidget::on_pushButton_man_clicked()
{
    qDebug()<<"change man";   
    QMessageBox::StandardButton rb=QMessageBox::information(NULL, "提示", "  包裹改为人工配送 ?", QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes);
    if(rb == QMessageBox::Yes)
    {
        emit signal_parcelInfoWidget_changeMan(parcelID_pj);
        this->close();
    }
    else
    {
        qDebug()<<"no";
        //this->close();
    }
}
void ParcelInfoWidget::on_pushButton_detention_clicked()
{
    qDebug()<<"change detention";
    detentionReasonWidget.show();
    detentionReasonWidget.getParcelID_pj(parcelID_pj);
}
