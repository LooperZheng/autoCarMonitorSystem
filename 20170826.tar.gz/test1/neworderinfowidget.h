#ifndef NEWORDERINFOWIDGET_H
#define NEWORDERINFOWIDGET_H

#include <QWidget>

namespace Ui {
class NewOrderInfoWidget;
}

class NewOrderInfoWidget : public QWidget
{
    Q_OBJECT

public:
    explicit NewOrderInfoWidget(QWidget *parent = 0);
    ~NewOrderInfoWidget();
    void initUi();//初始化界面参数
    void initConnect();//初始化信号和槽连接
    bool getMegFromDB();
public slots:
    void on_pushButton_close_clicked();

    void getUpdateParcelState();
    void updateTableWidget();
    void  clickCell(int , int);
signals:
    void signal_updadeNewMsgNum(int);
private:
    Ui::NewOrderInfoWidget *ui;

    QString parcelID_pj;
    QString name;
    QString currentState;
    QString lastState;

    int parcelNum;
    std::vector<QString> parcelIDClusters;
    std::vector<QString> nameClusters;
    std::vector<QString> currentStateClusters;
    std::vector<QString> lastStateClusters;
    std::vector<bool> isCheckCluster;
};

#endif // NEWORDERINFOWIDGET_H
