#ifndef TELEOPERATION_H
#define TELEOPERATION_H

#include <QWidget>
#include "boxinfowidget.h"
#include "vehicleinfowidget.h"
//#include "taskquerywidget.h"
#include <QGraphicsView>

//hkws
#include <QFrame>
#include "HCNetSDK.h"
#include "FramePlayWnd.h"
#include "robot.h"

#include <QModelIndex>
#include <QFrame>
#include <QMenu>
#include <QList>

#include <QPainter>
#include <QPoint>
#include <QMouseEvent>

#define SAVE_REALDATA_FILEPATH0 "/home/zlp/qt_test/DOWNLOAD_FILE/"
#define SAVE_REALDATA_FILEPATH "/home/zlp/qt_test/REALPLAY_DOWNLOAD_LEFT/"
#define SAVE_REALDATA_FILEPATH1 "/home/zlp/qt_test/REALPLAY_DOWNLOAD_RIGHT/"

#ifndef HPR_OK
#define HPR_OK 0
#endif

#ifndef HPR_ERROR
#define HPR_ERROR -1
#endif

namespace Ui {
class Teleoperation;
}

class Teleoperation : public QWidget
{
    Q_OBJECT

public:
    explicit Teleoperation(QWidget *parent = 0);
    ~Teleoperation();
    void setSysState();

    void sleep(unsigned int msec)
    {
    QTime dieTime = QTime::currentTime().addMSecs(msec);
    while( QTime::currentTime() < dieTime )
    QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
    }


    //hkws
    QFrame *frame_left;
    QFrame *frame_right;
    QFrame *frame_back;
    QFrame *frame_front;
    QFrame *frame_main;

    CFramePlayWnd *frames[5];
    LONG lUserID;
    LONG lUserIDD;
    LONG lUserIID;
    LONG lUserID1;
    LONG lUserID2;
    LONG lUserID3;
    LONG lUserID4;
    DWORD dwCommand;
    LPVOID   lpInBuffer;
    DWORD    dwInBufferSize;
    queue<UINT64> BufSize_queue;
    int times;
    bool flag;

    int init_nvr();
    int Demo_GetStream_V30(LONG lUserID);
    int StartGetStream(LONG lUserIDD,  int f_id);
    //int StartGetStream( LONG lUserIDD,int f_id);
    //void downloadfile_start(LONG lUserIID);
   // void downloadfile_stop();
    int StopNVR();
    void Demo_SDK_Version();

public slots:
    void on_button_playVideo_clicked();
    void on_button_stopVideo_clicked();
    //void on_button_downloadfilestart_clicked();
    //void on_button_downloadfilestop_clicked();
    void on_button_savefile_clicked();
    void on_button_savefile_2_clicked();
    void display();

public slots:
    void on_button_turnLeft_clicked();
    void on_button_turnRight_clicked();
    void on_button_forward_clicked();
    void on_button_backward_clicked();
    void on_button_stop_clicked();
    void on_button_start_clicked();
    void on_button_horn_clicked();
    void on_button_light_clicked();
    void on_button_lightClose_clicked();
    void on_button_operationExchange_clicked();

    void on_button_adas_clicked();
    void on_button_disPlayVediobps_clicked();
    void on_button_boxSelect_clicked();
    void on_button_vehicleInfo_clicked();

    void on_button_changeViewport_left_clicked();
    void on_button_changeViewport_back_clicked();
    void on_button_changeViewport_right_clicked();
    void on_button_changeViewport_front_clicked();
   //void on_pushButton_savefile_clicked();

    void slot_sendVehicleCmd();
    void updateRobotInfo(Robot *);
    void refreshMap();
    void addJavaScriptObject();

signals:
    void signal_showTaskQueryWidget();
    void signal_showBoxQueryWidget();
    void signal_showVehicleQueryWidget();

    void signal_vehicleControlTurnLeft();
    void signal_vehicleControlTurnRight();
    void signal_vehicleControlTurnForward();
    void signal_vehicleControlTurnBackward();
    void signal_vehicleControlStop();
    void signal_vehicleControlStart();
    void signal_vehicleControlHorn();
    void signal_vehicleControlLight();
    void signal_vehicleControlLightClose();
    void signal_operationExchange();


    void signal_vehicleControlCmd(int vel, int alpha);

private:
    void initUi();//初始化界面参数
    void initConnect();//初始化信号和槽连接

private:
    Ui::Teleoperation *ui;
    Robot *myRobot;

    QGraphicsScene scene_front ;
    QPixmap image_frontRed;
    QPixmap image_frontGreen;

    QPixmap image_frontYellow;
    QGraphicsScene scene_left;
    QPixmap image_leftRed;
    QPixmap image_leftGreen;
    QPixmap image_leftYellow;
    QGraphicsScene scene_right;
    QPixmap image_rightRed;
    QPixmap image_rightGreen;
    QPixmap image_rightYellow;
    QGraphicsScene scene_back ;
    QPixmap image_backRed;
    QPixmap image_backGreen;
    QPixmap image_backYellow;
    QGraphicsScene scene_lidar ;
    QPixmap image_lidar;
    bool adasFlag;
    bool mapFlag;
    bool speedFlag;
    bool delayFlag;
    bool m_rpsavestopflag;
    bool m_rpstartstopflag;
    bool flagid1;
    QTimer *timer;
    QTimer *timer_refreshMap;
    QTimer *timer_speed;
    QTimer *timer_delay;

    //vehicle con
    QPointF lastPoint;
    QPointF endPoint;
    QPainterPath path;
    int mouseReleaseNum;
    int mousePressNum;
    bool mouseMove;
    bool enable;
    bool enableOperation;
    bool isInCircle(QPointF centerPoint, float r , QPointF mouseCurPoint);
    void paintEvent(QPaintEvent *);
    void mousePressEvent(QMouseEvent *);
    void mouseMoveEvent(QMouseEvent *);
    void mouseReleaseEvent(QMouseEvent *);

};

#endif // TELEOPERATION_H
