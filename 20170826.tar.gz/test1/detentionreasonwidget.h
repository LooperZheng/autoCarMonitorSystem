#ifndef DETENTIONREASONWIDGET_H
#define DETENTIONREASONWIDGET_H

#include <QWidget>
#include <string>
namespace Ui {
class DetentionReasonWidget;
}

class DetentionReasonWidget : public QWidget
{
    Q_OBJECT

public:
    explicit DetentionReasonWidget(QWidget *parent = 0);
    ~DetentionReasonWidget();

    QString parcelID;
    QString parcelID_pj;
    QString reason;
    QString reason_2;

    void getParcelID_pj(QString);
public slots:
    void on_pushButton_cancell_clicked();
    void on_pushButton_yes_clicked();
private:
    void initUi();//初始化界面参数
    void initConnect();//初始化信号和槽连接
    void getRententionReason();
signals:
    void signal_parcelInfoWidget_changeDetention(QString);
private:
    Ui::DetentionReasonWidget *ui;
};

#endif // DETENTIONREASONWIDGET_H
