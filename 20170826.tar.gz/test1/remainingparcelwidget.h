#ifndef REMAININGPARCELWIDGET_H
#define REMAININGPARCELWIDGET_H

#include <QWidget>
#include <QButtonGroup>
#include "mydb.h"
namespace Ui {
class RemainingParcelWidget;
}

class RemainingParcelWidget : public QWidget
{
    Q_OBJECT

public:
    explicit RemainingParcelWidget(QWidget *parent = 0);
    ~RemainingParcelWidget();

    int getAllRemainingParcelInfoFromDB();
    void updateTableWidget();
    void updateParcelStateInDB_handle();
    void deleteParcelStateInDB_handle();
    void resetUI();
    int getBoxIndexAccordingToBoxID(QString boxID);
private:
    void initUi();//初始化界面参数
    void initConnect();//初始化信号和槽连接
    bool checkParcelID(QString parcelID);
    bool getBoxIndex(QString);
public slots:
    void on_pushButton_pickUpParcel_clicked();
    void onButtonClicked(QAbstractButton*);
    void getParcelIDFromScanner();
    void getParcelInfo();
signals:
    void signal_openBox_remainingParcel(std::vector<int>);
private:
    Ui::RemainingParcelWidget *ui;
    int parcelNum;
    QString parcelID;
    QString parcelID_scanner;
    QString parcelType;
    QString parcelInfo;
    QString BoxPos;
    std::vector<QString> parcelIDClusters;
    std::vector<QString> nameClusters;
    std::vector<QString> parcelTypeClusters;
    std::vector<QString> boxPosClusters;
    std::vector<QString> boxTypeClusters;

    std::vector<QString> parcelIDClusters_handle;
    std::vector<QString> nameClusters_handle;
    std::vector<QString> parcelTypeClusters_handle;
    std::vector<QString> boxPosClusters_handle;

    std::vector<int> boxIndex;
    std::vector<int> boxIndex_all;

    QButtonGroup *m_pButtonGroup;
};

#endif // REMAININGPARCELWIDGET_H
